Description:  pymcuprog - python-based serial-updi programmer, modified by Spence Konde and Quentin Bolsee
Source:       https://pypi.org/project/pymcuprog/
              https://github.com/SpenceKonde/DxCore
License:      MIT License

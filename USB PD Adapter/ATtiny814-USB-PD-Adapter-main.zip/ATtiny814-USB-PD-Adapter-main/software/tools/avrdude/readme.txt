Description:  Modified avrdude config file to work with jtag2updi
Source:       https://github.com/ElTangas/jtag2updi
License:      MIT License

unsigned char readbuff[64] absolute 0x500;   // Buffers should be in USB RAM, please consult datasheet
unsigned char writebuff[64] absolute 0x540;

char cnt;
char kk;

void interrupt(){
   USB_Interrupt_Proc();                   // USB servicing is done inside the interrupt
}

void main(void){
  ADCON1 |= 0x0F;                         // Configure all ports with analog function as digital
  CMCON  |= 7;                            // Disable comparators

  PORTB=0x00;                            // Port B all low
  TRISB=0x00;                            // Port B output

  HID_Enable(&readbuff,&writebuff);       // Enable HID communication

  while(1){
    kk=HID_Read();
   if(kk !=0)
    {
     if(readbuff[0]=='1') RB0_bit=1; else RB0_bit=0;
     if(readbuff[1]=='1') RB1_bit=1; else RB1_bit=0;
     if(readbuff[2]=='1') RB2_bit=1; else RB2_bit=0;
     if(readbuff[3]=='1') RB3_bit=1; else RB3_bit=0;
     if(readbuff[4]=='1') RB4_bit=1; else RB4_bit=0;
     if(readbuff[5]=='1') RB5_bit=1; else RB5_bit=0;
     if(readbuff[6]=='1') RB6_bit=1; else RB6_bit=0;
     if(readbuff[7]=='1') RB7_bit=1; else RB7_bit=0;
     for(cnt=0;cnt<kk;cnt++)       // load data for send back
      {
       writebuff[cnt]=readbuff[cnt];
      }
      HID_Write(&writebuff,kk); // send back via HID class !
    }
  }
}


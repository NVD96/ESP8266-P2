Public Class frmUSB
    ' vendor and product IDs
    Private Const VendorID As Integer = &H1234    'Replace with your device's
    Private Const ProductID As Integer = &H1234      'product and vendor IDs

    ' read and write buffers
    Private Const BufferInSize As Integer = 64 'Size of the data buffer coming IN to the PC
    Private Const BufferOutSize As Integer = 64    'Size of the data buffer going OUT from the PC
    Dim BufferIn(BufferInSize) As Byte          'Received data will be stored here - the first byte in the array is unused
    Dim BufferOut(BufferOutSize) As Byte    'Transmitted data is stored here - the first item in the array must be 0

    ' ****************************************************************
    ' when the form loads, connect to the HID controller - pass
    ' the form window handle so that you can receive notification
    ' events...
    '*****************************************************************
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' do not remove!
        ConnectToHID(Me)
        Label2.Text = "DISCONNECT"
        Label2.ForeColor = Color.Red
        GroupBox1.Hide()
        GroupBox2.Hide()
        CheckBox1.Checked = False
        CheckBox2.Checked = False
        CheckBox3.Checked = False
        CheckBox4.Checked = False
        CheckBox5.Checked = False
        CheckBox6.Checked = False
        CheckBox7.Checked = False
        CheckBox8.Checked = False
        OvalShape1.BackColor = Color.Blue
        OvalShape2.BackColor = Color.Blue
        OvalShape3.BackColor = Color.Blue
        OvalShape4.BackColor = Color.Blue
        OvalShape5.BackColor = Color.Blue
        OvalShape6.BackColor = Color.Blue
        OvalShape7.BackColor = Color.Blue
        OvalShape8.BackColor = Color.Blue
    End Sub

    '*****************************************************************
    ' disconnect from the HID controller...
    '*****************************************************************
    Private Sub Form1_FormClosed(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        DisconnectFromHID()
    End Sub

    '*****************************************************************
    ' a HID device has been plugged in...
    '*****************************************************************
    Public Sub OnPlugged(ByVal pHandle As Integer)
        If hidGetVendorID(pHandle) = VendorID And hidGetProductID(pHandle) = ProductID Then
            ' ** YOUR CODE HERE **
            Label2.Text = "CONNECTED"
            Label2.ForeColor = Color.Green
            GroupBox1.Show()
            GroupBox2.Show()
        End If
    End Sub

    '*****************************************************************
    ' a HID device has been unplugged...
    '*****************************************************************
    Public Sub OnUnplugged(ByVal pHandle As Integer)
        If hidGetVendorID(pHandle) = VendorID And hidGetProductID(pHandle) = ProductID Then
            hidSetReadNotify(hidGetHandle(VendorID, ProductID), False)
            ' ** YOUR CODE HERE **
            Label2.Text = "DISCONNECT"
            Label2.ForeColor = Color.Red
            GroupBox1.Hide()
            GroupBox2.Hide()
            CheckBox1.Checked = False
            CheckBox2.Checked = False
            CheckBox3.Checked = False
            CheckBox4.Checked = False
            CheckBox5.Checked = False
            CheckBox6.Checked = False
            CheckBox7.Checked = False
            CheckBox8.Checked = False
            OvalShape1.BackColor = Color.Blue
            OvalShape2.BackColor = Color.Blue
            OvalShape3.BackColor = Color.Blue
            OvalShape4.BackColor = Color.Blue
            OvalShape5.BackColor = Color.Blue
            OvalShape6.BackColor = Color.Blue
            OvalShape7.BackColor = Color.Blue
            OvalShape8.BackColor = Color.Blue
        End If
    End Sub

    '*****************************************************************
    ' controller changed notification - called
    ' after ALL HID devices are plugged or unplugged
    '*****************************************************************
    Public Sub OnChanged()
        ' get the handle of the device we are interested in, then set
        ' its read notify flag to true - this ensures you get a read
        ' notification message when there is some data to read...
        Dim pHandle As Integer
        pHandle = hidGetHandle(VendorID, ProductID)
        hidSetReadNotify(hidGetHandle(VendorID, ProductID), True)
    End Sub

    '*****************************************************************
    ' on read event...
    '*****************************************************************
    Public Sub OnRead(ByVal pHandle As Integer)
        ' read the data (don't forget, pass the whole array)...
        If hidRead(pHandle, BufferIn(0)) Then
            ' ** YOUR CODE HERE **
            ' first byte is the report ID, e.g. BufferIn(0)
            ' the other bytes are the data from the microcontroller...
            read_back()
        End If
    End Sub

    Private Sub Button1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Button1.Click
        DisconnectFromHID()
        End
    End Sub

    ' Functions
    Private Sub load_to_send()
       
        If CheckBox1.Checked Then
            BufferOut(1) = Asc("1")
        Else
            BufferOut(1) = 0
        End If

        If CheckBox2.Checked Then
            BufferOut(2) = Asc("1")
        Else
            BufferOut(2) = 0
        End If

        If CheckBox3.Checked Then
            BufferOut(3) = Asc("1")
        Else
            BufferOut(3) = 0
        End If

        If CheckBox4.Checked Then
            BufferOut(4) = Asc("1")
        Else
            BufferOut(4) = 0
        End If

        If CheckBox5.Checked Then
            BufferOut(5) = Asc("1")
        Else
            BufferOut(5) = 0
        End If

        If CheckBox6.Checked Then
            BufferOut(6) = Asc("1")
        Else
            BufferOut(6) = 0
        End If

        If CheckBox7.Checked Then
            BufferOut(7) = Asc("1")
        Else
            BufferOut(7) = 0
        End If

        If CheckBox8.Checked Then
            BufferOut(8) = Asc("1")
        Else
            BufferOut(8) = 0
        End If
        BufferOut(0) = 0  ' forced = 0  ( mcHid.dll) 
        hidWriteEx(VendorID, ProductID, BufferOut(0))
    End Sub
    Private Sub read_back()
        If Chr(BufferIn(1)) = "1" Then
            OvalShape1.BackColor = Color.Red
        Else
            OvalShape1.BackColor = Color.Blue
        End If

        If Chr(BufferIn(2)) = "1" Then
            OvalShape2.BackColor = Color.Red
        Else
            OvalShape2.BackColor = Color.Blue
        End If

        If Chr(BufferIn(3)) = "1" Then
            OvalShape3.BackColor = Color.Red
        Else
            OvalShape3.BackColor = Color.Blue
        End If

        If Chr(BufferIn(4)) = "1" Then
            OvalShape4.BackColor = Color.Red
        Else
            OvalShape4.BackColor = Color.Blue
        End If

        If Chr(BufferIn(5)) = "1" Then
            OvalShape5.BackColor = Color.Red
        Else
            OvalShape5.BackColor = Color.Blue
        End If

        If Chr(BufferIn(6)) = "1" Then
            OvalShape6.BackColor = Color.Red
        Else
            OvalShape6.BackColor = Color.Blue
        End If

        If Chr(BufferIn(7)) = "1" Then
            OvalShape7.BackColor = Color.Red
        Else
            OvalShape7.BackColor = Color.Blue
        End If

        If Chr(BufferIn(8)) = "1" Then
            OvalShape8.BackColor = Color.Red
        Else
            OvalShape8.BackColor = Color.Blue
        End If
        
    End Sub


    Private Sub CheckBox1_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CheckBox1.CheckedChanged
        load_to_send()
    End Sub
    Private Sub CheckBox2_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CheckBox2.CheckedChanged
        load_to_send()
    End Sub
    Private Sub CheckBox3_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CheckBox3.CheckedChanged
        load_to_send()
    End Sub
    Private Sub CheckBox4_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CheckBox4.CheckedChanged
        load_to_send()
    End Sub
    Private Sub CheckBox5_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CheckBox5.CheckedChanged
        load_to_send()
    End Sub
    Private Sub CheckBox6_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CheckBox6.CheckedChanged
        load_to_send()
    End Sub
    Private Sub CheckBox7_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CheckBox7.CheckedChanged
        load_to_send()
    End Sub
    Private Sub CheckBox8_CheckedChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles CheckBox8.CheckedChanged
        load_to_send()
    End Sub
End Class

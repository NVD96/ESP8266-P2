#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include <avr/wdt.h>
#include <util/delay.h>
#include <string.h>

#include "usbdrv.h"

void init_keys() {
    // Keys set to input-PULLUP
    DDRD &= ~(1 << PD3);
    PORTD |= (1 << PD3);
}

void init_leds(){
    // LEDs are outputs but off initially
    DDRB |= (1 << PB5);
    PORTB &= ~(1 << PB5);
}

#define NUM_KEYS_MAX 6

uint8_t g_reportBuf[1 + NUM_KEYS_MAX] = {0}; // 8 bits ctrl + 6 bytes for keys
uint8_t g_idleRate = 4;

const PROGMEM char usbHidReportDescriptor[53] = {
    0x05, 0x01,     // Usage Page (Generic Desktop Page)
    0x09, 0x06,     // Usage (Keyboard)
    0xA1, 0x01,     // Collection (Application)
    0x05, 0x07,         // Usage Page (Keyboard)
    0x19, 0xE0,         // Usage Minimum (Left Ctrl)
    0x29, 0xE7,         // Usage Maximum (Right GUI)
    0x15, 0x00,         // Logical Min (0)
    0x25, 0x01,         // Logical Max (1)
    0x75, 0x01,         // Report Size (1)
    0x95, 0x08,         // Report Count (8)
    0x81, 0x02,         // Input(Data, Var, Abs)

    0x19, 0x00,         // Usage Minimum (0)
    0x29, 0x65,         // Usage Maximum (0x65)
    0x15, 0x00,         // Logical Min (0)
    0x25, 0x65,         // Logical Max (0x65)
    0x75, 0x08,         // Report Size (8)
    0x95, 0x06,         // Report Count (6)
    0x81, 0x00,         // Input(Data, Array, Abs)

    0x05, 0x08,         // Usage Page (LED)
    0x19, 0x01,         // Usage Minimum (Num Lock)
    0x29, 0x03,         // Usage Maximum (Scroll Lock)
    0x15, 0x00,         // Logical Min (0)
    0x25, 0x01,         // Logical Max (1)
    0x75, 0x01,         // Report Size (1)
    0x95, 0x03,         // Report Count (3)
    0x91, 0x02,         // Output(Data, Var, Abs)
    0xC0            // End Collection
};

uint8_t get_ctrl_keys(){
    // Return the first four buttons, they are already in correct MOD key order
    return 0;
}

#define KEY_W 0x1A
#define KEY_A 0x04
#define KEY_S 0x16
#define KEY_D 0x07
#define KEY_H 0x0B
#define KEY_J 0x0D
#define KEY_K 0x0E
#define KEY_L 0x0F

const uint8_t keyMap[] = {KEY_W, KEY_A, KEY_S, KEY_D, KEY_H, KEY_J, KEY_K, KEY_L};

uint8_t buildReport(){
    uint8_t current_key = 0;

    // Will be used to check if there was a change
    uint8_t tmpBuf[sizeof(g_reportBuf)];
    memcpy(tmpBuf, g_reportBuf, sizeof(tmpBuf));

    g_reportBuf[0] = get_ctrl_keys();

    // Add your own keys here, you can only report a maximum of NUM_KEYS_MAX
    if(!(PIND & (1 << PD3))){
        g_reportBuf[1] = KEY_W;
        current_key++;
    }

    // Fill in the rest of the buffer with zeros
    if(current_key < NUM_KEYS_MAX-1){
        for(uint8_t i = current_key; i < NUM_KEYS_MAX; i++){
            g_reportBuf[i + 1] = 0;
        }
    }

    // They are the same (no change)
    if(memcmp(tmpBuf, g_reportBuf, sizeof(tmpBuf)) == 0){
        return 0;
    }

    return 1;
}

usbMsgLen_t usbFunctionSetup(uint8_t data[8]){
    usbRequest_t *rq = (void *) data;

    if((rq->bmRequestType & USBRQ_TYPE_MASK) == USBRQ_TYPE_MASK){
        switch(rq->bRequest){
        
            case USBRQ_HID_GET_REPORT:
                // Treat same as our interrupt IN (send keys)
                buildReport();
                usbMsgPtr = g_reportBuf;
                return sizeof(g_reportBuf);

            case USBRQ_HID_SET_REPORT:
                // Should only by 1 byte for the LEDs
                if(rq->wLength.word == 1){
                    // Go to usbFunctionWrite() instead
                    return USB_NO_MSG;
                }

                return 0;

            // Send or change Idle rate when commanded
            case USBRQ_HID_GET_IDLE:
                usbMsgPtr = &g_idleRate;
                return 1;

            case USBRQ_HID_SET_IDLE:
                g_idleRate = rq->wValue.bytes[1];
                return 0;
        }
    }

    // By default, return no data back
    return 0;
}

usbMsgLen_t usbFunctionWrite(uint8_t *data, uint8_t len){
    // Num, caps, and scroll
    if(data[0]){
        PORTB |= (1 << PB5);
    } else {
        PORTB &= ~(1 << PB5);
    }

    return 1;
}

int main(){
    // Enable watchdog in case of an unrecoverable error
    // Reset after 2 seconds
    wdt_enable(WDTO_2S);

    // Keyboard initialization
    init_keys();
    init_leds();

    // Allow VUSB to initialize itself
    usbInit();
    sei();

    // Re-enumerate device
    usbDeviceDisconnect();
    uchar i = 0;
    while(--i){
        wdt_reset();
        _delay_ms(1);
    }
    usbDeviceConnect();

    while(1){
        // Reset the watchdog reset countdown
        wdt_reset();

        usbPoll();

        uint8_t change = buildReport();

        // 0 is an indefinite idle
        if(g_idleRate != 0) {
            for(int i = 0; i < g_idleRate; i++){
                _delay_ms(4);
            }
        }

        // Interrupt IN request, and there is new data to report
        if(usbInterruptIsReady() && change == 1){
            // Send over the HID data
            usbSetInterrupt(g_reportBuf, sizeof(g_reportBuf));
        }
    }

    return 0;
}

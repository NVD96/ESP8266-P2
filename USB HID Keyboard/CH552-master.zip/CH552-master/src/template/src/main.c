#include "ch552.h"

void main(void) {

	// Prepare the hardware here
	init_clock();

	while (1) {
		// Do stuff here
	}
}
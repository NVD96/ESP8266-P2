var searchData=
[
  ['get2channeldata_0',['get2ChannelData',['../class_two_channel_sound_data.html#a0a39d70aca39dbeca3d20676635b7615',1,'TwoChannelSoundData::get2ChannelData()'],['../class_one_channel_sound_data.html#a3ed4a75be0bb4dbb42752f5ae83badbb',1,'OneChannelSoundData::get2ChannelData()'],['../class_one_channel8_bit_sound_data.html#a0d7a1fdf7cc8aee06c158b7dc72d491d',1,'OneChannel8BitSoundData::get2ChannelData()']]],
  ['get_5faudio_5fstate_1',['get_audio_state',['../class_bluetooth_a2_d_p_common.html#a74eadbd69b5c7adf1b190c7e41b75b10',1,'BluetoothA2DPCommon']]],
  ['get_5faudio_5ftype_2',['get_audio_type',['../class_bluetooth_a2_d_p_sink.html#a77600cb1e36b7814eb9b4126cdec62d4',1,'BluetoothA2DPSink']]],
  ['get_5fconnection_5fstate_3',['get_connection_state',['../class_bluetooth_a2_d_p_common.html#a513b32676d8fc248bb481180f832ef97',1,'BluetoothA2DPCommon']]],
  ['get_5fcurrent_5fpeer_5faddress_4',['get_current_peer_address',['../class_bluetooth_a2_d_p_sink.html#a84491fcf5f42ca5ac2f5dcff5a0d4508',1,'BluetoothA2DPSink']]],
  ['get_5fdata_5fdefault_5',['get_data_default',['../class_bluetooth_a2_d_p_source.html#ab199a1240a5850a43738f3872805c9ba',1,'BluetoothA2DPSource']]],
  ['get_5flast_5fpeer_5faddress_6',['get_last_peer_address',['../class_bluetooth_a2_d_p_common.html#acf924bb9f5e348c85e65879c337a4bde',1,'BluetoothA2DPCommon']]],
  ['get_5flast_5frssi_7',['get_last_rssi',['../class_bluetooth_a2_d_p_sink.html#a5a770be98d977a8df916d8cc044b310c',1,'BluetoothA2DPSink']]],
  ['get_5fvolume_8',['get_volume',['../class_bluetooth_a2_d_p_common.html#a0e570c2c2f9db40873286e0571f0d93a',1,'BluetoothA2DPCommon::get_volume()'],['../class_bluetooth_a2_d_p_sink.html#aca1119f20d2321fb950ae859000cce7b',1,'BluetoothA2DPSink::get_volume()']]]
];

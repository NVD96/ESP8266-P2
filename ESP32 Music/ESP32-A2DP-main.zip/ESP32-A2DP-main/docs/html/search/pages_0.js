var searchData=
[
  ['a_20simple_20arduino_20bluetooth_20music_20receiver_20and_20sender_20for_20the_20esp32_0',['A Simple Arduino Bluetooth Music Receiver and Sender for the ESP32',['../index.html',1,'']]]
];

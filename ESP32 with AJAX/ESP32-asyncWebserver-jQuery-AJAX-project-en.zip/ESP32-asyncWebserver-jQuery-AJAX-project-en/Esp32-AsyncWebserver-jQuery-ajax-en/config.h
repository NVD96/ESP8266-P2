
const char* ssid = "SSID";
const char* password = "Password";

const char* http_username = "admin";
const char* http_password = "admin";

const char* host = "esp32-asyncwebserver";

String allowedExtensionsForEdit = "txt, h, htm, html, css, cpp, js";

const char* jquery = "/jquery-3.6.3.min.js";


const char ldrPin = 36;
String sensorValue = "0";

const char ledPin = 2;
String ledValue = "true";
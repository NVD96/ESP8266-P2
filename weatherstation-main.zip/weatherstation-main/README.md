# Weather Station with E-Ra Platfrom
+ Goouuu-ESP32
+ DHT11 Temperature Humidity Sensor
+ 2 inch TFT Module 240×320 ST7789V GMT020-02


![final](https://github.com/tinh0403/weatherstation/assets/96488265/22f89f9f-2522-4f32-835a-2e3dd2a913c9)
![ERa](https://github.com/tinh0403/weatherstation/assets/96488265/6eb69d7e-7ec3-4d1d-9320-9359728ce945)

void XuLyPhimM(uint8_t phim);

void XuLyPhimM(uint8_t phim){
	if(ctrl){
		ctrl=0;
		cmd_LCD(troKoNhapNhay);
		RongMang(rawData,MAX_RAWDATA);
		cmd_LCD(1);
		move_LCD(1,1);
		data_LCD('M');	
		if(phim==mpMcong){
			so[0]=mem;
			mu[0]=muMem;
		}else{
			so[0]=mem=0;
			mu[0]=muMem=0;
		}
		HtDong2();
		return;	
	}
	if((*(pRawData-1)==mpMcong)||(*(pRawData-1)==mpMtru)){
		cmd_LCD(1);
		printx_LCD("K M");
		if(phim==mpMcong){
			mem=iadd(mem,muMem,kq,soMuKq,&muMem);
			data_LCD('+');
		}else{
			mem=isub(mem,muMem,kq,soMuKq,&muMem);
			data_LCD('-');
		}
		move_LCD(1,17);
		return;
	}
	XuLyPhimBang();
	if(phim==mpMcong)
		mem=iadd(mem,muMem,kq,soMuKq,&muMem);
	else
		mem=isub(mem,muMem,kq,soMuKq,&muMem);
	
	if(rawData[MAX_RAWDATA-2]!=RONG) return;	//day du lieu, chua lai moi byte RONG o cuoi mang	
	*pRawData=phim;
	pRawData++;	
	HtDong1();
	move_LCD(1,17);
}
int on=0;
int vuaTinhXong=0;

int64_t mem=0;
int muMem=0;

int64_t so[MAX_RAWDATA];
int mu[MAX_RAWDATA];
uint8_t koSo[MAX_RAWDATA];
int64_t kq;
int soMuKq;
char aKq[MAX_SO];

uint8_t cotData[MAX_COTDATA];
uint8_t *xlData=cotData+MAX_RAWDATA;

uint8_t ol=0;
uint8_t div0=0;
uint8_t can2am=0;
uint8_t ctrl=0;
uint8_t sapHetRam=0;
uint8_t rawData[MAX_RAWDATA];
uint8_t *pRawData=rawData,*pCotData=cotData, *htData=cotData;
uint8_t *htDataTruoc=cotData, *htDataSau=cotData+MAX_RAWDATA;
uint8_t *ctaData=cotData, *rgData=cotData+MAX_RAWDATA;
uint8_t *rgcdData=cotData, *naData=cotData+MAX_RAWDATA;
void HtDong2(void);
void XoaDong2(void);
int i2a(uint64_t so, char* aSo);
int64_t iabs(int64_t so);

void HtDong2(void){
	XoaDong2();
	if(div0){
		div0=0;
		move_LCD(2,1);
		printx_LCD("Chia cho 0");
		move_LCD(2,17);
		return;
	}
	if(ol){
		ol=0;
		move_LCD(2,1);
		printx_LCD("Tran so");
		move_LCD(2,17);
		return;
	}
	if(can2am){
		can2am=0;
		move_LCD(2,1);
		printx_LCD("Can 2 so am");
		move_LCD(2,17);
		return;
	}
	
	kq=so[0];
	soMuKq=mu[0];
	if(kq==0){
		move_LCD(2,16);
		data_LCD('0');
		return;
	}
	int soYnghia;
	soYnghia=i2a(iabs(kq),aKq);
	move_LCD(2,16);	
	cmd_LCD(0b100);					//xuat tu phai sang trai	
	if((soMuKq<9)&&(soMuKq>=0)){			//ghi dang binh thuong
		if(soYnghia<=soMuKq+1){			//ko co phan thap phan
			for(int i=0;i<soMuKq-soYnghia+1;i++)
				data_LCD('0');
			for(int i=0;i<soYnghia;i++)
				data_LCD(aKq[i]+0x30);		//chuyen sang ma ascii roi xuat ra lcd
		}else{
			for(int i=0;i<soYnghia-soMuKq-1;i++)
				data_LCD(aKq[i]+0x30);		//xuat phan thap phan
			data_LCD(',');
			for(int i=soYnghia-soMuKq-1;i<soYnghia;i++)
				data_LCD(aKq[i]+0x30);
		}
	}else if(soMuKq>8){
		data_LCD(soMuKq%10+0x30);
		if(soMuKq>9)
			data_LCD(soMuKq/10+0x30);
		data_LCD(kyTu10nho);
		data_LCD('x');
		if(soYnghia==1)
			data_LCD(aKq[0]+0x30);
		else{
			for(int i=0;i<soYnghia-1;i++)
				data_LCD(aKq[i]+0x30);
			data_LCD(',');
			data_LCD(aKq[soYnghia-1]+0x30);
		}
	}else if(soMuKq>-9){
		int soXuatRa;
		soXuatRa=min(soYnghia,10+soMuKq);		
		for(int i=soYnghia-soXuatRa;i<soYnghia;i++){
			if(aKq[i]==0) 
				continue;
			else{
				for(;i<soYnghia;i++)
					data_LCD(aKq[i]+0x30);
				break;
			}
		}
		for(int i=0;i<-soMuKq-1;i++)
			data_LCD('0');
		data_LCD(',');
		data_LCD('0');
	}else if(soMuKq<-8){
		data_LCD(-soMuKq%10+0x30);
		if(-soMuKq>9)
			data_LCD(-soMuKq/10+0x30);
		data_LCD(kyTu10nhoAm);
		data_LCD('x');
		if(soYnghia==1)
			data_LCD(aKq[0]+0x30);
		else{
			for(int i=0;i<soYnghia-1;i++)
				data_LCD(aKq[i]+0x30);
			data_LCD(',');
			data_LCD(aKq[soYnghia-1]+0x30);
		}		
	}
	if(kq<0)
		data_LCD('-');
	move_LCD(2,17);	
}

void XoaDong2(void){
	move_LCD(2,1);
	for(int i=0;i<16;i++)
		data_LCD(' ');
}

int i2a(uint64_t so, char* aSo){
	int i=0;
	for(; so!=0; i++){
		if(so%10!=0){ 
			aSo[i]=so%10;
			for(;so!=0;i++){
				aSo[i]=so%10;
				so/=10;
			}
			break;
		}else
			i--;
		so/=10;
	}
	return i;
}
#include <const.h>
#include <bienToanCuc.h>
#include <flash.h>
//#include <avr/io.h>
//#include <avr/iom32.h>
//#include <inttypes.h>
#include <math.h>
//#include <avr/eeprom.h>

#include <myKeypad.h>
#include <myLCD.h>
#include <khoiTao.c>
#include <htDong1.c>
#include <phimHT.c>
#include <htDong2.c>
#include <phimBang.c>

#include <phimM.c>
#include <phimC.c>
#include <phimShift.c>
#include <phimDK.c>
#include <phimDEL.c>

int main(void){
	KhoiTao();	
/*
	move_LCD(1,5);
	print_LCD("Xin Chao",8);
	move_LCD(1,17);	
*/

		while(1){	
			uint8_t phim,loaiPhim;
			do{
				phim=XdPhimNhan();
			}while(phim==0xFF);
			
			if(phim==mpShift){
				on=~on;
				if(on==0){
					XuLyPhimC();
					cmd_LCD(1);				//xoa LCD
					cmd_LCD(0b00001000);	//tat LCD
					LCD_EX|=1<<LCD_ONOFF;
				}else{
					cmd_LCD(0b00001110);	//bat LCD	
					LCD_EX&=~(1<<LCD_ONOFF);
				}
				continue;
			}
	
			if(on==0) continue;
			
			loaiPhim=pgm_read_byte(&MAPHIM_LOAIPHIM[phim]);
			switch(loaiPhim){
				case pHT: 	XuLyPhimHT(phim);
							break;
				case pBang: XuLyPhimBang();
							break;
				case pM:	XuLyPhimM(phim);
							break;
				case pC: 	XuLyPhimC();
							break;
				//case pShift:XuLyPhimShift();
				//			break;
				case pDK: 	XuLyPhimDK(phim);
							break;
				case pDEL: 	XuLyPhimDEL();
			}
		}	
	return 0;
}
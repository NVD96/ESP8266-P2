void XuLyPhimBang(void);
#include <ktraLoi.c>
#include <tinhToan.c>
void XuLyDuLieu(void);
void RutGonCongTruAm(void);
void RutGonCongDu(void);
void PhanBietTruAm(void);
void HienDauNhanAn(void);
void TachSo(void);
void TachTungSo(int bdSo, int csSo);
int XdViTriDauPhay(int bdSo);
int XdViTriA0(int bdSo);
int XdSoMu10mu(int bdSo);
int XdSoMu(int viTriA0, int viTriDauPhay, int soMu10mu);
void GhiAi(int csSo, int viTriA0, int bdSo);
int64_t i8pow(int so, int mu);
int64_t iabs(int64_t so);

void XuLyPhimBang(void){
	uint8_t maLoi=KtraLoi();
	if(maLoi==KOLOI){
		XuLyDuLieu();
		TinhToan();
		vuaTinhXong=-1;
		HtDong2();
	}else{
		pRawData=maLoi+rawData;
		HtDong1();
	}	
}

void XuLyDuLieu(void){
	RutGonCongTruAm();
	RutGonCongDu();
	PhanBietTruAm();
	HienDauNhanAn();
	TachSo();
}

void RutGonCongTruAm(void){
	RongMang(ctaData,MAX_CTADATA);	
	uint8_t *pRaw=rawData, *pCta=ctaData;
	for(;*pRaw!=RONG; pRaw++,pCta++){
		uint8_t nho=0;
		for(;*pRaw!=RONG;pRaw++,pCta++){
			if((*pRaw==mpTru)||(*pRaw==mpAm)){
				nho=~nho;
				*pCta=mpCong;
			}else if(*pRaw==mpCong){
				*pCta=mpCong;
			}else break;
		}
		*pCta=*pRaw;
		if(nho!=0) *(pCta-1)=mpTru;
	}
	
	RongMang(rgData,MAX_RGDATA);
	uint8_t *pRg=rgData;
	pCta=ctaData;
	for(;; pCta++,pRg++){
		switch(*pCta){
			case RONG: return;
			case mpCong: 
				pCta++;
				switch(*pCta){
					case mpCong:
						pRg--;
						pCta--;
						continue;
					case mpTru:
						*pRg=mpTru;
						break;
					default:
						*pRg=mpCong;
						pRg++;
						*pRg=*pCta;
				}
				break;
			case mpTru:
				*pRg=mpTru;
				break;
			default:
				*pRg=*pCta;
		}
	}
}

void RutGonCongDu(void){
	RongMang(rgcdData,MAX_RGCDDATA);
	uint8_t *pRgcd=rgcdData, *pRg=rgData;
	if(*pRg==mpCong) pRg++;	//bo qua dau cong dau tien
	for(;;pRgcd++,pRg++){
		switch(*pRg){
			case RONG: return;				
			case mp10mu:case mpSongSong:case mpMo:case mpCan2:case mpCan3:case mpNhan:case mpChia:
				*pRgcd=*pRg;
				if(*(pRg+1)==mpCong) pRg++;	//bo qua dau cong theo ngay sau
				break;
			default: 
				*pRgcd=*pRg;
		}
	}
}

void PhanBietTruAm(void){
	uint8_t *pTa=rgcdData;
	if(*pTa==mpTru) *pTa=mpAm;	//doi mpTru dau tien thanh mpAm
	for(;;pTa++){
		switch(*pTa){
			case RONG: return;
			case mp10mu:case mpSongSong:case mpMo:case mpCan2:case mpCan3:case mpNhan:case mpChia:
				if(*++pTa==mpTru) *pTa=mpAm;	//neu mpTru theo ngay sau thi thay mpTru bang mpAm
				break;
		}
	}
}

void HienDauNhanAn(void){
	RongMang(naData,MAX_NADATA);
	uint8_t *pNa=naData, *pRgcd=rgcdData;
	for(;;pNa++,pRgcd++){
		switch(*pRgcd){
			case RONG: return;
			case mp0:case mp1:case mp2:case mp3:case mp4:case mp5:case mp6:case mp7:case mp8:
			case mp9:case mpDong:case mpPhay:case mpK:case mpMu2:case mpMu3:case mpGiaiThua:
				*pNa=*pRgcd;
				switch(*(pRgcd+1)){
					case RONG: return;
					case mpMo:case mpK:case mpCan2:case mpCan3:
						*++pNa=mpNhan;
				}
				break;
			default:
				*pNa=*pRgcd;				
		}
	}
}

void TachSo(void){
	int bdSo;
	RongMang(koSo,MAX_RAWDATA);
	for(int i=0,j=0,k=0; naData[i]!=RONG; k++){
		if(naData[i]==mpK){
			so[j]=kq;
			mu[j]=soMuKq;
			koSo[k]=ALPHA+j;
			i++;
			j++;
			continue;
		}else if(IsMember(naData[i],MP_SOPHAYAM10MU)==NO){
			koSo[k]=naData[i];										//neu ko phai la so thi luu vao koSo
			i++;
			continue;
		}		
		bdSo=i;
		for(;IsMember(naData[i],MP_SOPHAYAM10MU)==YES; i++)		//neu la so thi bo qua
			;
		TachTungSo(bdSo,j);
		koSo[k]=ALPHA+j;
		j++;
	}
	return;
}

void TachTungSo(int bdSo, int csSo){
	int viTriA0,viTriDauPhay;
	int soMu10mu,soMu;
	
	viTriDauPhay=XdViTriDauPhay(bdSo);
	viTriA0=XdViTriA0(bdSo);
	soMu10mu=XdSoMu10mu(bdSo);	
	soMu=XdSoMu(viTriA0,viTriDauPhay,soMu10mu);
	if(soMu<-99)
		so[csSo]=0;
	else if(soMu>99)
		ol=1;
	else{
		GhiAi(csSo,viTriA0,bdSo);
		mu[csSo]=soMu;
	}
}

int XdViTriDauPhay(int bdSo){	
	int i=bdSo;
	for(;IsMember(naData[i],MP_SOAM)==YES;i++)
		;
	return i;
}

int XdViTriA0(int bdSo){
	if(naData[bdSo]==mp10mu) 
		return -1;				//A0=1 an
	for(int i=bdSo; ;i++){
		switch(naData[i]){
			case mp1:case mp2:case mp3:case mp4:case mp5:case mp6:case mp7:case mp8:case mp9:
				return i;
			case mp0:case mpPhay:case mpAm: 
				continue;
			default:
				return -2;		//ko co A0
		}
	}	
}

int XdSoMu10mu(int bdSo){
	int muAm=1,i=bdSo,soMu10mu;

	for(;naData[i]!=mp10mu;i++)
		if(IsMember(naData[i],MP_SOPHAYAM)==NO) 
			return 0;
	i++;
	if(naData[i]==mpAm){
		muAm=-1;
		i++;
	}
	soMu10mu=pgm_read_byte(&MAPHIM_BCD[naData[i]]);
	i++;
	if(IsMember(naData[i],MP_SO)==YES)
		soMu10mu=soMu10mu*10+pgm_read_byte(&MAPHIM_BCD[naData[i]]);
	return muAm*soMu10mu;
}

int XdSoMu(int viTriA0, int viTriDauPhay, int soMu10mu){
	if(viTriA0==-2) return 0;
	if(viTriA0>viTriDauPhay)
		return viTriDauPhay-viTriA0+soMu10mu;
	else
		return viTriDauPhay-viTriA0-1+soMu10mu;
}

void GhiAi(int csSo, int viTriA0, int bdSo){
	so[csSo]=0;
	
	if(viTriA0==-1){
		so[csSo]=1;
	}else if(viTriA0!=-2){
		for(int i=0,soLan=0; soLan<MAX_SO; i++,soLan++){
			if(naData[viTriA0+i]==mpPhay)
				i++;
			if(IsMember(naData[viTriA0+i],MP_SO)==NO)
				break;
			so[csSo]=so[csSo]*10+pgm_read_byte(&MAPHIM_BCD[naData[viTriA0+i]]);	
		}
	}
	int i=1;
	for(; so[csSo]>=i8pow(10,i); i++)
		;
	so[csSo]*=i8pow(10,MAX_SO-i);	
	if(naData[bdSo]==mpAm) 
		so[csSo]=-so[csSo];
}

int64_t i8pow(int so, int mu){
	int64_t kq=1;
	for(int i=0;i<mu;i++)
		kq*=so;
	return kq;
}

int64_t iabs(int64_t so){
	if(so>0) return so;
	return -so;
}
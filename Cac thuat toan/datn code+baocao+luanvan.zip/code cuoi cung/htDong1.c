void HtDong1(void);
uint8_t SoByte(uint8_t *pMang);
uint8_t Byte2cot(void);
uint8_t GhiKyTuDai(prog_char pKyTu[], uint8_t *pCot);
uint8_t SoCotThuc(void);
uint8_t DoDaiKyTuCuoi(void);
void KyTuSangTrai(void);
void KyTuSangPhai(void);

void HtDong1(){
	if(ctrl) cmd_LCD(troNhapNhay);
	else cmd_LCD(troKoNhapNhay);
	
	cmd_LCD(0b110);
	move_LCD(1,1);
	for(int i=0;i<16;i++)
		data_LCD(' ');
	move_LCD(1,1);

	if(*rawData==RONG) return;
	if((MAX_RAWDATA-SoByte(rawData))<10) sapHetRam=1;
	else sapHetRam=0;
	
	uint8_t soCot=Byte2cot(),sct=SoCotThuc();
	
	if(soCot<16){								//ko day dong
		for(int i=0;pCotData[i]!=RONG;i++)
			data_LCD(pCotData[i]);
		move_LCD(1,sct+1);
	}else if(*pRawData==RONG){					//day dong trai
		KyTuSangTrai();
		for(int i=soCot-14; i<soCot; i++)
			data_LCD(pCotData[i]);
	}else if(*(pRawData+1)==RONG){				//vua day dong trai
		KyTuSangTrai();
		for(int i=soCot-15; i<soCot; i++)
			data_LCD(pCotData[i]);
		move_LCD(1,17-DoDaiKyTuCuoi());
	}else if(sct<15){							//day dong phai
		for(int i=0; i<15; i++)
			data_LCD(pCotData[i]);
		KyTuSangPhai();
		move_LCD(1,sct+1);
	}else{										//day dong trai phai
		KyTuSangTrai();
		for(int i=sct-13; i<=sct; i++)
			data_LCD(pCotData[i]);
		KyTuSangPhai();
		move_LCD(1,15);
	}
}

uint8_t SoByte(uint8_t *pMang){
	uint8_t *pMang0=pMang;
	while(1){
		if(*pMang==RONG) return (pMang-pMang0);
		else
			pMang++;
	}
}

uint8_t Byte2cot(void){
	RongMang(pCotData, MAX_COTDATA);
	
	uint8_t *pRaw=rawData, *pCot=cotData;
	while(*pRaw!=RONG){
		switch(*pRaw){
			case mpCan2:	pCot+=GhiKyTuDai(CHUOI_CAN2,pCot);
				break;
			case mpCan3:	pCot+=GhiKyTuDai(CHUOI_CAN3,pCot);
				break;
			case mp10mu:	pCot+=GhiKyTuDai(CHUOI_10MU,pCot);
				break;
			case mpMcong:	pCot+=GhiKyTuDai(CHUOI_MCONG,pCot);
				break;
			case mpMtru:	pCot+=GhiKyTuDai(CHUOI_MTRU,pCot);
				break;
			default: 		*pCot=pgm_read_byte(&MAPHIM_TENPHIM[*pRaw]);
							pCot++;
		}
		pRaw++;
	}
	return pCot-cotData;
}

uint8_t GhiKyTuDai(prog_char pKyTu[], uint8_t *pCot){
	uint8_t tam;
	for(uint8_t i=0;;i++){
		tam=pgm_read_byte(&pKyTu[i]);
		if(tam==het) return i;
		pCot[i]=tam;
	}
}
	
uint8_t SoCotThuc(void){
	uint8_t sct=0;
	
	for(uint8_t *pMang=rawData; pMang<pRawData; pMang++){
		switch(*pMang){
			case mpCan2:case mp10mu:case mpMcong:case mpMtru: sct+=2;
				break;
			case mpCan3: sct+=3;
				break;
			default: sct++;
		}
	}
	return sct;
}

uint8_t DoDaiKyTuCuoi(void){
	uint8_t kyTuCuoi=pRawData[SoByte(pRawData)-1];
	switch(kyTuCuoi){
		case mpCan2:case mp10mu:case mpMcong:case mpMtru: return 2;
			break;
		case mpCan3: return 3;
			break;
		default: return 1;
	}
}

void KyTuSangTrai(void){
	if(sapHetRam) data_LCD(kyTuSangTraiHetRam);
	else data_LCD(kyTuSangTrai);
}
	
void KyTuSangPhai(void){
	if(sapHetRam) data_LCD(kyTuSangPhaiHetRam);
	else data_LCD(kyTuSangPhai);
}

void XuLyPhimDEL(void);
uint8_t SoByteTuPtrVeSau(uint8_t *ptr);

void XuLyPhimDEL(void){
	if(*rawData==RONG) return;
	if(ctrl){
		if(*pRawData==RONG)
			if(SoByte(rawData)<11){
				for(uint8_t *pMang=rawData; pMang<pRawData; pMang++)
					*pMang=RONG;
				pRawData=rawData;
			}else{
				for(uint8_t *pMang=pRawData-1; pMang>pRawData-11; pMang--)
					*pMang=RONG;
				pRawData-=10;
			}
		else{
			if(SoByteTuPtrVeSau(pRawData)<11)
				for(uint8_t *pMang=pRawData; *pMang!=RONG; pMang++)
					*pMang=RONG;
			else{
				uint8_t *pMang=pRawData;
				for(; *(pMang+10)!=RONG; pMang++)
					*pMang=*(pMang+10);
				for(; *pMang!=RONG; pMang++)
					*pMang=RONG;
			}
		}
	}else
		if(*pRawData==RONG){
			pRawData--;
			*pRawData=RONG;
		}else{
			uint8_t *pMang=pRawData;
			for(; *(pMang+1)!=RONG; pMang++)
				*pMang=*(pMang+1);	
			*pMang=RONG;
			}
	
	HtDong1();
}

uint8_t SoByteTuPtrVeSau(uint8_t *ptr){
	uint8_t *pMang=ptr;
	for(; *pMang!=RONG; pMang++){}
	return pMang-ptr;
}
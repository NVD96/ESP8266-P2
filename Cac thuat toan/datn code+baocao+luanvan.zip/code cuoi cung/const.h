#include <avr/pgmspace.h>
//---------------------------------------------------------------
typedef enum {YES,NO} yes_no;
typedef enum {CO,KO} bit;
//---------------------------------------------------------------

#define RONG 0XEE
#define het 0xFF
#define xx	0xDD
#define KOLOI 0xFF
#define ALPHA 0x30
//---------------------------------------------------------------

#define mpCtrl	0
#define mpTrai	1
#define mpPhai	2
#define mpDel	3
#define mpShift	4
#define mpC	5
#define mp7	6
#define mp8	7
#define mp9	8
#define mpChia	9
#define mpMo	0xA
#define mpGiaiThua	0xB
#define mp4	0xC
#define mp5	0xD
#define mp6	0xE
#define mpNhan	0xF
#define mpDong	0x10
#define mpNghichDao	0x11
#define mp1	0x12
#define mp2	0x13
#define mp3	0x14
#define mpTru	0x15
#define mpAm	0x16
#define mpSongSong	0x17
#define mp0	0x18
#define mpPhay	0x19
#define mpBang	0x1A
#define mpCong	0x1B
#define mpK	0x1C
#define mpMtru	0x1D
#define mpCan2	0x1E
#define mpCan3	0x1F
#define mpMu2	0x20
#define mpMu3	0x21
#define mp10mu	0x22
#define mpMcong	0x23
#define MAX_MP	0x23

#define pHT	0
#define pDK 1
#define pBang 2
#define pDEL 3
#define pC 4
#define pShift 5
#define pM 6

//---------------------------------------------------------------

#define troNhapNhay 0b00001111
#define troKoNhapNhay 0b00001110
#define xoaLCD 1

//---------------------------------------------------------------
#define MAX_RAWDATA 80		//so ky tu toi da nguoi dung duoc nhap vao la 80
#define MAX_COTDATA 3*MAX_RAWDATA
#define MAX_HTDATA MAX_RAWDATA
#define MAX_CTADATA MAX_RAWDATA
#define MAX_RGDATA MAX_RAWDATA
#define MAX_RGCDDATA MAX_RAWDATA
#define MAX_NADATA 2*MAX_RAWDATA
#define MAX_SO 9
#define MAX_SOMU 99

//---------------------------------------------------------------
#define CGRAM0	0B01000000
#define CGRAM1	0B01001000
#define CGRAM2	0B01010000
#define CGRAM3	0B01011000
#define CGRAM4	0B01100000
#define CGRAM5	0B01101000
#define CGRAM6	0B01110000
#define CGRAM7	0B01111000
#define min(a,b) a<b?a:b
//---------------------------------------------------------------

#define kyTuAm 0
#define kyTu2nho 1
#define kyTu3nho 2
#define kyTuCan 3
#define kyTu10nho 4
#define kyTu10nhoAm 5
#define kyTuNghichDao 6
#define kyTuSongSong 7
#define kyTuChia 0xFD
#define kyTuSangTrai 0x7F
#define kyTuSangPhai 0X7E	
#define kyTuSangTraiHetRam 0x3C
#define kyTuSangPhaiHetRam 0x3E

//---------------------------------------------------------------
#define lpSo	13
#define lpCongTru	12
#define lpNhanChia	11
#define lpMo	10
#define lpDong	9
#define lpPhay	8
#define lpAm	7
#define lpK		6
#define lpCan	5
#define lpMu	4
#define lp10mu	3
#define lpGiaiThua	2
#define lpNghichDao	1
#define lpSongSong	0	

#define lpKtraDongMoXong 14
void XuLyPhimDK(char phim);

void XuLyPhimDK(char phim){
	vuaTinhXong=0;
	switch(phim){
		case mpCtrl:	ctrl=~ctrl;
						break;
						
		case mpTrai: 	if(pRawData!=rawData){
							if(!ctrl) pRawData--;
							else if(pRawData-rawData<10) pRawData=rawData;
							else pRawData-=10;
						}
						break;						
						
		case mpPhai:	
						if((*pRawData)!=RONG){
							if(!ctrl) pRawData++;
							else{
								uint8_t n=SoByte(pRawData);
								if(n<10) pRawData+=n;
								else pRawData+=10;
							}
						}				
	}
	HtDong1();
}
void XuLyPhimC(void);

void XuLyPhimC(void){
	RongVungNho();
	pRawData=rawData;
	cmd_LCD(xoaLCD);
}

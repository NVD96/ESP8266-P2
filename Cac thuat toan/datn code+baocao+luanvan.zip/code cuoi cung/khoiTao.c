void KhoiTao(void);
void RongVungNho(void);
void RongMang(uint8_t* pMang, uint8_t lenMang);
void GhiCGRAM(void);

void KhoiTao(void){
//---------------------------------------------------------------

	DDR_COT=0XFF; 	//cot phim la output
	DDR_HANG=0; 	//hang phim la input
	PORT_HANG=0XFF;	//treo dien tro cac hang
	
//---------------------------------------------------------------
	
	init_LCD();
	
	DDRA=0XFF; 	//ex lcd la output
	LCD_EX|=1<<LCD_ONOFF;		
	cmd_LCD(1);				//xoa LCD
	cmd_LCD(0b00001000);	//tat LCD	
//---------------------------------------------------------------
	
	RongVungNho();
	
//---------------------------------------------------------------
	GhiCGRAM();
}

void RongVungNho(void){
	RongMang(rawData, MAX_RAWDATA);
}

void RongMang(uint8_t* pMang, uint8_t lenMang){
	for(uint8_t i=0; i<lenMang; i++){
		pMang[i]=RONG;
	}
}

void GhiCGRAM(void){
	cmd_LCD(CGRAM0);
	for(uint8_t i=0; i<8*8; i++)
		data_LCD(pgm_read_byte(&KYTUDACBIET[i]));
}
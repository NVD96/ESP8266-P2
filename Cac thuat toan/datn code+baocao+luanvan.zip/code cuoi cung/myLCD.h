#include <util/delay.h>

#define 	sbi(sfr,bit)	sfr|=_BV(bit)
#define 	cbi(sfr,bit)	sfr&=~(_BV(bit))

#define EN 			2
#define RW 			1
#define RS 			0
#define CTRL		PORTD
#define DDR_CTRL	DDRD

#define DATA_O		PORTD
#define DATA_I		PIND
#define DDR_DATA	DDRD

#define LCD_EX		PORTA
#define LCD_ONOFF 	0

char Read2Nib(void);
void Write2Nib(uint8_t chr);
void Write8Bit(uint8_t chr);
void wait_LCD(void);
void init_LCD(void);
void home_LCD(void);
void move_LCD(uint8_t y,uint8_t x);
void clr_LCD(void);
void putChar_LCD(uint8_t chr);
void print_LCD(char* str, unsigned char len);
void printx_LCD(char* str);
void cmd_LCD(uint8_t);
void data_LCD(uint8_t chr);

char Read2Nib(){
	char HNib, LNib;
	DATA_O |=0xF0;
	DDR_DATA &=0x0F;	
	sbi(CTRL,EN); 
	sbi(CTRL,EN); //enable	

	HNib=DATA_I & 0xF0;
	cbi(CTRL,EN); //disable
	
	sbi(CTRL,EN); //enable
	LNib = DATA_I & 0xF0;
	cbi(CTRL,EN); //disable
	LNib>>=4;
	return (HNib|LNib);
}

void Write2Nib(uint8_t chr){

	uint8_t HNib, LNib, temp_data;	
	temp_data=DATA_O & 0x0F;

	HNib=chr & 0xF0;
	LNib=(chr<<4) & 0xF0;		
		
	DATA_O =(HNib |temp_data);	
	sbi(CTRL,EN); //enable
	cbi(CTRL,EN); //disable	
	
	DATA_O =(LNib|temp_data);		
	sbi(CTRL,EN); //enable
	cbi(CTRL,EN); //disable
}

void wait_LCD(){	

		char temp_val;
		while(1){
			cbi(CTRL,RS); //RS=0 mean the following data is COMMAND (not normal DATA)
			sbi(CTRL,RW); //the Direction of this COMMAND is from LCD -> chip
			temp_val=Read2Nib();
			if (bit_is_clear(temp_val,7)) break;
		}
		cbi(CTRL,RW); //ready for next step	
		DDR_DATA=0xFF;//Ready to Out		
	
}


void init_LCD(){
	DDR_CTRL=0xFF;
	DDR_DATA=0xFF;
//Function set------------------------------------------------------------------------------
	cbi(CTRL,RS);   // the following data is COMMAND
	cbi(CTRL, RW); // AVR->LCD
	cbi(CTRL, EN);

	sbi(CTRL,EN); //enable
	sbi(DATA_O, 5); 
	cbi(CTRL,EN); //disable
	wait_LCD();		
	Write2Nib(0x28);//
	wait_LCD();	

//Display control-------------------------------------------------------------------------		
	//cmd_LCD(0x0E);
	cmd_LCD(0b00001000);	//tat LCD

//Entry mode set------------------------------------------------------------------------
	cmd_LCD(6);
	
//Xoa LCD-------------------------------------------------------------------------------
	cmd_LCD(xoaLCD);
}

void move_LCD(uint8_t y,uint8_t x){
	uint8_t Ad;
	Ad=64*(y-1)+(x-1)+0x80; //
	cbi(CTRL,RS); // the following data is COMMAND

		Write2Nib(Ad);
		wait_LCD();
	
}

void print_LCD(char* str, unsigned char len){
	 unsigned char i;
	 for (i=0; i<len; i++){
	 	if(str[i] > 0) data_LCD(str[i]);
		else data_LCD(' ');
	 }
}

void printx_LCD(char* str){
	 for (int i=0; str[i]!=0; i++)
	 	data_LCD(str[i]);
}

void cmd_LCD(uint8_t chr){
	cbi(CTRL,RS);
	Write2Nib(chr);
	wait_LCD();
}

void data_LCD(uint8_t chr){
	sbi(CTRL,RS); //this is a normal DATA	

		Write2Nib(chr);
		wait_LCD();	
	
}
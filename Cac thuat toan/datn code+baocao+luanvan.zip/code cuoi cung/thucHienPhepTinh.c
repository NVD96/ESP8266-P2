void ThucHienPhepTinh(int64_t *soX,int *soMuX,int64_t *soY, int *soMuY,uint8_t viTriPT, uint8_t ngoi);
uint64_t iabs(int64_t so);
int64_t ipow10(int64_t so, int mu);
int64_t iadd(int64_t m,int muM, int64_t n, int muN, int* muKq);
int64_t isub(int64_t m,int muM, int64_t n, int muN, int* muKq);
int64_t imul(int64_t m,int muM, int64_t n, int muN, int* muKq);
int64_t idiv(int64_t m,int muM, int64_t n, int muN, int* muKq);

void ThucHienPhepTinh(int64_t *soX,int *soMuX,int64_t *soY, int *soMuY,uint8_t viTriPT, uint8_t ngoi){
	int64_t tuSo,mauSo;
	int soMuTuSo,soMuMauSo;
	int soMuBp;
	int64_t bp;
	int64_t gt;

	if(ngoi==1){
		switch(*(xlData+viTriPT)){
			case mpMu2:
				*soX=imul(*soX,*soMuX,*soX,*soMuX,soMuX);
				break;
			case mpMu3:
				bp=imul(*soX,*soMuX,*soX,*soMuX,&soMuBp);
				*soX=imul(*soX,*soMuX,bp,soMuBp,soMuX);
				break;
			case mpNghichDao:
				*soX=100000000000000000/(*soX);		//1e17
				*soMuX=-*soMuX-1;
				break;
			default:
				gt=1;
				for(int i=1;i<=(*soX)*pow(10,*soMuX-MAX_SO+1);i++){
					gt*=i;
				}
				for(int i=0;i<=MAX_SOMU;i++)
					if(pow(10,i)>gt){
						gt=ipow10(gt,9-i);
						*soX=gt;
						*soMuX=i-1;
						break;
					}
					
		}
	}else{
		switch(*(xlData+viTriPT)){
			case mpCong:
				*soX=iadd(*soX,*soMuX,*soY,*soMuY,soMuX);
				break;
			case mpTru:
				*soX=isub(*soX,*soMuX,*soY,*soMuY,soMuX);	
				break;
			case mpSongSong:	
				tuSo=imul(*soX,*soMuX,*soY,*soMuY,&soMuTuSo);		
				mauSo=iadd(*soX,*soMuX,*soY,*soMuY,&soMuMauSo);
				*soX=idiv(tuSo,soMuTuSo,mauSo,soMuMauSo,soMuX);
				break;
			case mpNhan:
				*soX=imul(*soX,*soMuX,*soY,*soMuY,soMuX);
				break;
			case mpChia:
				*soX=idiv(*soX,*soMuX,*soY,*soMuY,soMuX);
		}
	}
}

uint64_t iabs(int64_t so){
	if(so>0) return so;
	return -so;
}

int64_t ipow10(int64_t so, int mu){
	if(mu<0)
		for(int i=0;i<-mu;i++)
			so/=10;
	else
		for(int i=0;i<mu; i++)
			so*=10;		
	return so;
}

int64_t iadd(int64_t m,int muM, int64_t n, int muN, int* muKq){
	if(muM>muN){
		n=ipow10(n, muN-muM);
		*muKq=muM;
	}else{
		m=ipow10(m, muM-muN);
		*muKq=muN;
	}
	m=m+n;
	if(iabs(m)>=1000000000){
		m/=10;
		*muKq+=1;
	}
	int i=1;
	for(; i<=9; i++){
		if(iabs(m)<pow(10,i)){
			m=ipow10(m,9-i);					
			break;
		}
	}
	*muKq=*muKq-(9-i);		
	return m;
}

int64_t isub(int64_t m,int muM, int64_t n, int muN, int* muKq){
	if(muM>muN){
		n=ipow10(n, muN-muM);
		*muKq=muM;
	}else{
		m=ipow10(m, muM-muN);
		*muKq=muN;
	}
	m=m-n;
	if(iabs(m)>=1000000000){
		m/=10;
		*muKq+=1;
	}
	int i=1;
	for(; i<=9; i++){
		if(iabs(m)<pow(10,i)){
			m=ipow10(m,9-i);					
			break;
		}
	}
	*muKq=*muKq-(9-i);		
	return m;
}

int64_t imul(int64_t m,int muM, int64_t n, int muN, int* muKq){
	m=m*n/100000000;					//1e8
	muM+=muN;
	if(iabs(m)>=1000000000){			//1e9
		m/=10;
		muM+=1;
	}	
	*muKq=muM;
	return m;
}

int64_t idiv(int64_t m,int muM, int64_t n, int muN, int* muKq){
	m=m*1000000000/n;					//1e9
	muM=muM-muN-1;
	if(iabs(m)>=1000000000){			//1e9
		m/=10;
		muM+=1;
	}	
	*muKq=muM;
	return m;
}
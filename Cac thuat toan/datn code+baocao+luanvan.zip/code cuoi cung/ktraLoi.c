uint8_t KtraLoi(void);
void n2x(prog_char *dptr, uint8_t *r0, uint8_t *r1);
void CopyMang(uint8_t *r0, uint8_t *r1);
uint8_t KtraDungTruoc(void);
uint8_t KtraDungDau(void);
uint8_t KtraDungCuoi(void);
yes_no IsMember(uint8_t val, prog_char *dptr);
uint8_t KtraDauPhay(void);
uint8_t Ktra10mu(void);
uint8_t KtraDongMo(void);

uint8_t KtraLoi(void){
	uint8_t maLoi=KtraDungTruoc();
	//maLoi=KtraDungTruoc();
	maLoi=min(maLoi, KtraDungDau());
	maLoi=min(maLoi, KtraDungCuoi());
	maLoi=min(maLoi, KtraDauPhay());
	maLoi=min(maLoi, Ktra10mu());
	maLoi=min(maLoi, KtraDongMo());
	return maLoi;
}

uint8_t KtraDungTruoc(void){
	uint8_t *pHtDataSau=cotData+MAX_HTDATA+1, *pHtDataTruoc=cotData;
	RongMang(htDataTruoc,MAX_HTDATA);
	RongMang(htDataSau,MAX_HTDATA);
	n2x(MAPHIM_LOAIPHIMHIENTHI,htDataTruoc,rawData);
	CopyMang(htDataSau,htDataTruoc);
	uint16_t b;
	while(1){		
		if(*pHtDataSau==RONG) return KOLOI;
		b=pgm_read_word(&KTRA_DUNGTRUOC[*pHtDataSau]);
		uint16_t ax=1<<(*pHtDataTruoc);
		if((ax|b)!=b) return pHtDataSau-htDataSau;
		else{
			pHtDataTruoc++;
			pHtDataSau++;
		}
	}
}

uint8_t KtraDungDau(void){
	if(IsMember(*htData, KTRA_DUNGDAU)==YES) return KOLOI;
	else return 0;
}

uint8_t KtraDungCuoi(void){
	uint8_t n=SoByte(htData);
	if(IsMember(*(htData+n-1), KTRA_DUNGCUOI)==YES) return KOLOI;
	else return n-1;
}	

void n2x(prog_char *dptr, uint8_t *r0, uint8_t *r1){
	uint8_t a;
	while(1){
		a=*r1;
		if(a==RONG) return;		
		a=pgm_read_byte(&dptr[a]);
		*r0=a;
		r0++;
		r1++;
	}
}

uint8_t KtraDauPhay(){
	bit nho=KO;
	for(uint8_t *pHtData=htData; ; pHtData++){	
		switch(*pHtData){
			case RONG:	return KOLOI;
			case lpPhay:if(nho==CO) return pHtData-htData;
						else nho=CO;
						break;
			case lpSo: break;
			default: 	nho=KO;
		}
	}
}

uint8_t Ktra10mu(){
	for(uint8_t *pHtData=htData; ; pHtData++){
		switch(*pHtData){
			case RONG: return KOLOI;
			case lp10mu:	do{
								pHtData++;
								if(*pHtData==RONG) return KOLOI;
							}while(IsMember(*pHtData, CONGTRU_AM)==YES);
							if(*pHtData!=lpSo) return pHtData-htData;
							pHtData++;
							if(*pHtData==lpSo){
								pHtData++;
								if((*pHtData==lpSo)||(*pHtData==lpPhay)) return pHtData-htData;
								break;
							}else if(*pHtData==lpPhay) return pHtData-htData;
							else break;
		}
	}
}

uint8_t KtraDongMo(void){
	for(uint8_t *pHtData=htData; ; pHtData++){
		switch(*pHtData){
			case RONG: return KOLOI;
			case lpDong: 
				for(uint8_t *pMang=pHtData-1;; pMang--){
					if(pMang==htData-1) return pHtData-htData;
					if(IsMember(*pMang, MO_CAN)==YES){
						*pMang=*pHtData=lpKtraDongMoXong;
						break;
					}
				}
		}
	}
}

void CopyMang(uint8_t *r0, uint8_t *r1){
	for(;*r1!=RONG; r0++,r1++)
		*r0=*r1;
}

yes_no IsMember(uint8_t val, prog_char *dptr){
	for(uint8_t member,i=0; (member=pgm_read_byte(&dptr[i]))!=het; i++)
		if(member==val) return YES;
	return NO;
}
#define PORT_HANG PORTC
#define	DDR_HANG DDRC
#define	PIN_HANG PINC
#define PORT_COT PORTB
#define DDR_COT DDRB

uint8_t XdPhimNhan(void);
uint8_t QuetPhim(void);

uint8_t XdPhimNhan(){
	uint8_t maPhim;
	for(uint8_t i=0;i<100;i++){
		maPhim=QuetPhim();
		if(maPhim==0XFF) return 0xFF;
	}
	for(uint8_t i=0;i<100;i++){	
		if(QuetPhim()==0xFF) continue;			
		else i=0;
	}
	return maPhim;
}

uint8_t QuetPhim(){
	uint8_t maPhim=0;
	for(uint8_t i=0;i<6;i++){
		for(int j=0; j<15; j++)
			PORT_COT=~(1<<i);
		if((PIN_HANG&0B00111111)==0B00111111)
			maPhim++;
		else{
			uint8_t ktra=1;
			while(((~PIN_HANG)&0b00111111)!=ktra){
				maPhim+=6;
				ktra<<=1;
			}		
			return maPhim;
		}
	}
	return 0xFF;
}

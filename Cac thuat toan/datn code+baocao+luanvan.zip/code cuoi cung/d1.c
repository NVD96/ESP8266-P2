#include	<avr/io.h>

#define PORT_HANG PORTC
#define	DDR_HANG DDRC
#define	PIN_HANG PINC
#define PORT_COT PORTB
#define DDR_COT DDRB


void main(void){
	DDR_COT=0XFF; 	//cot phim la output
	DDR_HANG=0; 	//hang phim la input
	PORT_HANG=0XFF;	//treo dien tro cac hang
	
	uint8_t maPhim=0,maQuet=0b11111110;
	for(i=0;i<6;i++){
		PORT_COT|=maQuet;
		if((PIN_HANG&0B00111111)==0B00111111){
			maQuet=(maQuet<<1)+1;
			maPhim+=6;
		}
		else{
			uint8_t ktra=1;
			if(~(PIN_HANG&0B00111111)!=ktra){
				maPhim++;
				ktra<<=1;
			}
			//return maPhim;
		}
	}
	//return 0xFF;
}
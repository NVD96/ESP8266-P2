void XuLyPhimShift(void);

void XuLyPhimShift(void){
	//cmd_LCD(0b00001110);	//bat LCD	
}

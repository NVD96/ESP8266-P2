void XuLyPhimHT(char phim);
yes_no IsMember(uint8_t val, prog_char *dptr);

void XuLyPhimHT(char phim){	
	if(rawData[MAX_RAWDATA-2]!=RONG) return;	//day du lieu, chua lai moi byte RONG o cuoi mang
	
	if(vuaTinhXong){
		vuaTinhXong=0;
		pRawData=rawData;
		RongMang(pRawData,SoByte(pRawData));
		if(IsMember(phim,MP_SOPHAYAM10MU)==NO){
			*pRawData=mpK;
			pRawData++;
		}
	}
	
	if(*pRawData!=RONG){
		uint8_t n=SoByte(pRawData);
		for(uint8_t i=0; i<n; i++)
			*(pRawData+n-i)=*(pRawData+n-i-1);
	}
	
	*pRawData=phim;
	pRawData++;	
	HtDong1();
}
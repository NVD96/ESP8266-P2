prog_char phim_HT[]={	mp0, mp1, mp2, mp3, mp4, mp5, mp6, mp7, mp8, mp9,
						mpPhay, mpCong, mpTru, mpNhan, mpChia, mpAm, mpK, mpCan2, mpCan3, mpMu2,
						mpMu3, mp10mu, mpMo, mpDong, mpGiaiThua, mpNghichDao, mpSongSong};

prog_char phim_DK[]={	mpTrai, mpPhai, mpCtrl};
prog_char phim_M[]={	mpMcong, mpMtru};

prog_char MAPHIM_LOAIPHIM[]={	pDK, pDK, pDK, pDEL, pShift, pC,
								pHT, pHT, pHT, pHT, pHT, pHT,
								pHT, pHT, pHT, pHT, pHT, pHT,
								pHT, pHT, pHT, pHT, pHT, pHT,
								pHT, pHT, pBang, pHT, pHT, pM,
								pHT, pHT, pHT, pHT, pHT, pM};

prog_char MAPHIM_TENPHIM[]={	xx,xx,xx,xx,xx,xx,
								'7','8','9',kyTuChia,'(','!',
								'4','5','6','x',')',kyTuNghichDao,
								'1','2','3','-',kyTuAm,kyTuSongSong,
								'0',',',xx,'+','K',xx,
								xx,xx,kyTu2nho,kyTu3nho,xx,xx};

prog_char MAPHIM_BCD[]={		xx,xx,xx,xx,xx,xx,
								7,8,9,xx,xx,xx,
								4,5,6,xx,xx,xx,
								1,2,3,xx,xx,xx,
								0,xx,xx,xx,xx,xx,
								xx,xx,xx,xx,xx,xx};



prog_char MAPHIM_LOAIPHIMHIENTHI[]={	xx,xx,xx,xx,xx,xx,
										lpSo,lpSo,lpSo,lpNhanChia,lpMo,lpGiaiThua,
										lpSo,lpSo,lpSo,lpNhanChia,lpDong,lpNghichDao,
										lpSo,lpSo,lpSo,lpCongTru,lpAm,lpSongSong,
										lpSo,lpPhay,xx,lpCongTru,lpK,xx,
										lpCan,lpCan,lpMu,lpMu,lp10mu,xx};

prog_char KYTUDACBIET[]={	0,0,0,0XE,0,0,0,0,					//dau am
							0XE,0X11,2,4,0X1F,0,0,0,			//so 2 nho
							0XE,0X11,6,0X11,0XE,0,0,0,			//so 3 nho
							7,4,4,4,0X14,0XC,4,0,				//can
							0,0,0X17,0X15,0X15,0X15,0X17,0,	//so 10 nho
							0,0XF,0,0X17,0X15,0X15,0X17,0,		//so 10 nho am
							1,1,0X1D,1,1,0,0,0,				//nghich dao
							1,2,5,0XA,0X14,8,0X10,0};			//song song

prog_char CHUOI_CAN2[]={	kyTuCan,'(',het};
prog_char CHUOI_CAN3[]={	kyTu3nho,kyTuCan,'(',het};
prog_char CHUOI_10MU[]={	'x',kyTu10nho,het};
prog_char CHUOI_10MUAM[]={	'x',kyTu10nhoAm,het};
prog_char CHUOI_MCONG[]={	'M','+',het};
prog_char CHUOI_MTRU[]={	'M','-',het};

prog_int16_t KTRA_DUNGTRUOC[]={	0X2346,0X2356,0X2356,0X3FF7,0X2356,0X3FF7,0X3FFF,
								0X1CA9,0X3CA1,0X2356,0X3FF5,0X2356,0X3FFF,0X3DA9};

prog_char KTRA_DUNGDAU[]={	lpSo,lpCongTru,lpMo,lpPhay,lpAm,lpK,lpCan,lp10mu,het};
prog_char KTRA_DUNGCUOI[]={	lpSo,lpDong,lpPhay,lpK,lpMu,lpGiaiThua,lpNghichDao,het};
prog_char CONGTRU_AM[]={	lpCongTru,lpAm,het};
prog_char MO_CAN[]={		lpMo,lpCan,het};
prog_char MP_CONGDU[]={		mp10mu,mpSongSong,mpMo,mpCan2,mpCan3,mpNhan,mpChia,het};
prog_char MP_SOPHAYAM[]={	mp0,mp1,mp2,mp3,mp4,mp5,mp6,mp7,mp8,mp9,mpPhay,mpAm,het};
prog_char MP_SO[]={			mp0,mp1,mp2,mp3,mp4,mp5,mp6,mp7,mp8,mp9,het};
prog_char MP_SOPHAYAM10MU[]={	mp0,mp1,mp2,mp3,mp4,mp5,mp6,mp7,mp8,mp9,mpPhay,mpAm,mp10mu,het};
prog_char MP_SOAM[]={		mp0,mp1,mp2,mp3,mp4,mp5,mp6,mp7,mp8,mp9,mpAm,het};
prog_char MP_MOCAN[]={		mpMo,mpCan2,mpCan3,het};
prog_char MP_DONGRONG[]={	mpDong,RONG,het};
prog_char MP_TINH[]={		mpCong,mpTru,mpSongSong,mpNhan,mpChia,mpMu2,mpMu3,mpGiaiThua,mpNghichDao,het};
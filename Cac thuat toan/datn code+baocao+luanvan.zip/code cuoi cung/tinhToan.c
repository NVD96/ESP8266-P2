void TinhToan(void);

uint8_t DoUuTien(uint8_t mpTinh);
int64_t iadd(int64_t m,int muM, int64_t n, int muN, int* muKq);
int64_t isub(int64_t m,int muM, int64_t n, int muN, int* muKq);
int64_t imul(int64_t m,int muM, int64_t n, int muN, int* muKq);
int64_t idiv(int64_t m,int muM, int64_t n, int muN, int* muKq);
int64_t iinv(int64_t m,int muM, int* muKq);
int64_t isqrt(int64_t m, int muM, int* muKq);
int64_t iroot3(int64_t m, int muM, int* muKq);

void XoaByte(uint8_t *mang, int vt);
int64_t ipow10(int64_t so, int mu);
int PhepTinhDauTien(int vtbd);
int MoCanTrongCung(void);

void TinhToan(void){
	while(1){
		int vtMCTC=MoCanTrongCung();
		int vtPTDT=PhepTinhDauTien(vtMCTC);		
		if(vtPTDT==0){
			if(vtMCTC==-1)
				return;
			if(koSo[vtMCTC+2]==mpDong)
				XoaByte(koSo,vtMCTC+2);		//xoa mpDong
			int cs0=koSo[vtMCTC+1]-ALPHA;
			switch(koSo[vtMCTC]){
				case mpCan2:					
					so[cs0]=isqrt(so[cs0],mu[cs0],&mu[cs0]);
					if(can2am) return;
					break;
				case mpCan3:
					so[cs0]=iroot3(so[cs0],mu[cs0],&mu[cs0]);
					break;
			}
			if(ol||div0) return;
			XoaByte(koSo,vtMCTC);			//xoa mpMo hoac mpCan2 hoac mpCan3
			continue;
		}
		int cs1=koSo[vtPTDT-1]-ALPHA,cs2=koSo[vtPTDT+1]-ALPHA;
		int64_t bp,gt=1,tu,mau;
		int muBp,muTu,muMau;
		switch(koSo[vtPTDT]){
			case mpMu2:case mpMu3:case mpGiaiThua:case mpNghichDao:
				switch(koSo[vtPTDT]){
					case mpMu2:
						so[cs1]=imul(so[cs1],mu[cs1],so[cs1],mu[cs1],&mu[cs1]);
						break;
					case mpMu3:
						bp=imul(so[cs1],mu[cs1],so[cs1],mu[cs1],&muBp);
						if(ol) return;
						so[cs1]=imul(so[cs1],mu[cs1],bp,muBp,&mu[cs1]);
						break;
					case mpNghichDao:
						so[cs1]=iinv(so[cs1],mu[cs1],&mu[cs1]);
						break;						
					case mpGiaiThua:
						for(int i=1;i<=so[cs1]*pow(10,mu[cs1]-MAX_SO+1);i++){
							gt*=i;
						}
						for(int i=0;i<=MAX_SOMU;i++)
							if(pow(10,i)>gt){
								gt=ipow10(gt,9-i);
								so[cs1]=gt;
								mu[cs1]=i-1;
								break;
							}
							if(mu[cs1]>99){
								ol=-1;
								return;
							}
						break;
				}
				if(ol||div0) return;
				break;
			case mpCong:case mpTru:case mpNhan:case mpChia:case mpSongSong:
				switch(koSo[vtPTDT]){
					case mpCong:
						so[cs1]=iadd(so[cs1],mu[cs1],so[cs2],mu[cs2],&mu[cs1]);						
						break;
					case mpTru:
						so[cs1]=isub(so[cs1],mu[cs1],so[cs2],mu[cs2],&mu[cs1]);
						break;
					case mpNhan:
						so[cs1]=imul(so[cs1],mu[cs1],so[cs2],mu[cs2],&mu[cs1]);
						break;
					case mpChia:
						so[cs1]=idiv(so[cs1],mu[cs1],so[cs2],mu[cs2],&mu[cs1]);
						break;
					case mpSongSong:
						tu=imul(so[cs1],mu[cs1],so[cs2],mu[cs2],&muTu);
						if(ol) return;
						mau=iadd(so[cs1],mu[cs1],so[cs2],mu[cs2],&muMau);
						if(ol) return;
						so[cs1]=idiv(tu,muTu,mau,muMau,&mu[cs1]);						
						break;
				}
				if(ol||div0) return;
				XoaByte(koSo,vtPTDT+1);
		}
		XoaByte(koSo,vtPTDT);
	}
}

int MoCanTrongCung(void){
	int vt=-1;
	vt=-1;
	for(int i=0;IsMember(koSo[i],MP_DONGRONG)==NO; i++)
		if(IsMember(koSo[i],MP_MOCAN)==YES)
			vt=i;
	return vt;	
}

int PhepTinhDauTien(int vtbd){
	int dut=0,vt=0;

	for(int i=vtbd+1; IsMember(koSo[i],MP_DONGRONG)==NO; i++)
		if(IsMember(koSo[i],MP_TINH)==NO)
			continue;
		else if(DoUuTien(koSo[i])>dut){
			dut=DoUuTien(koSo[i]);
			vt=i;
		}else
			break;
	return vt;
}

uint8_t DoUuTien(uint8_t mpTinh){
	switch(mpTinh){
		case mpCong:case mpTru:
			return 1;
		case mpSongSong:
			return 2;
		case mpNhan:case mpChia:
			return 3;
		default:
			return 4;
	}
}

int64_t isub(int64_t m,int muM, int64_t n, int muN, int* muKq){
	if(muM>muN){
		n=ipow10(n, muN-muM);
		*muKq=muM;
	}else{
		m=ipow10(m, muM-muN);
		*muKq=muN;
	}
	m=m-n;
	if(iabs(m)>=1000000000){
		m/=10;
		*muKq+=1;
	}
	if(*muKq>99){
		ol=-1;
		return m;
	}
	int i=1;
	for(; i<=9; i++){
		if(iabs(m)<pow(10,i)){
			m=ipow10(m,9-i);					
			break;
		}
	}
	*muKq=*muKq-(9-i);		
	return m;
}

int64_t iadd(int64_t m,int muM, int64_t n, int muN, int* muKq){
	if(muM>muN){
		n=ipow10(n, muN-muM);
		*muKq=muM;
	}else{
		m=ipow10(m, muM-muN);
		*muKq=muN;
	}
	m=m+n;
	if(iabs(m)>=1000000000){
		m/=10;
		*muKq+=1;
	}
	
	if(*muKq>99){
		ol=-1;
		return m;
	}
	
	int i=1;
	for(; i<=9; i++){
		if(iabs(m)<pow(10,i)){
			m=ipow10(m,9-i);					
			break;
		}
	}
	*muKq=*muKq-(9-i);		
	return m;
}

int64_t imul(int64_t m,int muM, int64_t n, int muN, int* muKq){
	m=m*n/100000000;					//1e8
	muM+=muN;
	if(iabs(m)>=1000000000){			//1e9
		m/=10;
		muM+=1;
	}	
	*muKq=muM;
	if(*muKq>99){
		ol=-1;
		return m;
	}
	return m;
}

int64_t idiv(int64_t m,int muM, int64_t n, int muN, int* muKq){
	if(n==0){
		div0=-1;
		return n;
	}
	m=m*1000000000/n;					//1e9
	muM=muM-muN-1;
	if(iabs(m)>=1000000000){			//1e9
		m/=10;
		muM+=1;
	}	
	*muKq=muM;
	if(*muKq>99){
		ol=-1;
		return m;
	}
	return m;
}

int64_t iinv(int64_t m,int muM, int* muKq){
	if(m==0){
		div0=-1;
		return m;
	}	
	*muKq=-muM-1;
	if(*muKq>99){
		ol=-1;
		return m;
	}
	return 100000000000000000/m;		//1e17	
}

int64_t isqrt(int64_t m, int muM, int* muKq){
	if(m==0) return 0;
	if(m<0){
		can2am=-1;
		return m;
	}

	uint64_t xk0,xk=m,xk1;
	int muXk0,muXk=muM,muXk1;
	do{
		xk0=xk;
		muXk0=muXk;
		xk1=idiv(m,muM,xk,muXk,&muXk1);
		xk=iadd(xk,muXk,xk1,muXk1,&muXk);
		xk=idiv(xk,muXk,200000000,0,&muXk);
	}while((xk!=xk0)||(muXk!=muXk0));
	*muKq=muXk;
	if(*muKq>99){
		ol=-1;
		return m;
	}
	return xk;
}

int64_t iroot3(int64_t m, int muM, int* muKq){
	if(m==0) return 0;
	uint64_t xk0,xk=m,xk1;
	int muXk0,muXk=muM,muXk1;
	do{
		xk0=xk;
		muXk0=muXk;
		xk1=imul(xk,muXk,xk,muXk,&muXk1);
		xk1=idiv(m,muM,xk1,muXk1,&muXk1);
		xk=imul(200000000,0,xk,muXk,&muXk);
		xk=iadd(xk,muXk,xk1,muXk1,&muXk);
		xk=idiv(xk,muXk,300000000,0,&muXk);
	}while((xk!=xk0)||(muXk!=muXk0));
	*muKq=muXk;
	if(*muKq>99){
		ol=-1;
		return m;
	}
	return xk;
}

void XoaByte(uint8_t *mang, int vt){
	int i=vt;
	for(; mang[i+1]!=RONG; i++)
		mang[i]=mang[i+1];
	mang[i]=RONG;
}

int64_t ipow10(int64_t so, int mu){
	if(mu<0)
		for(int i=0;i<-mu;i++)
			so/=10;
	else
		for(int i=0;i<mu; i++)
			so*=10;		
	return so;
}
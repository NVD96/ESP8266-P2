/********************************************************/
// CPU��Ҫ��STM32F103--RAM�ڴ治С��48K	Flash�ڴ治С��256K
// ����������STM32F103RDT6��VET6����ͨ��

/********************************************************/


#include "stm32f10x.h"
#include "stm32f10x_flash.h"
#include <stdio.h>
#include <absacc.h> 
#include "usart.h"
#include <stdarg.h>
#include "PLC_Dialogue.h"


#define C235 PLC_RAM32(0X20005C90)   
#define C236 PLC_RAM32(0X20005C94)
#define C237 PLC_RAM32(0X20005C98)
#define C238 PLC_RAM32(0X20005C9C)
#define C239 PLC_RAM32(0x20005CA0)
#define C240 PLC_RAM32(0X20005CA4)

#define C241 PLC_RAM32(0X20005CA8)
#define C242 PLC_RAM32(0X20005CAC)
#define C243 PLC_RAM32(0X20005CB0)
#define C244 PLC_RAM32(0X20005CB4)
#define C245 PLC_RAM32(0X20005CB8)

#define C246 PLC_RAM32(0X20005CBC)
#define C247 PLC_RAM32(0X20005CC0)
#define C248 PLC_RAM32(0X20005CC4)
#define C249 PLC_RAM32(0X20005CC8)
#define C250 PLC_RAM32(0X20005CCC)



#define M8235 (plc_16BitBuf[0XEE]&0x800)
#define M8236 (plc_16BitBuf[0XEE]&0x1000)
#define M8237 (plc_16BitBuf[0XEE]&0x2000)
#define M8238 (plc_16BitBuf[0XEE]&0x4000)
#define M8239 (plc_16BitBuf[0XEE]&0x8000)
#define M8240 (plc_16BitBuf[0XEF]&0x01)
#define M8241 (plc_16BitBuf[0XEF]&0x02)
#define M8242 (plc_16BitBuf[0XEF]&0x04)
#define M8243 (plc_16BitBuf[0XEF]&0x08)
#define M8244 (plc_16BitBuf[0XEF]&0x10)
#define M8245 (plc_16BitBuf[0XEF]&0x20)



#define X2 (plc_16BitBuf[0X120]&0x04)
#define X5 (plc_16BitBuf[0X120]&0x20)
#define X6 (plc_16BitBuf[0X120]&0x40)
#define X7 (plc_16BitBuf[0X120]&0x80)



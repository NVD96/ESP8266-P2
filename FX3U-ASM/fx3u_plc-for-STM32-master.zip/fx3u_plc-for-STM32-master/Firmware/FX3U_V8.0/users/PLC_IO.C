/********************************************************/
// CPU��Ҫ��STM32F103--RAM�ڴ治С��64K	Flash�ڴ治С��128K


#include "PLC_IO.h"
#include "stm32f10x.h"
#include <stdio.h>
#include "absacc.h" 
#include "PLC_Dialogue.h"
#include "plc_conf.h"


uint8_t powerDownFlg =0;  // �ϵ����־
volatile uint8_t powerDownCnt =0;  // ���籣���ʱ


bit_byte x_in[2],y_out[2]; 
u8  X_DIY=10;	//ָ���޸��˲�ʱ��X000-X007


#if POWER_DOWN_WAY ==1	
void EXTI9_5_IRQHandler(void)
{
	if((EXTI->IMR & EXTI->PR & EXTI_Line8) != 0)
	{
		powerDownFlg = 0x01; // ��Ǽ�⵽��ѹ����
		EXTI->PR = EXTI_Line8; // ������ж�
	}
}
#endif /* #if POWER_DOWN_WAY ==0 */


//======================================================================================================
// ��������:  void PLC_X_config(void)   
// ���������� PLC_����״̬IO��ʼ��
// �䡡��:   void  
// �䡡��:   void   
// ȫ�ֱ���:  

//------------------------------------------------------------------------------------------------------
// �޸���:
// �ա���:
// ��  ע: JTAG/SWD��PA13:JTMS/SWDIO��PA14:JTCK/SWCLK��PA15/JTDI��PB3��JTDO/TRACESWO��PB4��JNTRST��
//=======================================================================================================
void PLC_Mode_config(void)
{ 
	GPIO_InitTypeDef GPIO_InitStructure;
	
  // GPIO_PinRemapConfig(GPIO_Remap_SWJ_Disable , ENABLE);  //��ȫ���ã�JTAG+SW-DP�� 
  GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable , ENABLE); //JTAG-DP ���� + SW-DP ʹ�� 


	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;	// SHUTDOWN
	GPIO_InitStructure.GPIO_Mode =  GPIO_Mode_IN_FLOATING;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_Init(GPIOA,&GPIO_InitStructure);
	
#if POWER_DOWN_WAY ==1	
{
	EXTI_InitTypeDef EXTI_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOC, GPIO_PinSource8);	
	EXTI_ClearITPendingBit(EXTI_Line8);
  EXTI_InitStructure.EXTI_Line = EXTI_Line8;
  EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
  EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;  // �����ж�
  EXTI_InitStructure.EXTI_LineCmd = ENABLE;
  EXTI_Init(&EXTI_InitStructure);
	
//	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_3);
	NVIC_InitStructure.NVIC_IRQChannel = EXTI9_5_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);
}
#endif /* #if POWER_DOWN_WAY ==0 */

//	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;	// RUN/STOP_SWITCH
//	GPIO_InitStructure.GPIO_Mode =  GPIO_Mode_IN_FLOATING;
//	GPIO_InitStructure.GPIO_Mode =  GPIO_Mode_IPU;
//	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
//	GPIO_Init(GPIOA,&GPIO_InitStructure);

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7 | GPIO_Pin_8 | GPIO_Pin_9; // RUN LAMP ERR_LAMP �� LCD POWER
	GPIO_InitStructure.GPIO_Mode =  GPIO_Mode_Out_OD;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_Init(GPIOE,&GPIO_InitStructure);
	LCD_POWER_ON;// ������

}

//======================================================================================================
// ��������:  void PLC_X_config(void)   
// ���������� PLC_X_�����ʼ��
// �䡡��:   void  
// �䡡��:   void   
// ȫ�ֱ���:  
// ����ģ��: 
// ������:  ���˼�
// �ա���:  2014��6��13��
// ��  ע:  
/* 28����
X0��PC7��X1��PD15��X2:PD14��X3:PD13��X4:PD12��X5:PD11��X6��PD10��X7:PD9
X10:PD8��X11��PDB15��X12:PB14��X13:PB13��X14��PB12��X15:PB11��X16:PB10��X17:PE15
X20:PE14��X21:PE13��X22:PE12��X23:PE11��X24:PE10��X25:PE10��X26:PE10��X27:PE10
X30:PE10��X31:PE10��X32:PE10��X33:PE10
*/
//------------------------------------------------------------------------------------------------------
// �޸���:
// �ա���:
// ��  ע: JTAG/SWD��PA13:JTMS/SWDIO��PA14:JTCK/SWCLK��PA15/JTDI��PB3��JTDO/TRACESWO��PB4��JNTRST��
//=======================================================================================================
void PLC_X_config(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	
	/* X3:PA1��X4:PA0��X7:PA6��X6��PA7��X34��PA3 */
//	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8 ;	
//	GPIO_InitStructure.GPIO_Mode =  GPIO_Mode_IN_FLOATING;
//	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
//	GPIO_Init(GPIOA,&GPIO_InitStructure);
	/*PA4: X37*/
#if DAC_FUNC ==0
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_4|GPIO_Pin_5;
	GPIO_InitStructure.GPIO_Mode =  GPIO_Mode_IN_FLOATING;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
	GPIO_Init(GPIOA,&GPIO_InitStructure);
#endif 
	
	/* X2:PB15��X20:PB14��X21:PB13��X22:PB12  */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10 |GPIO_Pin_11 |GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14 |GPIO_Pin_15;
	GPIO_InitStructure.GPIO_Mode =  GPIO_Mode_IN_FLOATING;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
	GPIO_Init(GPIOB,&GPIO_InitStructure);		
	
	/* X0��PC7��X1��PC6 */
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_6 ;
	GPIO_InitStructure.GPIO_Mode =  GPIO_Mode_IN_FLOATING;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
	GPIO_Init(GPIOC,&GPIO_InitStructure);
	
	/*PC0: X35 PC1: X36*/
#if ADC_FUNC ==0
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_0 | GPIO_Pin_1| GPIO_Pin_2| GPIO_Pin_3| GPIO_Pin_6| GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Mode =  GPIO_Mode_IN_FLOATING;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
	GPIO_Init(GPIOA,&GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_0 | GPIO_Pin_1;
	GPIO_InitStructure.GPIO_Mode =  GPIO_Mode_IN_FLOATING;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
	GPIO_Init(GPIOB,&GPIO_InitStructure);
  
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_0 | GPIO_Pin_1| GPIO_Pin_2| GPIO_Pin_3| GPIO_Pin_4| GPIO_Pin_5;
	GPIO_InitStructure.GPIO_Mode =  GPIO_Mode_IN_FLOATING;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
	GPIO_Init(GPIOC,&GPIO_InitStructure);
#endif 

	/* X10:PD15��X11��PD14��X12:PD13��X13:PD12��X14��PD11��X15:PD10��X16:PD9��X17:PD8 */
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_10 | GPIO_Pin_11 | GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14 | GPIO_Pin_15;
	GPIO_InitStructure.GPIO_Mode =  GPIO_Mode_IN_FLOATING;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
	GPIO_Init(GPIOD,&GPIO_InitStructure);

  /* X23:PE15��X24:PE14��X25:PE13��X26:PE12��X27:PE11����X30:PE10��X31:PE9��X32:PE8��X33:PE7�� */
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_10 | GPIO_Pin_11 | GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14 | GPIO_Pin_15 ;
	GPIO_InitStructure.GPIO_Mode =  GPIO_Mode_IN_FLOATING;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_Init(GPIOE,&GPIO_InitStructure);

}

//======================================================================================================
// ��������:  PLC_Y_config(void)   
// ���������� PLC_Y_�����ʼ��
// �䡡��:   void  
// �䡡��:   void   
// ȫ�ֱ���:  
// ����ģ��: 
// ������:  ���˼�
// �ա���:  2014��6��13��
// ��  ע:  
/* 30���
Y0:PC9��Y1:PA11��Y2:PC8��Y3:PC7 ��Y4:PA12 ��Y5:PA15��Y6��PC12��Y7��PD0
Y10:PD1��Y11:PD2��Y12:PD3��Y13:PD4��Y14:PD5��Y15:PD6��Y16:PD7��Y17��PB3
Y20:PB4��Y21:PB5��Y22:PB6��Y23:PB7��Y24:PE0��Y25:PE1��Y26:PE2��Y27��PE3
Y30:PE4��Y31:PE5��Y32:PE6��Y33:PC13��Y34:PC13��Y35:PC13
*/
//------------------------------------------------------------------------------------------------------
// �޸���:
// �ա���:
// ��  ע: JTAG/SWD��PA13:JTMS/SWDIO��PA14:JTCK/SWCLK��PA15/JTDI��PB3��JTDO/TRACESWO��PB4��JNTRST��
//=======================================================================================================
void PLC_Y_config(void)
{ 	
	GPIO_InitTypeDef GPIO_InitStructure;
	
	/* Y1:PA11��Y4:PA12��Y5:PA15 */
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_11 | GPIO_Pin_12 | GPIO_Pin_15;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOA, &GPIO_InitStructure);	
	
	/* Y17��PB3��Y20:PB4��Y21:PB5��Y22:PB6��Y23:PB7��Y24:PB8��Y25:PB9 ��Y36:PB10��Y37:PB11 */ 
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7 ;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	/* Y0:PC9��Y2:PC8��Y3:PC3��Y6��PC12��Y35:PC13 */
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_7 | GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_12 | GPIO_Pin_13;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOC, &GPIO_InitStructure);
	
	/* Y7��PD0��Y10:PD1��Y11:PD2��Y12:PD3��Y13:PD4��Y14:PD5��Y15:PD6��Y16:PD7 */
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7 ;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOD, &GPIO_InitStructure);
	
		/* Y26:PE0��Y27��PE1��Y30:PE2��Y31:PE3��Y32:PE4��Y33:PE5��Y34:PE6 */
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_0 | GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5 |  GPIO_Pin_6;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOE, &GPIO_InitStructure);
}

void X_filter(void)			           //ÿ��1ms  �����һ�Σ�����X�˲����ݶ�Ϊ20MS
{	 
	static signed char x_buffer[33];   //�ݶ�ˢ��32��X 

	(X00) ? (x_buffer[0]=0,x_in[0].bits.bit0=0) : (x_buffer[0]<D8020) ? (x_buffer[0]++) : (x_in[0].bits.bit0=1);
	(X01) ? (x_buffer[1]=0,x_in[0].bits.bit1=0) : (x_buffer[1]<D8020) ? (x_buffer[1]++) : (x_in[0].bits.bit1=1);	
	(X02) ? (x_buffer[2]=0,x_in[0].bits.bit2=0) : (x_buffer[2]<D8020) ? (x_buffer[2]++) : (x_in[0].bits.bit2=1);	
	(X03) ? (x_buffer[3]=0,x_in[0].bits.bit3=0) : (x_buffer[3]<D8020) ? (x_buffer[3]++) : (x_in[0].bits.bit3=1);	
	(X04) ? (x_buffer[4]=0,x_in[0].bits.bit4=0) : (x_buffer[4]<D8020) ? (x_buffer[4]++) : (x_in[0].bits.bit4=1);	
	(X05) ? (x_buffer[5]=0,x_in[0].bits.bit5=0) : (x_buffer[5]<D8020) ? (x_buffer[5]++) : (x_in[0].bits.bit5=1);	
	(X06) ? (x_buffer[6]=0,x_in[0].bits.bit6=0) : (x_buffer[6]<D8020) ? (x_buffer[6]++) : (x_in[0].bits.bit6=1);	
	(X07) ? (x_buffer[7]=0,x_in[0].bits.bit7=0) : (x_buffer[7]<D8020) ? (x_buffer[7]++) : (x_in[0].bits.bit7=1);
	
	(X10) ? (x_buffer[8]=0,x_in[0].bits.bit10=0) : (x_buffer[8]<D8020) ? (x_buffer[8]++) : (x_in[0].bits.bit10=1);
	(X11) ? (x_buffer[9]=0,x_in[0].bits.bit11=0) : (x_buffer[9]<D8020) ? (x_buffer[9]++) : (x_in[0].bits.bit11=1);	
	(X12) ? (x_buffer[10]=0,x_in[0].bits.bit12=0) : (x_buffer[10]<D8020) ? (x_buffer[10]++) : (x_in[0].bits.bit12=1);	
	(X13) ? (x_buffer[11]=0,x_in[0].bits.bit13=0) : (x_buffer[11]<D8020) ? (x_buffer[11]++) : (x_in[0].bits.bit13=1);	
	(X14) ? (x_buffer[12]=0,x_in[0].bits.bit14=0) : (x_buffer[12]<D8020) ? (x_buffer[12]++) : (x_in[0].bits.bit14=1);	
 	(X15) ? (x_buffer[13]=0,x_in[0].bits.bit15=0) : (x_buffer[13]<D8020) ? (x_buffer[13]++) : (x_in[0].bits.bit15=1);	
	(X16) ? (x_buffer[14]=0,x_in[0].bits.bit16=0) : (x_buffer[14]<D8020) ? (x_buffer[14]++) : (x_in[0].bits.bit16=1);	
	(X17) ? (x_buffer[15]=0,x_in[0].bits.bit17=0) : (x_buffer[15]<D8020) ? (x_buffer[15]++) : (x_in[0].bits.bit17=1);

	(X20) ? (x_buffer[16]=0,x_in[1].bits.bit0=0) : (x_buffer[16]<D8020) ? (x_buffer[16]++) : (x_in[1].bits.bit0=1);
	(X21) ? (x_buffer[17]=0,x_in[1].bits.bit1=0) : (x_buffer[17]<D8020) ? (x_buffer[17]++) : (x_in[1].bits.bit1=1);	
	(X22) ? (x_buffer[18]=0,x_in[1].bits.bit2=0) : (x_buffer[18]<D8020) ? (x_buffer[18]++) : (x_in[1].bits.bit2=1);	
	(X23) ? (x_buffer[19]=0,x_in[1].bits.bit3=0) : (x_buffer[19]<D8020) ? (x_buffer[19]++) : (x_in[1].bits.bit3=1);	
	(X24) ? (x_buffer[20]=0,x_in[1].bits.bit4=0) : (x_buffer[20]<D8020) ? (x_buffer[20]++) : (x_in[1].bits.bit4=1);	
	(X25) ? (x_buffer[21]=0,x_in[1].bits.bit5=0) : (x_buffer[21]<D8020) ? (x_buffer[21]++) : (x_in[1].bits.bit5=1);	
	(X26) ? (x_buffer[22]=0,x_in[1].bits.bit6=0) : (x_buffer[22]<D8020) ? (x_buffer[22]++) : (x_in[1].bits.bit6=1);	
	(X27) ? (x_buffer[23]=0,x_in[1].bits.bit7=0) : (x_buffer[23]<D8020) ? (x_buffer[23]++) : (x_in[1].bits.bit7=1);
  (X30) ? (x_buffer[24]=0,x_in[1].bits.bit10=0) : (x_buffer[24]<D8020) ? (x_buffer[24]++) : (x_in[1].bits.bit10=1);
  (X31) ? (x_buffer[25]=0,x_in[1].bits.bit11=0) : (x_buffer[25]<D8020) ? (x_buffer[25]++) : (x_in[1].bits.bit11=1);	
  (X32) ? (x_buffer[26]=0,x_in[1].bits.bit12=0) : (x_buffer[26]<D8020) ? (x_buffer[26]++) : (x_in[1].bits.bit12=1);	
  (X33) ? (x_buffer[27]=0,x_in[1].bits.bit13=0) : (x_buffer[27]<D8020) ? (x_buffer[27]++) : (x_in[1].bits.bit13=1);	
  (X34) ? (x_buffer[28]=0,x_in[1].bits.bit14=0) : (x_buffer[28]<D8020) ? (x_buffer[28]++) : (x_in[1].bits.bit14=1);
#if ADC_FUNC ==0	
  (X35) ? (x_buffer[29]=0,x_in[1].bits.bit15=0) : (x_buffer[29]<D8020) ? (x_buffer[29]++) : (x_in[1].bits.bit15=1);	
  (X36) ? (x_buffer[30]=0,x_in[1].bits.bit16=0) : (x_buffer[30]<D8020) ? (x_buffer[30]++) : (x_in[1].bits.bit16=1);	
#endif
#if DAC_FUNC ==0
  (X37) ? (x_buffer[31]=0,x_in[1].bits.bit17=0) : (x_buffer[31]<D8020) ? (x_buffer[31]++) : (x_in[1].bits.bit17=1);
#endif 

  plc_16BitBuf[64] = x_in[0].bytes ; // X0 ~X17
	plc_16BitBuf[65] = x_in[1].bytes ;// X20 ~ X37
}


//ˢ�������һ����ַΪ32����
void PLC_IO_Refresh(void)         
{
  y_out[0].bytes =plc_16BitBuf[80]; // Y0~ Y17;
	y_out[1].bytes =plc_16BitBuf[81]; // Y20 ~ Y37

	Y00=y_out[0].bits.bit0;
	Y01=y_out[0].bits.bit1;
	Y02=y_out[0].bits.bit2;
	Y03=y_out[0].bits.bit3;
	Y04=y_out[0].bits.bit4;
	Y05=y_out[0].bits.bit5;
	
	Y06=y_out[0].bits.bit6;
	Y07=y_out[0].bits.bit7;
	Y10=y_out[0].bits.bit10;
	Y11=y_out[0].bits.bit11;
	Y12=y_out[0].bits.bit12;
	Y13=y_out[0].bits.bit13;
	Y14=y_out[0].bits.bit14;
	Y15=y_out[0].bits.bit15;
	Y16=y_out[0].bits.bit16;
	Y17=y_out[0].bits.bit17;

	Y20=y_out[1].bits.bit0;
	Y21=y_out[1].bits.bit1;
	Y22=y_out[1].bits.bit2;
	Y23=y_out[1].bits.bit3;
	Y24=y_out[1].bits.bit4;
	Y25=y_out[1].bits.bit5;
	Y26=y_out[1].bits.bit6;
	Y27=y_out[1].bits.bit7;
	Y30=y_out[1].bits.bit10;
	Y31=y_out[1].bits.bit11;
	Y32=y_out[1].bits.bit12;
	Y33=y_out[1].bits.bit13;			
  Y34=y_out[1].bits.bit14;
	Y35=y_out[1].bits.bit15;
	Y36=y_out[1].bits.bit16;
	Y37=y_out[1].bits.bit17;		
}



void PLC_IO_config(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA|RCC_APB2Periph_GPIOB|RCC_APB2Periph_GPIOC|
	                       RCC_APB2Periph_GPIOD|RCC_APB2Periph_GPIOE, ENABLE);
	
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO , ENABLE);//RCC_APB2Periph_AFIO

    PLC_Y_config(); 
    PLC_IO_Refresh(); //ˢ��Y���                            
    PLC_X_config();
	  PLC_Mode_config();
		ERR_LAMP_OFF;	
//	  GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDiable,ENABLE);
}

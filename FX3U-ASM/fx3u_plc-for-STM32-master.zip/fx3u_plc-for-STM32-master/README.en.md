# FX3U_PLC for STM32

#### Description
STM32仿FX3U PLC控制器，可以直接使用GX Works2编程直接写入，用梯形图语言编写应用程序，可以直接使用三菱编程软件GX Developer 或者GX Works2编程、下载、调试、监视。

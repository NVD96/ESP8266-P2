/*
 * app_cli.h
 *
 * Created: 10/29/2021 3:20:02 PM
 *  Author: phuoc
 */ 
#ifndef _APP_CLI_H_
#define _APP_CLI_H_

#include "ftr_cli.h"
#include "ftr_sensor.h"
#include "sys_task.h"
#include "ds1307.h"

void app_cli_init(void);

#endif
/*
 * app_display.h
 *
 * Created: 10/29/2021 3:21:44 PM
 *  Author: phuoc
 */ 
#include "lcd_i2c.h"
#include "ds1307.h"
#include "sys_task.h"
#include "sys_timer.h"

void app_display_init(void);

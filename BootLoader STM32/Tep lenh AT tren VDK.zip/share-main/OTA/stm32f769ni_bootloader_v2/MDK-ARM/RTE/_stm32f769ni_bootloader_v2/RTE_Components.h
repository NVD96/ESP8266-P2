
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'stm32f769ni_bootloader_v2' 
 * Target:  'stm32f769ni_bootloader_v2' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "stm32f7xx.h"



#endif /* RTE_COMPONENTS_H */

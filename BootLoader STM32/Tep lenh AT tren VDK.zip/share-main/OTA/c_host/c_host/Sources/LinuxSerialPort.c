
#include "main.h"

#ifdef LINUX_HOST

/* If you are here, then you may be trying to run this STM32_Programmer Application on Linux Host.
   Note1 : This file should implement the functions mentioned in the "LinuxSerialPort.h"
   Note2 : Take a reference from the source file "WindowsSerialPort.c
 */

 #include "LinuxSerialPort.h"

/* Code Begin */



/* Code End */

 #endif

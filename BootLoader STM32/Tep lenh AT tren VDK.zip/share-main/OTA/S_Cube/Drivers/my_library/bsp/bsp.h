#ifndef _BSP_H_
#define _BSP_H_

#include "main.h"

typedef enum
{
	NO_ERROR 						= 0,
	UART_INVALID_INPUT,
	ERROR_TX,	
} error_code_t;

#endif

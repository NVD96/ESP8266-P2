#ifndef _APP_CLI_H_
#define _APP_CLI_H_

#include "ftr_cli.h"
#include "sys_task.h"

void app_cli_init(void);

#endif

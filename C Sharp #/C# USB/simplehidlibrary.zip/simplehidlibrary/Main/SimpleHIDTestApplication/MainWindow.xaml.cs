﻿using SimpleHIDTestApplication.ViewModel;
using Microsoft.Windows.Controls.Ribbon;

namespace SimpleHIDTestApplication
{
  /// <summary>
  /// Interaction logic for MainWindow.xaml
  /// </summary>
  public partial class MainWindow : RibbonWindow
  {
    /// <summary>
    /// Initializes a new instance of the MainWindow class.
    /// </summary>
    public MainWindow()
    {
      InitializeComponent();
      Closing += (s, e) => ViewModelLocator.Cleanup();
    }
  }
}
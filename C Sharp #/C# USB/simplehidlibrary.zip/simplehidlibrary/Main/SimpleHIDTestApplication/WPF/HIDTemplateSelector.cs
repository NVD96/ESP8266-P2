﻿using System.Windows;
using System.Windows.Controls;
using SimpleHID.Report;

namespace SimpleHIDTestApplication.WPF
{
  public class HIDTemplateSelector : DataTemplateSelector
  {
    public DataTemplate ButtonTemplate { get; set; }
    public DataTemplate RangeTemplate { get; set; }

    public override DataTemplate SelectTemplate(object item, DependencyObject container)
    {
      if (item is ButtonItem) return ButtonTemplate;
      if (item is ButtonRangeItem) return RangeTemplate;
      return null;
    }
  }
}

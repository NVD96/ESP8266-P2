﻿using System.Collections.Generic;
using System.Linq;
using SimpleHID;

namespace SimpleHIDTestApplication.Model
{
  internal class Model
  {
    public HIDDevice Device { get; set; }

    public List<HIDInfoSet> GetDevices()
    {
      return HIDManager.GetInfoSets().ToList();
    }
  }
}

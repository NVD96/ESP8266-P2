﻿using System.Windows;
using GalaSoft.MvvmLight.Messaging;
using GalaSoft.MvvmLight.Threading;

namespace SimpleHIDTestApplication
{
  /// <summary>
  /// Interaction logic for App.xaml
  /// </summary>
  public partial class App : Application
  {
    App()
    {
      DispatcherHelper.Initialize();

      RegisterPopups();
    }

    /// <summary>
    /// Register popups in the MVVM Light framework
    /// </summary>
    private void RegisterPopups()
    {
      // Message box
      Messenger.Default.Register<DialogMessage>(this, (s) =>
                                                        {
                                                          var m = MessageBox.Show(s.Content, s.Caption, s.Button);
                                                          s.ProcessCallback(m);
                                                        });
    }
  }
}

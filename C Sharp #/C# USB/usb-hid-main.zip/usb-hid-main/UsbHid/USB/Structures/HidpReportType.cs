namespace UsbHid.USB.Structures
{
    public enum HidpReportType
    {
        HidPInput,	// 0 input
        HidPOutput,	// 1 output
        HidPFeature	// 2 feature
    }
}
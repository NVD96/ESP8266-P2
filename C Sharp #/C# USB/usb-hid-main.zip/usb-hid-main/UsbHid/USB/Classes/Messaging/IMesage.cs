namespace UsbHid.USB.Classes.Messaging
{
    public interface IMesage
    {
        byte[] MessageData { get; }
    }
}
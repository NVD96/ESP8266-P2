//-----------------------------------------------------------------------------
//
//  GenericHID.c
//
//  WFF UDB GenericHID Reference Firmware (4_0)
//  A reference firmware for the WFF GenericHID Communication Library
//
//  Copyright (c) 2011 Simon Inns
//
//  Permission is hereby granted, free of charge, to any person obtaining a
//  copy of this software and associated documentation files (the "Software"),
//  to deal in the Software without restriction, including without limitation
//  the rights to use, copy, modify, merge, publish, distribute, sublicense,
//  and/or sell copies of the Software, and to permit persons to whom the
//  Software is furnished to do so, subject to the following conditions:
//
//  The above copyright notice and this permission notice shall be included in
//  all copies or substantial portions of the Software.
//
//  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
//  FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
//  DEALINGS IN THE SOFTWARE.
//
//  Web:    http://www.waitingforfriday.com
//  Email:  simon.inns@gmail.com
//
//-----------------------------------------------------------------------------

#include "GenericHID.h"

// Success indication globals (used to keep the success LED on so you can see it)
int16_t successIndicatorCounter = 0;
uint8_t successIndicatorFlag = false;

// Failure indication globals (used to keep the failure LED on so you can see it)
int16_t failureIndicatorCounter = 0;
uint8_t failureIndicatorFlag = false;

// Globals for bulk packet reception
int16_t bulkRxExpectedPackets = 0;
int16_t bulkRxCurrentPacket = 0;
uint8_t bulkRxModeFlag = false;
uint8_t bulkRxCommandNumber;

// Global for forming debug output strings using sprintf
char debugString[24];

// Main program entry point
int main(void)
{
	setupHardware();

	LEDs_TurnOffLEDs(LEDS_LED1 | LEDS_LED2 | LEDS_LED3 | LEDS_LED4);
	sei();

	// Output the firmware version
	sprintf(debugString, "USB Generic HID Reference Firmware 4_0 (ATmega32U4)");
	debugOut(debugString);

	// Output the copyright information
	sprintf(debugString, "(C)2011 Simon Inns - http://www.waitingforfriday.com");
	debugOut(debugString);

	// Mention Dean's USB library because it's cool and open-source
	sprintf(debugString, "LUFA library by Dean Camera - http://fourwalledcubicle.com");
	debugOut(debugString);

	for (;;)
	{
		// Poll the USB tasks
 		USB_USBTask();
		
		// Check to see if the success indicator LED is on and update the delay counter
		if (successIndicatorFlag == true)
		{
			LEDs_TurnOnLEDs(LEDS_LED2);
			successIndicatorCounter++;
		
			if (successIndicatorCounter == 30000)
			{
				LEDs_TurnOffLEDs(LEDS_LED2);
				successIndicatorCounter = 0;
				successIndicatorFlag = false;
			}
		}
    
		// Check to see if the failure indicator LED is on and update the delay counter
		if (failureIndicatorFlag == true)
		{
			LEDs_TurnOnLEDs(LEDS_LED3);
			failureIndicatorCounter++;
		
			if (failureIndicatorCounter == 60000)
			{
				LEDs_TurnOffLEDs(LEDS_LED3);
				failureIndicatorCounter = 0;
				failureIndicatorFlag = false;
			}
		}
	}
}

// Setup the hardware
void setupHardware(void)
{
	// Disable watchdog if enabled by boot-loader/fuses
	MCUSR &= ~(1 << WDRF);
	wdt_disable();

	// Disable clock division
	clock_prescale_set(clock_div_1);

	// Hardware Initialization
	debugInitialise();
	LEDs_Init();
	USB_Init();
}

// USB Device connected event handler
void EVENT_USB_Device_Connect(void)
{
	// Indicate USB enumerating
	sprintf(debugString, "USB Device enumerating");
	debugOut(debugString);
}

// USB Device disconnected event handler
void EVENT_USB_Device_Disconnect(void)
{
	// Indicate USB not ready
	LEDs_TurnOffLEDs(LEDS_LED1 | LEDS_LED2 | LEDS_LED3 | LEDS_LED4);
	sprintf(debugString, "USB Device disconnected");
	debugOut(debugString);
}

// Event handler for the USB_ConfigurationChanged event
void EVENT_USB_Device_ConfigurationChanged(void)
{
	bool ConfigSuccess = true;

	// Setup HID Report Endpoints
	ConfigSuccess &= Endpoint_ConfigureEndpoint(GENERIC_IN_EPNUM, EP_TYPE_INTERRUPT, ENDPOINT_DIR_IN,
	                                            GENERIC_EPSIZE, ENDPOINT_BANK_SINGLE);
	ConfigSuccess &= Endpoint_ConfigureEndpoint(GENERIC_OUT_EPNUM, EP_TYPE_INTERRUPT, ENDPOINT_DIR_OUT,
	                                            GENERIC_EPSIZE, ENDPOINT_BANK_SINGLE);

	// Indicate endpoint configuration success or failure
	if (ConfigSuccess)
	{
		LEDs_TurnOnLEDs(LEDS_LED1);
		sprintf(debugString, "USB endpoint configuration successful");
		debugOut(debugString);
	}		
	else
	{
		LEDs_TurnOffLEDs(LEDS_LED1 | LEDS_LED2 | LEDS_LED3 | LEDS_LED4);
		sprintf(debugString, "USB endpoint configuration failed");
		debugOut(debugString);
	}		
}

// Event handler for the USB_ControlRequest event
void EVENT_USB_Device_ControlRequest(void)
{
	// Handle HID Class specific requests
	
	// Note: For all tests we expect to receive a 64 byte packet containing
	// the command in byte[0] and then the numbers 0-62 in bytes 1-63.
	uint8_t bufferPointer;
    uint8_t expectedData;
    uint8_t dataReceivedOk;
	
	int16_t bulkTxPacketCounter = 0;

	// This is called if the host is waiting for a report from the device.  This functionality is not used
	// in the generic HID framework but is kept for compatibility with LUFA (bulk sending and receiving is
	// an atomic operation dealt with when the initial command packet is received below).
	if (USB_ControlRequest.bRequest == HID_REQ_GetReport)
	{
		if (USB_ControlRequest.bmRequestType == (REQDIR_DEVICETOHOST | REQTYPE_CLASS | REQREC_INTERFACE))
		{
			uint8_t GenericData[GENERIC_REPORT_SIZE];
			//CreateGenericHIDReport(GenericData);

			Endpoint_ClearSETUP();
			
			sprintf(debugString, "Error: USB_ControlRequest.bRequest == HID_REQ_GetReport?");
			debugOut(debugString);

			/* Write the report data to the control endpoint */
			//Endpoint_Write_Control_Stream_LE(&GenericData, sizeof(GenericData));
			Endpoint_ClearOUT();
		}
	}
	
	// Do we have a command request from the host?
	if (USB_ControlRequest.bRequest == HID_REQ_SetReport)
	{		
		// Ensure this is the type of report we are interested in
		if (USB_ControlRequest.bmRequestType == (REQDIR_HOSTTODEVICE | REQTYPE_CLASS | REQREC_INTERFACE))
		{
			// Note: the endpoints are from the perspective of the host: OUT is 'out from host' and IN is 'in to host'
			
			// Declare our send and receive buffers
			char hidReceiveBuffer[GENERIC_REPORT_SIZE];
			char hidSendBuffer[GENERIC_REPORT_SIZE];

			// Clear the SETUP endpoint
			Endpoint_ClearSETUP();

			// Read the report data from the control endpoint
			Endpoint_Read_Control_Stream_LE(&hidReceiveBuffer, sizeof(hidReceiveBuffer));
			Endpoint_ClearIN();

			// If we are not in Bulk Rx mode interpret the packet as a command
			if (bulkRxModeFlag == false)
			{
				// Process GenericHID command packet
				switch(hidReceiveBuffer[0])
				{
					case 0x10:	// Debug information request from host
						// Select the IN end-point
						Endpoint_SelectEndpoint(GENERIC_IN_EPNUM);

						// Send a response to the host
						if (Endpoint_IsINReady())
						{
							// Copy any waiting debug text to the send data buffer
							copyDebugToSendBuffer((char*)&hidSendBuffer[0]);
					
							// Write the return packet data into the report
							Endpoint_Write_Stream_LE(&hidSendBuffer, sizeof(hidSendBuffer), NULL);

							// Finalize the stream transfer to send the last packet
							Endpoint_ClearOUT();
						}
						break;
					
					// Place application specific commands here:
				
					case 0x80:  // Test 1 - Single packet write from host to device
	            		sprintf(debugString, "** Received command 0x80 from host");
						debugOut(debugString);
	
	            		// Test the received data
	            		expectedData = 0;
	            		dataReceivedOk = true;
	            		for (bufferPointer = 1; bufferPointer < GENERIC_REPORT_SIZE; bufferPointer++)
	            		{
		            		if (hidReceiveBuffer[bufferPointer] != expectedData)
		            			dataReceivedOk = false;
		            	
		            		expectedData++;
						}
		            
						// Display the test result
						if (dataReceivedOk == true)
						{
			        		successIndicatorFlag = true;
			        		sprintf(debugString, "Successfully received 1 packet of data from command 0x80");
							debugOut(debugString);
						}
						else
						{
							failureIndicatorFlag = true;
							sprintf(debugString, "Failed to receive 1 packet of data from command 0x80");
							debugOut(debugString);
						} 
	            		break;
	            	
					case 0x81:	// Test 2 - Single packet write from host, single packet reply from device
	            		sprintf(debugString, "** Received command 0x81 from host");
						debugOut(debugString);
					
	            		// Test the received data
	            		expectedData = 0;
	            		dataReceivedOk = true;
	            		for (bufferPointer = 1; bufferPointer < GENERIC_REPORT_SIZE; bufferPointer++)
	            		{
		            		if (hidReceiveBuffer[bufferPointer] != expectedData)
		            			dataReceivedOk = false;
		            	
		            		expectedData++;
						}
		            
						// If we got the data correctly, send the response packet
						if (dataReceivedOk == true)
						{
							sprintf(debugString, "Successfully received 1 packet of data from command 0x81");
							debugOut(debugString);
				        
							// Select the IN end-point
							Endpoint_SelectEndpoint(GENERIC_IN_EPNUM);

							// Send a response to the host
							if (Endpoint_IsINReady())
							{
								// Create return packet data
								expectedData = 0;
								for (bufferPointer = 0; bufferPointer < GENERIC_REPORT_SIZE; bufferPointer++)
								{
									hidSendBuffer[bufferPointer] = expectedData;
									expectedData++;
								}

								// Write the return packet data into the report
								Endpoint_Write_Stream_LE(&hidSendBuffer, sizeof(hidSendBuffer), NULL);

								// Finalize the stream transfer to send the last packet
								Endpoint_ClearOUT();
							}

							sprintf(debugString, "Sent 1 packet of data to the host from command 0x81");
							debugOut(debugString);
						
							// Show our success
							successIndicatorFlag = true;
						}
						else
						{
							failureIndicatorFlag = true;
				        
							sprintf(debugString, "Failed to receive 1 packet of data from command 0x81");
							debugOut(debugString);
						} 
	            		break;
	            	
					case 0x82:	// Test 3 - Single packet write from host, 128 packets in reply from device
	            		sprintf(debugString, "** Received command 0x82 from host");
						debugOut(debugString);
					
						// Test the received data
	            		expectedData = 0;
	            		dataReceivedOk = true;
	            		for (bufferPointer = 1; bufferPointer < GENERIC_REPORT_SIZE; bufferPointer++)
	            		{
		            		if (hidReceiveBuffer[bufferPointer] != expectedData)
		            			dataReceivedOk = false;
		            	
		            		expectedData++;
						}
		            
						// If the receive was OK, go into bulk sending mode
						if (dataReceivedOk == true)
						{
							sprintf(debugString, "Successfully received 1 packet of data from command 0x82, now bulk sending");
							debugOut(debugString);
			            
							// Bulk send 128 reply packets to the host (128x64 bytes = 8Kbytes response with 64 byte packet size)
						
							// Select the IN end-point
							Endpoint_SelectEndpoint(GENERIC_IN_EPNUM);
						
							for (bulkTxPacketCounter = 0; bulkTxPacketCounter < 128; bulkTxPacketCounter++)
							{
								// Wait for the host IN endpoint to be ready
								while(!Endpoint_IsINReady());
							
								// Create return packet data
								for (bufferPointer = 0; bufferPointer < GENERIC_REPORT_SIZE; bufferPointer++)
								{
									hidSendBuffer[bufferPointer] = bulkTxPacketCounter;
								}

								// Write the return packet data into the report
								Endpoint_Write_Stream_LE(&hidSendBuffer, sizeof(hidSendBuffer), NULL);

								// Finalize the stream transfer to send the last packet
								Endpoint_ClearOUT();
							}
						
							sprintf(debugString, "Bulk sending complete (128 packets sent)");
							debugOut(debugString);
						
							// Show our success
							successIndicatorFlag = true;
						}
						else
						{
							failureIndicatorFlag = true;
			            
							sprintf(debugString, "Failed to receive 1 packet of data from command 0x82");
							debugOut(debugString);
						} 
	            		break;
					
					case 0x83:	// Test 4 - 128 packets written from host, 1 packet in reply from device
	            		sprintf(debugString, "** Received command 0x83 from host");
						debugOut(debugString);

						// There is only 63 bytes of data in the first packet due to the command byte
						dataReceivedOk = true;
						
						// we are expecting 0 (the packet number) in bytes 1 to 63 (byte 0 is the command)
	            		for (bufferPointer = 1; bufferPointer < GENERIC_REPORT_SIZE; bufferPointer++)
	            		{
		            		if (hidReceiveBuffer[bufferPointer] != 0)
		            			dataReceivedOk = false;
						}
					
						// Display the test result
						if (dataReceivedOk == true)
						{
			        		successIndicatorFlag = true;
			        		sprintf(debugString, "Successfully received 1 packet of data from command 0x83");
							debugOut(debugString);
						}
						else
						{
							failureIndicatorFlag = true;
							sprintf(debugString, "Failed to receive 1 packet of data from command 0x83");
							debugOut(debugString);
						} 
					
						// Set up the bulk Rx globals
						bulkRxExpectedPackets = 128;
						bulkRxCurrentPacket = 1;
						bulkRxModeFlag = true;
						bulkRxCommandNumber = 0x83;
					
	            		break;
	            	
					case 0x84:	// Test 5 - 128 packets written from host, 128 packets in reply from device
	            		sprintf(debugString, "** Received command 0x84 from host");
						debugOut(debugString);
						
						// There is only 63 bytes of data in the first packet due to the command byte
						dataReceivedOk = true;
						
						// we are expecting 0 (the packet number) in bytes 1 to 63 (byte 0 is the command)
	            		for (bufferPointer = 1; bufferPointer < GENERIC_REPORT_SIZE; bufferPointer++)
	            		{
		            		if (hidReceiveBuffer[bufferPointer] != 0)
		            			dataReceivedOk = false;
						}
					
						// Display the test result
						if (dataReceivedOk == true)
						{
			        		successIndicatorFlag = true;
			        		sprintf(debugString, "Successfully received 1 packet of data from command 0x84");
							debugOut(debugString);
						}
						else
						{
							failureIndicatorFlag = true;
							sprintf(debugString, "Failed to receive 1 packet of data from command 0x84");
							debugOut(debugString);
						} 
					
						// Set up the bulk Rx globals
						bulkRxExpectedPackets = 128;
						bulkRxCurrentPacket = 1;
						bulkRxModeFlag = true;
						bulkRxCommandNumber = 0x84;
	            		break;
				
					default:
						// Unknown command received
						sprintf(debugString, "Unknown command received (%x)", hidReceiveBuffer[0]);
						debugOut(debugString);
						break;
				} // switch(hidReceiveBuffer[0])
			}
			else
			{
				// We are in bulk receive mode - packet is data
				switch(bulkRxCommandNumber)
				{
					case 0x83: // Test 4 (Bulk Rx) - 128 packets written from host, 1 packet in reply from device
						// Test the received data
	            		expectedData = bulkRxCurrentPacket;
	            		dataReceivedOk = true;
	            		for (bufferPointer = 0; bufferPointer < GENERIC_REPORT_SIZE; bufferPointer++)
	            		{
		            		if (hidReceiveBuffer[bufferPointer] != expectedData)
							{
		            			dataReceivedOk = false;
								sprintf(debugString, "Bulk Rx 0x83 expected %d, got %d (bufferPointer = %d)", expectedData, hidReceiveBuffer[bufferPointer], bufferPointer);
								debugOut(debugString);
								
								// Quit the for() loop
								break;
							}								
						}
						
						if (dataReceivedOk == true)
						{
							bulkRxCurrentPacket++;
							
							// Is the bulk receive complete?
							if (bulkRxCurrentPacket == bulkRxExpectedPackets)
							{
								// Leave bulk Rx mode
								bulkRxModeFlag = false;
								bulkRxCommandNumber = 0;
								
								sprintf(debugString, "Bulk Rx to command 0x83 successful - %d packets received", bulkRxCurrentPacket);
								debugOut(debugString);
								
								// Send 1 packet to the host in reply to the command
								
								// Select the IN end-point
								Endpoint_SelectEndpoint(GENERIC_IN_EPNUM);

								// Send a response to the host
								if (Endpoint_IsINReady())
								{
									// Create return packet data
									for (bufferPointer = 0; bufferPointer < GENERIC_REPORT_SIZE; bufferPointer++)
									{
										hidSendBuffer[bufferPointer] = bufferPointer;
									}

									// Write the return packet data into the report
									Endpoint_Write_Stream_LE(&hidSendBuffer, sizeof(hidSendBuffer), NULL);

									// Finalize the stream transfer to send the last packet
									Endpoint_ClearOUT();
								}

								sprintf(debugString, "Sent 1 packet of data to the host from command 0x83");
								debugOut(debugString);
						
								// Show our success
								successIndicatorFlag = true;
							}
						}
						else
						{
							// Received data was wrong, give up
							failureIndicatorFlag = true;
							sprintf(debugString, "Failed to bulk Rx data from command 0x83 (current packet = %d)", bulkRxCurrentPacket);
							debugOut(debugString);
							
							// Leave bulk Rx mode
							bulkRxModeFlag = false;
							bulkRxCommandNumber = 0;
						}
						break;
						
						case 0x84: // Test 5 (Bulk Rx) - 128 packets written from host, 128 packets in reply from device
						// Test the received data
	            		expectedData = bulkRxCurrentPacket;
	            		dataReceivedOk = true;
	            		for (bufferPointer = 0; bufferPointer < GENERIC_REPORT_SIZE; bufferPointer++)
	            		{
		            		if (hidReceiveBuffer[bufferPointer] != expectedData)
							{
		            			dataReceivedOk = false;
								sprintf(debugString, "Bulk Rx 0x84 expected %d, got %d (bufferPointer = %d)", expectedData, hidReceiveBuffer[bufferPointer], bufferPointer);
								debugOut(debugString);
								
								// Quit the for() loop
								break;
							}								
						}
						
						if (dataReceivedOk == true)
						{
							bulkRxCurrentPacket++;
							
							// Is the bulk receive complete?
							if (bulkRxCurrentPacket == bulkRxExpectedPackets)
							{
								// Leave bulk Rx mode
								bulkRxModeFlag = false;
								bulkRxCommandNumber = 0;
								
								sprintf(debugString, "Bulk Rx to command 0x84 successful - %d packets received", bulkRxCurrentPacket);
								debugOut(debugString);
								
								// Send 128 packets to the host in reply to the command
								
								// Select the IN end-point
								Endpoint_SelectEndpoint(GENERIC_IN_EPNUM);
						
								for (bulkTxPacketCounter = 0; bulkTxPacketCounter < 128; bulkTxPacketCounter++)
								{
									// Wait for the host IN endpoint to be ready
									while(!Endpoint_IsINReady());
							
									// Create return packet data
									for (bufferPointer = 0; bufferPointer < GENERIC_REPORT_SIZE; bufferPointer++)
									{
										hidSendBuffer[bufferPointer] = bulkTxPacketCounter;
									}

									// Write the return packet data into the report
									Endpoint_Write_Stream_LE(&hidSendBuffer, sizeof(hidSendBuffer), NULL);

									// Finalize the stream transfer to send the last packet
									Endpoint_ClearOUT();
								}
						
								sprintf(debugString, "Bulk sending complete (128 packets sent) 0x84");
								debugOut(debugString);
						
								// Show our success
								successIndicatorFlag = true;
							}
						}
						else
						{
							// Received data was wrong, give up
							failureIndicatorFlag = true;
							sprintf(debugString, "Failed to bulk Rx data from command 0x84 (current packet = %d)", bulkRxCurrentPacket);
							debugOut(debugString);
							
							// Leave bulk Rx mode
							bulkRxModeFlag = false;
							bulkRxCommandNumber = 0;
						}
						break;
						
					default:
						// Unknown bulk receive command!
						sprintf(debugString, "Unknown bulk receive command!");
						debugOut(debugString);
						break;
				}
			}	
		}
	}
}

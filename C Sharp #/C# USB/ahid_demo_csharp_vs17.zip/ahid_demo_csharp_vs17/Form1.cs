﻿using System;
using System.Windows.Forms;

namespace AHidLib.Samples.Csharp
{
    public partial class Form1 : Form
    {
        void timerCallback(object sender, EventArgs e)
        {
            read();

            if (0 == (findInterval++ % 10))
            {
                find();
            }
        }

        public Form1()
        {
            InitializeComponent();

            Timer timer = new Timer();

            timer.Interval = TIMER_INTERVAL;
            timer.Tick += new EventHandler(timerCallback);
            timer.Start();
        }

        private void buttonConnect_Click(object sender, EventArgs e)
        {
            connect();
        }

        private void buttonReset_Click(object sender, EventArgs e)
        {
            reset();
        }

        private void buttonSend_Click(object sender, EventArgs e)
        {
            write();
        }
    }
}

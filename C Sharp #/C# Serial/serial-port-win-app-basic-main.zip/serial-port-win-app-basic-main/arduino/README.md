# Arduino

Testing samples used for Arduino UNO board
- SerialEvent : test UART receive only
- uart_send : test UART send only
- uart_send_receive : test UART send and receive

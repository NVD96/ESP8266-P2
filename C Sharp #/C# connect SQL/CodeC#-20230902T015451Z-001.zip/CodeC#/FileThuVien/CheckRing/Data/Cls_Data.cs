﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CheckRing.Data
{
    public class Cls_Data
    {
        public static string Barcode { get; set; }
        public static string PO { get; set; }
        public static string MSNV { get; set; }
        public static string FullName { get; set; }
        public static string NamePO { get; set; }
        public static string Qty { get; set; }
        public static string Size { get; set; }
        public static string Master { get; set; }
        public static string Status { get; set; }

    }
}

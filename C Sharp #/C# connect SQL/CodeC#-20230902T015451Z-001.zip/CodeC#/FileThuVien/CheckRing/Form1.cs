﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SerialPortFX.Profinet;
using SerialPortFX;
using CheckRing.Data;

namespace CheckRing
{
    public partial class Form1 : Form
    {
        private bool stcomplete { get; set; }
        private MelsecFxSerial melsecFx = new MelsecFxSerial();
        public Form1()
        {
            InitializeComponent();
            
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            ConnectPLC();
     
        }
        public async void ConnectPLC()
        {
            if (melsecFx.IsOpen())
            {
                melsecFx.Close();
            }
            melsecFx.SerialPortInni("COM9", 38400, 7, System.IO.Ports.StopBits.One, System.IO.Ports.Parity.Even);
            melsecFx.Open();
            await Task.WhenAll(Statusconnect(200));
        }
        async Task PutTaskDelay(int SecondsRepeat)
        {
            stcomplete = false;
            await Task.Run(() => { return Task.Delay(SecondsRepeat); });
            stcomplete = true;
        }
        private async Task Statusconnect(int seconds)
        {
            while (true)
            {
                await PutTaskDelay(seconds);
                while (!stcomplete) { }
                try
                {
                    OperateResult<bool[]> readBoolM100 = melsecFx.ReadBool("M100", 10);
                    if (readBoolM100.IsSuccess)
                    {
                        bool m100 = readBoolM100.Content[0];
                        Invoke(new Action(() =>
                            {
                                lb_Connect.BackColor = m100 ? Color.Green : Color.Red;
                                lb_Connect.Text = m100 ? "Connect Successfully!" : "PLC Disconnected";
                            }));
                    }
                    else
                    {
                        Invoke(new Action(() =>
                       {
                           lb_Connect.Text = readBoolM100.ToMessageShowString();
                       }));
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        } 
    }
}

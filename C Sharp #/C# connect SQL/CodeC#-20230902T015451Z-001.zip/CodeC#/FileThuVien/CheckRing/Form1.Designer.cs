﻿
namespace CheckRing
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lb_Status = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lb_Master = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lb_Stt = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lb_Connect = new System.Windows.Forms.Label();
            this.L = new System.Windows.Forms.GroupBox();
            this.txt_Qty = new UI_SPC.UITextbox();
            this.txt_Size = new UI_SPC.UITextbox();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.txt_NamePO = new UI_SPC.UITextbox();
            this.label17 = new System.Windows.Forms.Label();
            this.txt_PO = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.txt_FullName = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_msnv = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_Barcode = new UI_SPC.UITextbox();
            this.label10 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.L.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.Location = new System.Drawing.Point(22, 167);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(1213, 548);
            this.dataGridView1.TabIndex = 1;
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.GhostWhite;
            this.groupBox2.Controls.Add(this.lb_Status);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.lb_Master);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.lb_Stt);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.ForeColor = System.Drawing.Color.Red;
            this.groupBox2.Location = new System.Drawing.Point(758, 2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(477, 159);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Auto Check Ring";
            // 
            // lb_Status
            // 
            this.lb_Status.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lb_Status.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lb_Status.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lb_Status.Location = new System.Drawing.Point(343, 74);
            this.lb_Status.Name = "lb_Status";
            this.lb_Status.Size = new System.Drawing.Size(103, 62);
            this.lb_Status.TabIndex = 7;
            this.lb_Status.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(370, 49);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(56, 21);
            this.label7.TabIndex = 6;
            this.label7.Text = "Status";
            // 
            // lb_Master
            // 
            this.lb_Master.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lb_Master.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lb_Master.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lb_Master.Location = new System.Drawing.Point(185, 74);
            this.lb_Master.Name = "lb_Master";
            this.lb_Master.Size = new System.Drawing.Size(103, 62);
            this.lb_Master.TabIndex = 3;
            this.lb_Master.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(183, 49);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(106, 21);
            this.label3.TabIndex = 2;
            this.label3.Text = "Master (mm)";
            // 
            // lb_Stt
            // 
            this.lb_Stt.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lb_Stt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lb_Stt.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lb_Stt.Location = new System.Drawing.Point(22, 74);
            this.lb_Stt.Name = "lb_Stt";
            this.lb_Stt.Size = new System.Drawing.Size(103, 62);
            this.lb_Stt.TabIndex = 1;
            this.lb_Stt.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(51, 49);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 21);
            this.label1.TabIndex = 0;
            this.label1.Text = "STT";
            // 
            // lb_Connect
            // 
            this.lb_Connect.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lb_Connect.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.lb_Connect.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Connect.Location = new System.Drawing.Point(0, 715);
            this.lb_Connect.Name = "lb_Connect";
            this.lb_Connect.Size = new System.Drawing.Size(1255, 34);
            this.lb_Connect.TabIndex = 3;
            this.lb_Connect.Text = "label15";
            this.lb_Connect.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // L
            // 
            this.L.BackColor = System.Drawing.Color.GhostWhite;
            this.L.Controls.Add(this.txt_Qty);
            this.L.Controls.Add(this.txt_Size);
            this.L.Controls.Add(this.label19);
            this.L.Controls.Add(this.label18);
            this.L.Controls.Add(this.txt_NamePO);
            this.L.Controls.Add(this.label17);
            this.L.Controls.Add(this.txt_PO);
            this.L.Controls.Add(this.label16);
            this.L.Controls.Add(this.txt_FullName);
            this.L.Controls.Add(this.label6);
            this.L.Controls.Add(this.txt_msnv);
            this.L.Controls.Add(this.label2);
            this.L.Controls.Add(this.txt_Barcode);
            this.L.Controls.Add(this.label10);
            this.L.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.L.ForeColor = System.Drawing.Color.Red;
            this.L.Location = new System.Drawing.Point(22, 2);
            this.L.Name = "L";
            this.L.Size = new System.Drawing.Size(737, 159);
            this.L.TabIndex = 0;
            this.L.TabStop = false;
            this.L.Text = "Input Barcode";
            // 
            // txt_Qty
            // 
            this.txt_Qty.BackColor = System.Drawing.SystemColors.Window;
            this.txt_Qty.BorderColor = System.Drawing.Color.MediumSlateBlue;
            this.txt_Qty.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txt_Qty.BorderRadius = 10;
            this.txt_Qty.BorderSize = 1;
            this.txt_Qty.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Qty.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txt_Qty.Location = new System.Drawing.Point(493, 110);
            this.txt_Qty.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Qty.Multiline = false;
            this.txt_Qty.Name = "txt_Qty";
            this.txt_Qty.Padding = new System.Windows.Forms.Padding(20, 7, 10, 7);
            this.txt_Qty.PasswordChar = false;
            this.txt_Qty.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txt_Qty.PlaceholderText = "";
            this.txt_Qty.Size = new System.Drawing.Size(63, 34);
            this.txt_Qty.TabIndex = 26;
            this.txt_Qty.Texts = "";
            this.txt_Qty.UnderlinedStyle = false;
            // 
            // txt_Size
            // 
            this.txt_Size.BackColor = System.Drawing.SystemColors.Window;
            this.txt_Size.BorderColor = System.Drawing.Color.MediumSlateBlue;
            this.txt_Size.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txt_Size.BorderRadius = 10;
            this.txt_Size.BorderSize = 1;
            this.txt_Size.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Size.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txt_Size.Location = new System.Drawing.Point(628, 110);
            this.txt_Size.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Size.Multiline = false;
            this.txt_Size.Name = "txt_Size";
            this.txt_Size.Padding = new System.Windows.Forms.Padding(20, 7, 10, 7);
            this.txt_Size.PasswordChar = false;
            this.txt_Size.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txt_Size.PlaceholderText = "";
            this.txt_Size.Size = new System.Drawing.Size(63, 34);
            this.txt_Size.TabIndex = 25;
            this.txt_Size.Texts = "";
            this.txt_Size.UnderlinedStyle = false;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Tahoma", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.Black;
            this.label19.Location = new System.Drawing.Point(579, 115);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(46, 21);
            this.label19.TabIndex = 24;
            this.label19.Text = "Size:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Tahoma", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.Black;
            this.label18.Location = new System.Drawing.Point(444, 115);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(42, 21);
            this.label18.TabIndex = 22;
            this.label18.Text = "Qty:";
            // 
            // txt_NamePO
            // 
            this.txt_NamePO.BackColor = System.Drawing.SystemColors.Window;
            this.txt_NamePO.BorderColor = System.Drawing.Color.MediumSlateBlue;
            this.txt_NamePO.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txt_NamePO.BorderRadius = 10;
            this.txt_NamePO.BorderSize = 1;
            this.txt_NamePO.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_NamePO.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txt_NamePO.Location = new System.Drawing.Point(121, 110);
            this.txt_NamePO.Margin = new System.Windows.Forms.Padding(4);
            this.txt_NamePO.Multiline = false;
            this.txt_NamePO.Name = "txt_NamePO";
            this.txt_NamePO.Padding = new System.Windows.Forms.Padding(20, 7, 10, 7);
            this.txt_NamePO.PasswordChar = false;
            this.txt_NamePO.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txt_NamePO.PlaceholderText = "";
            this.txt_NamePO.Size = new System.Drawing.Size(316, 34);
            this.txt_NamePO.TabIndex = 21;
            this.txt_NamePO.Texts = "";
            this.txt_NamePO.UnderlinedStyle = false;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Tahoma", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.Black;
            this.label17.Location = new System.Drawing.Point(14, 115);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(108, 21);
            this.label17.TabIndex = 20;
            this.label17.Text = "TypeProduct:";
            // 
            // txt_PO
            // 
            this.txt_PO.AutoSize = true;
            this.txt_PO.Font = new System.Drawing.Font("Tahoma", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_PO.ForeColor = System.Drawing.Color.BlueViolet;
            this.txt_PO.Location = new System.Drawing.Point(103, 74);
            this.txt_PO.Name = "txt_PO";
            this.txt_PO.Size = new System.Drawing.Size(25, 21);
            this.txt_PO.TabIndex = 19;
            this.txt_PO.Text = "...";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Tahoma", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.Black;
            this.label16.Location = new System.Drawing.Point(14, 74);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(83, 21);
            this.label16.TabIndex = 18;
            this.label16.Text = "Order No:";
            // 
            // txt_FullName
            // 
            this.txt_FullName.AutoSize = true;
            this.txt_FullName.Font = new System.Drawing.Font("Tahoma", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_FullName.ForeColor = System.Drawing.Color.BlueViolet;
            this.txt_FullName.Location = new System.Drawing.Point(498, 34);
            this.txt_FullName.Name = "txt_FullName";
            this.txt_FullName.Size = new System.Drawing.Size(25, 21);
            this.txt_FullName.TabIndex = 17;
            this.txt_FullName.Text = "...";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Tahoma", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(416, 34);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(85, 21);
            this.label6.TabIndex = 16;
            this.label6.Text = "FullName:";
            // 
            // txt_msnv
            // 
            this.txt_msnv.AutoSize = true;
            this.txt_msnv.Font = new System.Drawing.Font("Tahoma", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_msnv.ForeColor = System.Drawing.Color.BlueViolet;
            this.txt_msnv.Location = new System.Drawing.Point(317, 34);
            this.txt_msnv.Name = "txt_msnv";
            this.txt_msnv.Size = new System.Drawing.Size(25, 21);
            this.txt_msnv.TabIndex = 15;
            this.txt_msnv.Text = "...";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(261, 34);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(59, 21);
            this.label2.TabIndex = 14;
            this.label2.Text = "MSNV:";
            // 
            // txt_Barcode
            // 
            this.txt_Barcode.BackColor = System.Drawing.SystemColors.Window;
            this.txt_Barcode.BorderColor = System.Drawing.Color.MediumSlateBlue;
            this.txt_Barcode.BorderFocusColor = System.Drawing.Color.HotPink;
            this.txt_Barcode.BorderRadius = 10;
            this.txt_Barcode.BorderSize = 1;
            this.txt_Barcode.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Barcode.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txt_Barcode.Location = new System.Drawing.Point(18, 29);
            this.txt_Barcode.Margin = new System.Windows.Forms.Padding(4);
            this.txt_Barcode.Multiline = false;
            this.txt_Barcode.Name = "txt_Barcode";
            this.txt_Barcode.Padding = new System.Windows.Forms.Padding(20, 7, 10, 7);
            this.txt_Barcode.PasswordChar = false;
            this.txt_Barcode.PlaceholderColor = System.Drawing.Color.DarkGray;
            this.txt_Barcode.PlaceholderText = "";
            this.txt_Barcode.Size = new System.Drawing.Size(236, 34);
            this.txt_Barcode.TabIndex = 13;
            this.txt_Barcode.Texts = "";
            this.txt_Barcode.UnderlinedStyle = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(6, 82);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(0, 17);
            this.label10.TabIndex = 12;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1255, 749);
            this.Controls.Add(this.lb_Connect);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.L);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.L.ResumeLayout(false);
            this.L.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label lb_Stt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lb_Master;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lb_Connect;
        private System.Windows.Forms.Label lb_Status;
        private System.Windows.Forms.GroupBox L;
        private UI_SPC.UITextbox txt_Size;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private UI_SPC.UITextbox txt_NamePO;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label txt_PO;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label txt_FullName;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label txt_msnv;
        private System.Windows.Forms.Label label2;
        private UI_SPC.UITextbox txt_Barcode;
        private System.Windows.Forms.Label label10;
        private UI_SPC.UITextbox txt_Qty;
    }
}


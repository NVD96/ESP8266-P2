﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BAI_1_SORTING_STATION
{
    public class class_KEPServerEX
    {
        // Class Khai báo tag
        public static string[] tagread(int tagnumber)
        {
            string tagID_1 = "Channel1.Device1.Btt_Auto";
            string tagID_2 = "Channel1.Device1.Btt_Start";
            string tagID_3 = "Channel1.Device1.Btt_Stop";
            string tagID_4 = "Channel1.Device1.Btt_Reset";
            string tagID_5 = "Channel1.Device1.Entry_conveyor";
            string tagID_6 = "Channel1.Device1.Exit_conveyor";
            string tagID_7 = "Channel1.Device1.sorter_1_turn";
            string tagID_8 = "Channel1.Device1.sorter_1_belt";
            string tagID_9 = "Channel1.Device1.sorter_2_turn";
            string tagID_10 = "Channel1.Device1.sorter_2_belt";
            string tagID_11 = "Channel1.Device1.sorter_3_turn";
            string tagID_12 = "Channel1.Device1.sorter_3_belt";
            string tagID_13 = "Channel1.Device1.start_light";
            string tagID_14 = "Channel1.Device1.stop_light";
            string tagID_15 = "Channel1.Device1.vison_ss";
            string tagID_16 = "Channel1.Device1.couter_1";
            string tagID_17 = "Channel1.Device1.couter_2";
            string tagID_18 = "Channel1.Device1.couter_3";
            string tagID_19 = "Channel1.Device1.status_Y0";
            string tagID_20 = "Channel1.Device1.status_Y1";
            string tagID_21 = "Channel1.Device1.status_Y2";
            string tagID_22 = "Channel1.Device1.status_Y3";
            string tagID_23 = "Channel1.Device1.status_Y4";
            string tagID_24 = "Channel1.Device1.status_Y5";
            string tagID_25 = "Channel1.Device1.status_Y6";
            string tagID_26 = "Channel1.Device1.status_Y7";


            string[] tags;
            tags = new string[tagnumber];
            tags.SetValue(tagID_1, 1);
            tags.SetValue(tagID_2, 2);
            tags.SetValue(tagID_3, 3);
            tags.SetValue(tagID_4, 4);
            tags.SetValue(tagID_5, 5);
            tags.SetValue(tagID_6, 6);
            tags.SetValue(tagID_7, 7);
            tags.SetValue(tagID_8, 8);
            tags.SetValue(tagID_9, 9);
            tags.SetValue(tagID_10, 10);
            tags.SetValue(tagID_11, 11);
            tags.SetValue(tagID_12, 12);
            tags.SetValue(tagID_13, 13);
            tags.SetValue(tagID_14, 14);
            tags.SetValue(tagID_15, 15);
            tags.SetValue(tagID_16, 16);
            tags.SetValue(tagID_17, 17);
            tags.SetValue(tagID_18, 18);
            tags.SetValue(tagID_19, 19);
            tags.SetValue(tagID_20, 20);
            tags.SetValue(tagID_21, 21);
            tags.SetValue(tagID_22, 22);
            tags.SetValue(tagID_23, 23);
            tags.SetValue(tagID_24, 24);
            tags.SetValue(tagID_25, 25);
            tags.SetValue(tagID_26, 26);


            return tags;
        }
        // Class tạo array đọc ID tags - mặc định không đổi
        public static Int32[] tagID(int tagnumber)
        {
            Int32[] cltarr;
            cltarr = new Int32[tagnumber];
            for (int i = 1; i < tagnumber; i++)
            {
                cltarr.SetValue(i, i);
            }
            return cltarr;
        }
    }
}

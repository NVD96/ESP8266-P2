﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using OPCAutomation; // Thư viện OPC


namespace BAI_1_SORTING_STATION
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //==========================CHƯƠNG TRÌNH CON CLASS==================
        class_Status_Display statusDisplay = new class_Status_Display();
        //==========================THÂN CHƯƠNG TRÌNH=======================
        // Form load
        private void Form1_Load(object sender, EventArgs e)
        {
            KEPServerEX_Connect();
        }
        //==========================KEPServerEX CONNECT=====================
        static int tagNumber = 26;      // Cài đặt số lượng tag của project
        static int PLCscantime = 200;  // Cài đặt thời gian quét PLC
        // Gọi các kết nối OPC
        public OPCAutomation.OPCServer AnOPCServer;
        public OPCAutomation.OPCServer OPCServer;
        public OPCAutomation.OPCGroups OPCGroup;
        public OPCAutomation.OPCGroup PLC;
        public string Groupname;

        static int arrlength = tagNumber + 1;
        Array OPtags = class_KEPServerEX.tagread(arrlength);
        Array tagID = class_KEPServerEX.tagID(arrlength);
        Array WriteItems = Array.CreateInstance(typeof(object), arrlength);
        Array tagHandles = Array.CreateInstance(typeof(Int32), arrlength);
        Array OPCError = Array.CreateInstance(typeof(Int32), arrlength);
        Array dataType = Array.CreateInstance(typeof(Int16), arrlength);
        Array AccessPaths = Array.CreateInstance(typeof(string), arrlength);
        // Chương trình con kết nối (Connect)
        private void KEPServerEX_Connect()
        {
            string IOServer = "Kepware.KEPServerEX.V6";
            string IOGroup = "OPCGroup1";
            OPCServer = new OPCAutomation.OPCServer();
            OPCServer.Connect(IOServer, "");
            PLC = OPCServer.OPCGroups.Add(IOGroup);
            PLC.DataChange += new DIOPCGroupEvent_DataChangeEventHandler(dataScan);
            PLC.UpdateRate = PLCscantime;
            PLC.IsSubscribed = PLC.IsActive;
            PLC.OPCItems.DefaultIsActive = true;
            PLC.OPCItems.AddItems(tagNumber, ref OPtags, ref tagID,
                out tagHandles, out OPCError, dataType, AccessPaths);
        }

        private void dataScan(int ID, int NumItems, ref Array tagID,
            ref Array ItemValues, ref Array Qualities, ref Array TimeStamps)
        {
            for (int i = 1; i <= NumItems; i++)
            {
                // Khai báo biến chung
                int getTagID = Convert.ToInt32(tagID.GetValue(i));
                string tagValue = ItemValues.GetValue(i)?.ToString();
                // Lấy giá trị tag
                // Đèn báo
                if (getTagID == 13)
                {
                    statusDisplay.stt_Lamp(sym_Lamp_Start, tagValue);
                }
                if (getTagID == 14)
                {
                    statusDisplay.stt_Lamp(sym_Lamp_Stop, tagValue);
                }
                // Động cơ
                if (getTagID == 19)
                {
                    statusDisplay.stt_Motor(sym_Entry_conveyor, tagValue);
                }
                if (getTagID == 20)
                {
                    statusDisplay.stt_Motor(sym_Exit_conveyor, tagValue);
                }
                if (getTagID == 21)
                {
                    statusDisplay.stt_Motor(sym_sorter_turn_1, tagValue);
                }
                if (getTagID == 22)
                {
                    statusDisplay.stt_Motor(sym_sorter_belt_1, tagValue);
                }
                if (getTagID == 23)
                {
                    statusDisplay.stt_Motor(sym_sorter_turn_2, tagValue);
                }
                if (getTagID == 24)
                {
                    statusDisplay.stt_Motor(sym_sorter_belt_2, tagValue);
                }
                if (getTagID == 25)
                {
                    statusDisplay.stt_Motor(sym_sorter_turn_3, tagValue);
                }
                if (getTagID == 26)
                {
                    statusDisplay.stt_Motor(sym_sorter_belt_3, tagValue);
                }
                // Sensor
                /*if (getTagID == 15)
                {
                    statusDisplay.stt_Sensor(vison_ss, tagValue);

                }*/

                // textbox
                if (getTagID == 16) { tb_couter1.Text = tagValue; }
                if (getTagID == 17) { tb_couter2.Text = tagValue; }
                if (getTagID == 18) { tb_couter3.Text = tagValue; }
                // Trạng thái nút nhấn auto
                if (getTagID == 1)
                {
                    if (tagValue == "True")
                    {
                        sym_Btt_Auto.BackColor = Color.Green;
                        sym_Btt_Auto.ForeColor = Color.Black;
                    }
                    else
                    {
                        sym_Btt_Auto.BackColor = Color.Gray;
                        sym_Btt_Auto.ForeColor = Color.Black;
                    }
                }

            }
        }

        //==========================GHI DỮ LIỆU TAG=====================



        private void bttConnect_Click_1(object sender, EventArgs e)
        {
            KEPServerEX_Connect();
            progressBar1.Value = 100;
        }

        private void bttDisconnect_Click_1(object sender, EventArgs e)
        {
            OPCServer.Disconnect();
            progressBar1.Value = 0;
        }
        // nút nhấn reset
        private void sym_Btt_Reset_Click(object sender, EventArgs e)
        {
            WriteItems.SetValue(1, 4);
            PLC.SyncWrite(tagNumber, ref tagHandles, ref WriteItems, out OPCError);
            WriteItems.SetValue(0, 4);
        }
        // Nút nhấn Start
        private void sym_Btt_Start_Click_1(object sender, EventArgs e)
        {
            WriteItems.SetValue(1, 2);
            PLC.SyncWrite(tagNumber, ref tagHandles, ref WriteItems, out OPCError);
            WriteItems.SetValue(0, 2);
        }
        // Nút nhấn Stop
        private void sym_Btt_Stop_Click_1(object sender, EventArgs e)
        {
            WriteItems.SetValue(0, 3);
            PLC.SyncWrite(tagNumber, ref tagHandles, ref WriteItems, out OPCError);
            WriteItems.SetValue(1, 3);
        }
        // Nút nhấn chế độ Auto
        private void sym_Btt_Auto_Click_1(object sender, EventArgs e)
        {
            WriteItems.SetValue(1, 1);
            PLC.SyncWrite(tagNumber, ref tagHandles, ref WriteItems, out OPCError);
            //WriteItems.SetValue(0, 1);
        }
    }
}

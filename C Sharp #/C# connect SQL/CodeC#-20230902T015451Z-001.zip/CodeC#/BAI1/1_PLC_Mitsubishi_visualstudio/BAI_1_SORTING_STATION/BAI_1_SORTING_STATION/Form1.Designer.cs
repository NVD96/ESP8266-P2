﻿
namespace BAI_1_SORTING_STATION
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.sym_Btt_Auto = new System.Windows.Forms.Button();
            this.bttConnect = new System.Windows.Forms.Button();
            this.bttDisconnect = new System.Windows.Forms.Button();
            this.sym_Btt_Reset = new System.Windows.Forms.Button();
            this.sym_Btt_Stop = new System.Windows.Forms.Button();
            this.sym_Btt_Start = new System.Windows.Forms.Button();
            this.splitContainer3 = new System.Windows.Forms.SplitContainer();
            this.label9 = new System.Windows.Forms.Label();
            this.sym_Lamp_Start = new SymbolFactoryDotNet.StandardControl();
            this.sym_Lamp_Stop = new SymbolFactoryDotNet.StandardControl();
            this.label8 = new System.Windows.Forms.Label();
            this.tb_couter3 = new System.Windows.Forms.TextBox();
            this.tb_couter2 = new System.Windows.Forms.TextBox();
            this.tb_couter1 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.sym_sorter_belt_3 = new SymbolFactoryDotNet.StandardControl();
            this.label14 = new System.Windows.Forms.Label();
            this.sym_sorter_turn_3 = new SymbolFactoryDotNet.StandardControl();
            this.label4 = new System.Windows.Forms.Label();
            this.sym_sorter_belt_2 = new SymbolFactoryDotNet.StandardControl();
            this.label5 = new System.Windows.Forms.Label();
            this.sym_sorter_turn_2 = new SymbolFactoryDotNet.StandardControl();
            this.label6 = new System.Windows.Forms.Label();
            this.sym_sorter_belt_1 = new SymbolFactoryDotNet.StandardControl();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.sym_Exit_conveyor = new SymbolFactoryDotNet.StandardControl();
            this.sym_sorter_turn_1 = new SymbolFactoryDotNet.StandardControl();
            this.label1 = new System.Windows.Forms.Label();
            this.sym_Entry_conveyor = new SymbolFactoryDotNet.StandardControl();
            this.label7 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).BeginInit();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sym_Lamp_Start)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sym_Lamp_Stop)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sym_sorter_belt_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sym_sorter_turn_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sym_sorter_belt_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sym_sorter_turn_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sym_sorter_belt_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sym_Exit_conveyor)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sym_sorter_turn_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sym_Entry_conveyor)).BeginInit();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.splitContainer2);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.BackgroundImage = global::BAI_1_SORTING_STATION.Properties.Resources.background_la_gi_anh_background_dep_9;
            this.splitContainer1.Panel2.Controls.Add(this.label7);
            this.splitContainer1.Panel2.Controls.Add(this.label15);
            this.splitContainer1.Panel2.Controls.Add(this.label13);
            this.splitContainer1.Panel2.Controls.Add(this.sym_sorter_belt_3);
            this.splitContainer1.Panel2.Controls.Add(this.label14);
            this.splitContainer1.Panel2.Controls.Add(this.sym_sorter_turn_3);
            this.splitContainer1.Panel2.Controls.Add(this.label4);
            this.splitContainer1.Panel2.Controls.Add(this.sym_sorter_belt_2);
            this.splitContainer1.Panel2.Controls.Add(this.label5);
            this.splitContainer1.Panel2.Controls.Add(this.sym_sorter_turn_2);
            this.splitContainer1.Panel2.Controls.Add(this.label6);
            this.splitContainer1.Panel2.Controls.Add(this.sym_sorter_belt_1);
            this.splitContainer1.Panel2.Controls.Add(this.label3);
            this.splitContainer1.Panel2.Controls.Add(this.label2);
            this.splitContainer1.Panel2.Controls.Add(this.sym_Exit_conveyor);
            this.splitContainer1.Panel2.Controls.Add(this.sym_sorter_turn_1);
            this.splitContainer1.Panel2.Controls.Add(this.label1);
            this.splitContainer1.Panel2.Controls.Add(this.sym_Entry_conveyor);
            this.splitContainer1.Size = new System.Drawing.Size(888, 401);
            this.splitContainer1.SplitterDistance = 415;
            this.splitContainer1.TabIndex = 0;
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            this.splitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.groupBox1);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.splitContainer3);
            this.splitContainer2.Size = new System.Drawing.Size(415, 401);
            this.splitContainer2.SplitterDistance = 228;
            this.splitContainer2.TabIndex = 0;
            // 
            // groupBox1
            // 
            this.groupBox1.BackgroundImage = global::BAI_1_SORTING_STATION.Properties.Resources.background_la_gi_anh_background_dep_9;
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.progressBar1);
            this.groupBox1.Controls.Add(this.sym_Btt_Auto);
            this.groupBox1.Controls.Add(this.bttConnect);
            this.groupBox1.Controls.Add(this.bttDisconnect);
            this.groupBox1.Controls.Add(this.sym_Btt_Reset);
            this.groupBox1.Controls.Add(this.sym_Btt_Stop);
            this.groupBox1.Controls.Add(this.sym_Btt_Start);
            this.groupBox1.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(0, 0);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(419, 226);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Panel";
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(51, 148);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(312, 23);
            this.progressBar1.TabIndex = 7;
            // 
            // sym_Btt_Auto
            // 
            this.sym_Btt_Auto.Location = new System.Drawing.Point(167, 39);
            this.sym_Btt_Auto.Name = "sym_Btt_Auto";
            this.sym_Btt_Auto.Size = new System.Drawing.Size(81, 28);
            this.sym_Btt_Auto.TabIndex = 6;
            this.sym_Btt_Auto.Text = "Auto";
            this.sym_Btt_Auto.UseVisualStyleBackColor = true;
            this.sym_Btt_Auto.Click += new System.EventHandler(this.sym_Btt_Auto_Click_1);
            // 
            // bttConnect
            // 
            this.bttConnect.Location = new System.Drawing.Point(51, 179);
            this.bttConnect.Name = "bttConnect";
            this.bttConnect.Size = new System.Drawing.Size(150, 32);
            this.bttConnect.TabIndex = 5;
            this.bttConnect.Text = "Connect";
            this.bttConnect.UseVisualStyleBackColor = true;
            this.bttConnect.Click += new System.EventHandler(this.bttConnect_Click_1);
            // 
            // bttDisconnect
            // 
            this.bttDisconnect.Location = new System.Drawing.Point(207, 179);
            this.bttDisconnect.Name = "bttDisconnect";
            this.bttDisconnect.Size = new System.Drawing.Size(156, 32);
            this.bttDisconnect.TabIndex = 4;
            this.bttDisconnect.Text = "Disconnect";
            this.bttDisconnect.UseVisualStyleBackColor = true;
            this.bttDisconnect.Click += new System.EventHandler(this.bttDisconnect_Click_1);
            // 
            // sym_Btt_Reset
            // 
            this.sym_Btt_Reset.Location = new System.Drawing.Point(263, 73);
            this.sym_Btt_Reset.Name = "sym_Btt_Reset";
            this.sym_Btt_Reset.Size = new System.Drawing.Size(100, 32);
            this.sym_Btt_Reset.TabIndex = 2;
            this.sym_Btt_Reset.Text = "Reset";
            this.sym_Btt_Reset.UseVisualStyleBackColor = true;
            this.sym_Btt_Reset.Click += new System.EventHandler(this.sym_Btt_Reset_Click);
            // 
            // sym_Btt_Stop
            // 
            this.sym_Btt_Stop.Location = new System.Drawing.Point(157, 73);
            this.sym_Btt_Stop.Name = "sym_Btt_Stop";
            this.sym_Btt_Stop.Size = new System.Drawing.Size(100, 32);
            this.sym_Btt_Stop.TabIndex = 1;
            this.sym_Btt_Stop.Text = "Stop";
            this.sym_Btt_Stop.UseVisualStyleBackColor = true;
            this.sym_Btt_Stop.Click += new System.EventHandler(this.sym_Btt_Stop_Click_1);
            // 
            // sym_Btt_Start
            // 
            this.sym_Btt_Start.Location = new System.Drawing.Point(52, 73);
            this.sym_Btt_Start.Name = "sym_Btt_Start";
            this.sym_Btt_Start.Size = new System.Drawing.Size(100, 32);
            this.sym_Btt_Start.TabIndex = 0;
            this.sym_Btt_Start.Text = "Start";
            this.sym_Btt_Start.UseVisualStyleBackColor = true;
            this.sym_Btt_Start.Click += new System.EventHandler(this.sym_Btt_Start_Click_1);
            // 
            // splitContainer3
            // 
            this.splitContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer3.Location = new System.Drawing.Point(0, 0);
            this.splitContainer3.Name = "splitContainer3";
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.BackgroundImage = global::BAI_1_SORTING_STATION.Properties.Resources.background_la_gi_anh_background_dep_9;
            this.splitContainer3.Panel1.Controls.Add(this.label9);
            this.splitContainer3.Panel1.Controls.Add(this.sym_Lamp_Start);
            this.splitContainer3.Panel1.Controls.Add(this.sym_Lamp_Stop);
            this.splitContainer3.Panel1.Controls.Add(this.label8);
            // 
            // splitContainer3.Panel2
            // 
            this.splitContainer3.Panel2.BackgroundImage = global::BAI_1_SORTING_STATION.Properties.Resources.background_la_gi_anh_background_dep_9;
            this.splitContainer3.Panel2.Controls.Add(this.tb_couter3);
            this.splitContainer3.Panel2.Controls.Add(this.tb_couter2);
            this.splitContainer3.Panel2.Controls.Add(this.tb_couter1);
            this.splitContainer3.Panel2.Controls.Add(this.label12);
            this.splitContainer3.Panel2.Controls.Add(this.label11);
            this.splitContainer3.Panel2.Controls.Add(this.label10);
            this.splitContainer3.Size = new System.Drawing.Size(415, 169);
            this.splitContainer3.SplitterDistance = 161;
            this.splitContainer3.TabIndex = 0;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(104, 97);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(30, 15);
            this.label9.TabIndex = 10;
            this.label9.Text = "Stop";
            // 
            // sym_Lamp_Start
            // 
            this.sym_Lamp_Start.AnalogIntValue1 = ((short)(0));
            this.sym_Lamp_Start.AnalogValue1 = 0D;
            this.sym_Lamp_Start.AnimationMode = SymbolFactoryNetEngine.AnimationModeOptions.DiscreteColorFill;
            this.sym_Lamp_Start.BackColor = System.Drawing.Color.Transparent;
            this.sym_Lamp_Start.BackStyle = SymbolFactoryNetEngine.BackStyleOptions.Transparent;
            this.sym_Lamp_Start.BandsCollection.Add(new SymbolFactoryNetEngine.Band(0D, 0, false, SymbolFactoryNetEngine.BandStyleOptions.Shaded, System.Drawing.Color.Lime, "Band1"));
            this.sym_Lamp_Start.BlinkColor = System.Drawing.Color.Red;
            this.sym_Lamp_Start.Category = "1Btn.cat2";
            this.sym_Lamp_Start.DebugData = new SymbolFactoryDotNet.DebugClass(resources.GetString("sym_Lamp_Start.DebugData"));
            this.sym_Lamp_Start.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(135)))), ((int)(((byte)(135)))), ((int)(((byte)(135)))));
            this.sym_Lamp_Start.FillColorMode = SymbolFactoryNetEngine.FillColorModeOptions.Shaded;
            this.sym_Lamp_Start.Location = new System.Drawing.Point(11, 35);
            this.sym_Lamp_Start.Name = "sym_Lamp_Start";
            this.sym_Lamp_Start.Size = new System.Drawing.Size(53, 59);
            this.sym_Lamp_Start.SymbolHandle = ((long)(646493301));
            this.sym_Lamp_Start.TabIndex = 0;
            // 
            // sym_Lamp_Stop
            // 
            this.sym_Lamp_Stop.AnalogIntValue1 = ((short)(0));
            this.sym_Lamp_Stop.AnalogValue1 = 0D;
            this.sym_Lamp_Stop.AnimationMode = SymbolFactoryNetEngine.AnimationModeOptions.DiscreteColorFill;
            this.sym_Lamp_Stop.BackColor = System.Drawing.Color.Transparent;
            this.sym_Lamp_Stop.BackStyle = SymbolFactoryNetEngine.BackStyleOptions.Transparent;
            this.sym_Lamp_Stop.BandsCollection.Add(new SymbolFactoryNetEngine.Band(0D, 0, false, SymbolFactoryNetEngine.BandStyleOptions.Shaded, System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128))))), "Band1"));
            this.sym_Lamp_Stop.BlinkColor = System.Drawing.Color.Red;
            this.sym_Lamp_Stop.Category = "1Btn.cat2";
            this.sym_Lamp_Stop.DebugData = new SymbolFactoryDotNet.DebugClass(resources.GetString("sym_Lamp_Stop.DebugData"));
            this.sym_Lamp_Stop.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(135)))), ((int)(((byte)(135)))), ((int)(((byte)(135)))));
            this.sym_Lamp_Stop.FillColorMode = SymbolFactoryNetEngine.FillColorModeOptions.Shaded;
            this.sym_Lamp_Stop.Location = new System.Drawing.Point(93, 35);
            this.sym_Lamp_Stop.Name = "sym_Lamp_Stop";
            this.sym_Lamp_Stop.Size = new System.Drawing.Size(53, 59);
            this.sym_Lamp_Stop.SymbolHandle = ((long)(646493301));
            this.sym_Lamp_Stop.TabIndex = 9;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(22, 97);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(30, 15);
            this.label8.TabIndex = 8;
            this.label8.Text = "Start";
            // 
            // tb_couter3
            // 
            this.tb_couter3.Enabled = false;
            this.tb_couter3.Location = new System.Drawing.Point(121, 119);
            this.tb_couter3.Name = "tb_couter3";
            this.tb_couter3.Size = new System.Drawing.Size(108, 20);
            this.tb_couter3.TabIndex = 16;
            // 
            // tb_couter2
            // 
            this.tb_couter2.Enabled = false;
            this.tb_couter2.Location = new System.Drawing.Point(121, 72);
            this.tb_couter2.Name = "tb_couter2";
            this.tb_couter2.Size = new System.Drawing.Size(108, 20);
            this.tb_couter2.TabIndex = 15;
            // 
            // tb_couter1
            // 
            this.tb_couter1.Enabled = false;
            this.tb_couter1.Location = new System.Drawing.Point(121, 19);
            this.tb_couter1.Name = "tb_couter1";
            this.tb_couter1.Size = new System.Drawing.Size(108, 20);
            this.tb_couter1.TabIndex = 14;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(3, 119);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(117, 19);
            this.label12.TabIndex = 13;
            this.label12.Text = "Số sản phẩm lô 3:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(3, 73);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(117, 19);
            this.label11.TabIndex = 12;
            this.label11.Text = "Số sản phẩm lô 2:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(3, 20);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(117, 19);
            this.label10.TabIndex = 11;
            this.label10.Text = "Số sản phẩm lô 1:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(28, 267);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(415, 13);
            this.label15.TabIndex = 26;
            this.label15.Text = "................................................................................." +
    ".......................................................";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(370, 237);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(66, 15);
            this.label13.TabIndex = 25;
            this.label13.Text = "Sorter belt 3";
            // 
            // sym_sorter_belt_3
            // 
            this.sym_sorter_belt_3.AnalogIntValue1 = ((short)(0));
            this.sym_sorter_belt_3.AnalogValue1 = 0D;
            this.sym_sorter_belt_3.AnimationMode = SymbolFactoryNetEngine.AnimationModeOptions.DiscreteColorFill;
            this.sym_sorter_belt_3.BackColor = System.Drawing.Color.Transparent;
            this.sym_sorter_belt_3.BackStyle = SymbolFactoryNetEngine.BackStyleOptions.Transparent;
            this.sym_sorter_belt_3.BandsCollection.Add(new SymbolFactoryNetEngine.Band(90D, 90, false, SymbolFactoryNetEngine.BandStyleOptions.Shaded, System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(255)))), ((int)(((byte)(128))))), "Band1"));
            this.sym_sorter_belt_3.BandsCollection.Add(new SymbolFactoryNetEngine.Band(0D, 0, false, SymbolFactoryNetEngine.BandStyleOptions.Shaded, System.Drawing.Color.Red, "Band2"));
            this.sym_sorter_belt_3.BlinkColor = System.Drawing.Color.Red;
            this.sym_sorter_belt_3.Category = "1cvm.cat2";
            this.sym_sorter_belt_3.DebugData = new SymbolFactoryDotNet.DebugClass(resources.GetString("sym_sorter_belt_3.DebugData"));
            this.sym_sorter_belt_3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.sym_sorter_belt_3.Location = new System.Drawing.Point(351, 165);
            this.sym_sorter_belt_3.Name = "sym_sorter_belt_3";
            this.sym_sorter_belt_3.Size = new System.Drawing.Size(104, 69);
            this.sym_sorter_belt_3.SymbolHandle = ((long)(2065787901));
            this.sym_sorter_belt_3.TabIndex = 24;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(363, 90);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(68, 15);
            this.label14.TabIndex = 23;
            this.label14.Text = "Sorter turn 3";
            // 
            // sym_sorter_turn_3
            // 
            this.sym_sorter_turn_3.AnalogIntValue1 = ((short)(0));
            this.sym_sorter_turn_3.AnalogValue1 = 0D;
            this.sym_sorter_turn_3.AnimationMode = SymbolFactoryNetEngine.AnimationModeOptions.DiscreteColorFill;
            this.sym_sorter_turn_3.BackColor = System.Drawing.Color.Transparent;
            this.sym_sorter_turn_3.BackStyle = SymbolFactoryNetEngine.BackStyleOptions.Transparent;
            this.sym_sorter_turn_3.BandsCollection.Add(new SymbolFactoryNetEngine.Band(90D, 90, false, SymbolFactoryNetEngine.BandStyleOptions.Shaded, System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), "Band1"));
            this.sym_sorter_turn_3.BandsCollection.Add(new SymbolFactoryNetEngine.Band(0D, 0, false, SymbolFactoryNetEngine.BandStyleOptions.Shaded, System.Drawing.Color.Red, "Band2"));
            this.sym_sorter_turn_3.BlinkColor = System.Drawing.Color.Red;
            this.sym_sorter_turn_3.Category = "1MTR.cat2";
            this.sym_sorter_turn_3.DebugData = new SymbolFactoryDotNet.DebugClass(resources.GetString("sym_sorter_turn_3.DebugData"));
            this.sym_sorter_turn_3.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.sym_sorter_turn_3.Location = new System.Drawing.Point(366, 31);
            this.sym_sorter_turn_3.Name = "sym_sorter_turn_3";
            this.sym_sorter_turn_3.Size = new System.Drawing.Size(70, 56);
            this.sym_sorter_turn_3.SymbolHandle = ((long)(792410835));
            this.sym_sorter_turn_3.TabIndex = 22;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(199, 237);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(66, 15);
            this.label4.TabIndex = 21;
            this.label4.Text = "Sorter belt 2";
            // 
            // sym_sorter_belt_2
            // 
            this.sym_sorter_belt_2.AnalogIntValue1 = ((short)(0));
            this.sym_sorter_belt_2.AnalogValue1 = 0D;
            this.sym_sorter_belt_2.AnimationMode = SymbolFactoryNetEngine.AnimationModeOptions.DiscreteColorFill;
            this.sym_sorter_belt_2.BackColor = System.Drawing.Color.Transparent;
            this.sym_sorter_belt_2.BackStyle = SymbolFactoryNetEngine.BackStyleOptions.Transparent;
            this.sym_sorter_belt_2.BandsCollection.Add(new SymbolFactoryNetEngine.Band(90D, 90, false, SymbolFactoryNetEngine.BandStyleOptions.Shaded, System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(255)))), ((int)(((byte)(128))))), "Band1"));
            this.sym_sorter_belt_2.BandsCollection.Add(new SymbolFactoryNetEngine.Band(0D, 0, false, SymbolFactoryNetEngine.BandStyleOptions.Shaded, System.Drawing.Color.Red, "Band2"));
            this.sym_sorter_belt_2.BlinkColor = System.Drawing.Color.Red;
            this.sym_sorter_belt_2.Category = "1cvm.cat2";
            this.sym_sorter_belt_2.DebugData = new SymbolFactoryDotNet.DebugClass(resources.GetString("sym_sorter_belt_2.DebugData"));
            this.sym_sorter_belt_2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.sym_sorter_belt_2.Location = new System.Drawing.Point(180, 165);
            this.sym_sorter_belt_2.Name = "sym_sorter_belt_2";
            this.sym_sorter_belt_2.Size = new System.Drawing.Size(104, 69);
            this.sym_sorter_belt_2.SymbolHandle = ((long)(2065787901));
            this.sym_sorter_belt_2.TabIndex = 20;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(192, 90);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(68, 15);
            this.label5.TabIndex = 19;
            this.label5.Text = "Sorter turn 2";
            // 
            // sym_sorter_turn_2
            // 
            this.sym_sorter_turn_2.AnalogIntValue1 = ((short)(0));
            this.sym_sorter_turn_2.AnalogValue1 = 0D;
            this.sym_sorter_turn_2.AnimationMode = SymbolFactoryNetEngine.AnimationModeOptions.DiscreteColorFill;
            this.sym_sorter_turn_2.BackColor = System.Drawing.Color.Transparent;
            this.sym_sorter_turn_2.BackStyle = SymbolFactoryNetEngine.BackStyleOptions.Transparent;
            this.sym_sorter_turn_2.BandsCollection.Add(new SymbolFactoryNetEngine.Band(90D, 90, false, SymbolFactoryNetEngine.BandStyleOptions.Shaded, System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), "Band1"));
            this.sym_sorter_turn_2.BandsCollection.Add(new SymbolFactoryNetEngine.Band(0D, 0, false, SymbolFactoryNetEngine.BandStyleOptions.Shaded, System.Drawing.Color.Red, "Band2"));
            this.sym_sorter_turn_2.BlinkColor = System.Drawing.Color.Red;
            this.sym_sorter_turn_2.Category = "1MTR.cat2";
            this.sym_sorter_turn_2.DebugData = new SymbolFactoryDotNet.DebugClass(resources.GetString("sym_sorter_turn_2.DebugData"));
            this.sym_sorter_turn_2.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.sym_sorter_turn_2.Location = new System.Drawing.Point(195, 31);
            this.sym_sorter_turn_2.Name = "sym_sorter_turn_2";
            this.sym_sorter_turn_2.Size = new System.Drawing.Size(70, 56);
            this.sym_sorter_turn_2.SymbolHandle = ((long)(792410835));
            this.sym_sorter_turn_2.TabIndex = 18;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(32, 237);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(66, 15);
            this.label6.TabIndex = 17;
            this.label6.Text = "Sorter belt 1";
            // 
            // sym_sorter_belt_1
            // 
            this.sym_sorter_belt_1.AnalogIntValue1 = ((short)(0));
            this.sym_sorter_belt_1.AnalogValue1 = 0D;
            this.sym_sorter_belt_1.AnimationMode = SymbolFactoryNetEngine.AnimationModeOptions.DiscreteColorFill;
            this.sym_sorter_belt_1.BackColor = System.Drawing.Color.Transparent;
            this.sym_sorter_belt_1.BackStyle = SymbolFactoryNetEngine.BackStyleOptions.Transparent;
            this.sym_sorter_belt_1.BandsCollection.Add(new SymbolFactoryNetEngine.Band(90D, 90, false, SymbolFactoryNetEngine.BandStyleOptions.Shaded, System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(255)))), ((int)(((byte)(128))))), "Band1"));
            this.sym_sorter_belt_1.BandsCollection.Add(new SymbolFactoryNetEngine.Band(0D, 0, false, SymbolFactoryNetEngine.BandStyleOptions.Shaded, System.Drawing.Color.Red, "Band2"));
            this.sym_sorter_belt_1.BlinkColor = System.Drawing.Color.Red;
            this.sym_sorter_belt_1.Category = "1cvm.cat2";
            this.sym_sorter_belt_1.DebugData = new SymbolFactoryDotNet.DebugClass(resources.GetString("sym_sorter_belt_1.DebugData"));
            this.sym_sorter_belt_1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.sym_sorter_belt_1.Location = new System.Drawing.Point(13, 165);
            this.sym_sorter_belt_1.Name = "sym_sorter_belt_1";
            this.sym_sorter_belt_1.Size = new System.Drawing.Size(104, 69);
            this.sym_sorter_belt_1.SymbolHandle = ((long)(2065787901));
            this.sym_sorter_belt_1.TabIndex = 16;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(25, 90);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 15);
            this.label3.TabIndex = 7;
            this.label3.Text = "Sorter turn 1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(320, 377);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 15);
            this.label2.TabIndex = 6;
            this.label2.Text = "Edit_conveyor";
            // 
            // sym_Exit_conveyor
            // 
            this.sym_Exit_conveyor.AnalogIntValue1 = ((short)(0));
            this.sym_Exit_conveyor.AnalogValue1 = 0D;
            this.sym_Exit_conveyor.AnimationMode = SymbolFactoryNetEngine.AnimationModeOptions.DiscreteColorFill;
            this.sym_Exit_conveyor.BackColor = System.Drawing.Color.Transparent;
            this.sym_Exit_conveyor.BackStyle = SymbolFactoryNetEngine.BackStyleOptions.Transparent;
            this.sym_Exit_conveyor.BandsCollection.Add(new SymbolFactoryNetEngine.Band(90D, 90, false, SymbolFactoryNetEngine.BandStyleOptions.Shaded, System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(255)))), ((int)(((byte)(128))))), "Band1"));
            this.sym_Exit_conveyor.BandsCollection.Add(new SymbolFactoryNetEngine.Band(0D, 0, false, SymbolFactoryNetEngine.BandStyleOptions.Shaded, System.Drawing.Color.Red, "Band2"));
            this.sym_Exit_conveyor.BlinkColor = System.Drawing.Color.Red;
            this.sym_Exit_conveyor.Category = "1cvm.cat2";
            this.sym_Exit_conveyor.DebugData = new SymbolFactoryDotNet.DebugClass(resources.GetString("sym_Exit_conveyor.DebugData"));
            this.sym_Exit_conveyor.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.sym_Exit_conveyor.Location = new System.Drawing.Point(263, 263);
            this.sym_Exit_conveyor.Name = "sym_Exit_conveyor";
            this.sym_Exit_conveyor.Size = new System.Drawing.Size(193, 107);
            this.sym_Exit_conveyor.SymbolHandle = ((long)(2065787901));
            this.sym_Exit_conveyor.TabIndex = 5;
            // 
            // sym_sorter_turn_1
            // 
            this.sym_sorter_turn_1.AnalogIntValue1 = ((short)(0));
            this.sym_sorter_turn_1.AnalogValue1 = 0D;
            this.sym_sorter_turn_1.AnimationMode = SymbolFactoryNetEngine.AnimationModeOptions.DiscreteColorFill;
            this.sym_sorter_turn_1.BackColor = System.Drawing.Color.Transparent;
            this.sym_sorter_turn_1.BackStyle = SymbolFactoryNetEngine.BackStyleOptions.Transparent;
            this.sym_sorter_turn_1.BandsCollection.Add(new SymbolFactoryNetEngine.Band(90D, 90, false, SymbolFactoryNetEngine.BandStyleOptions.Shaded, System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255))))), "Band1"));
            this.sym_sorter_turn_1.BandsCollection.Add(new SymbolFactoryNetEngine.Band(0D, 0, false, SymbolFactoryNetEngine.BandStyleOptions.Shaded, System.Drawing.Color.Red, "Band2"));
            this.sym_sorter_turn_1.BlinkColor = System.Drawing.Color.Red;
            this.sym_sorter_turn_1.Category = "1MTR.cat2";
            this.sym_sorter_turn_1.DebugData = new SymbolFactoryDotNet.DebugClass(resources.GetString("sym_sorter_turn_1.DebugData"));
            this.sym_sorter_turn_1.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.sym_sorter_turn_1.Location = new System.Drawing.Point(28, 31);
            this.sym_sorter_turn_1.Name = "sym_sorter_turn_1";
            this.sym_sorter_turn_1.Size = new System.Drawing.Size(70, 56);
            this.sym_sorter_turn_1.SymbolHandle = ((long)(792410835));
            this.sym_sorter_turn_1.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(89, 377);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(86, 15);
            this.label1.TabIndex = 1;
            this.label1.Text = "Entry_conveyor";
            // 
            // sym_Entry_conveyor
            // 
            this.sym_Entry_conveyor.AnalogIntValue1 = ((short)(0));
            this.sym_Entry_conveyor.AnalogValue1 = 0D;
            this.sym_Entry_conveyor.AnimationMode = SymbolFactoryNetEngine.AnimationModeOptions.DiscreteColorFill;
            this.sym_Entry_conveyor.BackColor = System.Drawing.Color.Transparent;
            this.sym_Entry_conveyor.BackStyle = SymbolFactoryNetEngine.BackStyleOptions.Transparent;
            this.sym_Entry_conveyor.BandsCollection.Add(new SymbolFactoryNetEngine.Band(90D, 90, false, SymbolFactoryNetEngine.BandStyleOptions.Shaded, System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(255)))), ((int)(((byte)(128))))), "Band1"));
            this.sym_Entry_conveyor.BandsCollection.Add(new SymbolFactoryNetEngine.Band(0D, 0, false, SymbolFactoryNetEngine.BandStyleOptions.Shaded, System.Drawing.Color.Red, "Band2"));
            this.sym_Entry_conveyor.BlinkColor = System.Drawing.Color.Red;
            this.sym_Entry_conveyor.Category = "1cvm.cat2";
            this.sym_Entry_conveyor.DebugData = new SymbolFactoryDotNet.DebugClass(resources.GetString("sym_Entry_conveyor.DebugData"));
            this.sym_Entry_conveyor.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.sym_Entry_conveyor.Location = new System.Drawing.Point(36, 263);
            this.sym_Entry_conveyor.Name = "sym_Entry_conveyor";
            this.sym_Entry_conveyor.Size = new System.Drawing.Size(193, 104);
            this.sym_Entry_conveyor.SymbolHandle = ((long)(2065787901));
            this.sym_Entry_conveyor.TabIndex = 0;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(28, 139);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(415, 13);
            this.label7.TabIndex = 27;
            this.label7.Text = "................................................................................." +
    ".......................................................";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(35, 108);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(350, 21);
            this.label16.TabIndex = 28;
            this.label16.Text = "....................................................................";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(888, 401);
            this.Controls.Add(this.splitContainer1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel1.PerformLayout();
            this.splitContainer3.Panel2.ResumeLayout(false);
            this.splitContainer3.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).EndInit();
            this.splitContainer3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.sym_Lamp_Start)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sym_Lamp_Stop)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sym_sorter_belt_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sym_sorter_turn_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sym_sorter_belt_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sym_sorter_turn_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sym_sorter_belt_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sym_Exit_conveyor)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sym_sorter_turn_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sym_Entry_conveyor)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private SymbolFactoryDotNet.StandardControl sym_Exit_conveyor;
        private SymbolFactoryDotNet.StandardControl sym_sorter_turn_1;
        private System.Windows.Forms.Label label1;
        private SymbolFactoryDotNet.StandardControl sym_Entry_conveyor;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.Label label9;
        private SymbolFactoryDotNet.StandardControl sym_Lamp_Stop;
        private System.Windows.Forms.Label label8;
        private SymbolFactoryDotNet.StandardControl sym_Lamp_Start;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button sym_Btt_Reset;
        private System.Windows.Forms.Button sym_Btt_Stop;
        private System.Windows.Forms.Button sym_Btt_Start;
        private System.Windows.Forms.Button bttConnect;
        private System.Windows.Forms.Button bttDisconnect;
        private System.Windows.Forms.Button sym_Btt_Auto;
        private System.Windows.Forms.SplitContainer splitContainer3;
        private System.Windows.Forms.TextBox tb_couter3;
        private System.Windows.Forms.TextBox tb_couter2;
        private System.Windows.Forms.TextBox tb_couter1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label13;
        private SymbolFactoryDotNet.StandardControl sym_sorter_belt_3;
        private System.Windows.Forms.Label label14;
        private SymbolFactoryDotNet.StandardControl sym_sorter_turn_3;
        private System.Windows.Forms.Label label4;
        private SymbolFactoryDotNet.StandardControl sym_sorter_belt_2;
        private System.Windows.Forms.Label label5;
        private SymbolFactoryDotNet.StandardControl sym_sorter_turn_2;
        private System.Windows.Forms.Label label6;
        private SymbolFactoryDotNet.StandardControl sym_sorter_belt_1;
        private System.Windows.Forms.ProgressBar progressBar1;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label7;
    }
}


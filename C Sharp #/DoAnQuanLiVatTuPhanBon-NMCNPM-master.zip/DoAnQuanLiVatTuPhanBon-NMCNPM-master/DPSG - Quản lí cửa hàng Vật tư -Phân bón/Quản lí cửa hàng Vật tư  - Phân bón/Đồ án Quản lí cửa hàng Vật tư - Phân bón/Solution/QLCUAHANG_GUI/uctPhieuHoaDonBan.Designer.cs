﻿namespace QLCUAHANG_GUI
{
    partial class uctPhieuHoaDonBan
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grbInfoBill = new System.Windows.Forms.GroupBox();
            this.txtNote = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.txtTax = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.lkbClear = new System.Windows.Forms.LinkLabel();
            this.cbCheckInfoCustomer = new System.Windows.Forms.CheckBox();
            this.txtNameStore = new System.Windows.Forms.TextBox();
            this.btnUpdateBillExport = new System.Windows.Forms.Button();
            this.btnDeleteBillExport = new System.Windows.Forms.Button();
            this.btnAddBillExport = new System.Windows.Forms.Button();
            this.dtpkDateTimeExport = new System.Windows.Forms.DateTimePicker();
            this.txtTotalDebtExport = new System.Windows.Forms.TextBox();
            this.txtTotalPayExport = new System.Windows.Forms.TextBox();
            this.txtNameCustomer = new System.Windows.Forms.TextBox();
            this.txtIDCustomer = new System.Windows.Forms.TextBox();
            this.txtIDBillExport = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cmbUnitCalculator = new System.Windows.Forms.ComboBox();
            this.cbRetail = new System.Windows.Forms.CheckBox();
            this.label13 = new System.Windows.Forms.Label();
            this.grbDetailBillSale = new System.Windows.Forms.GroupBox();
            this.dtgvDetailBillSale = new System.Windows.Forms.DataGridView();
            this.MaHDB1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaSPCH = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SoLuong = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DonViTinh = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.HinhThucBan = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SoLuongMuaLe = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnUpdateProductExportDetail = new System.Windows.Forms.Button();
            this.btnDeleteProductExportDetail = new System.Windows.Forms.Button();
            this.btnAddProductExportDetail = new System.Windows.Forms.Button();
            this.lkbClear1 = new System.Windows.Forms.LinkLabel();
            this.cmbIDBillExportDetail = new System.Windows.Forms.ComboBox();
            this.cmbIDProductDetailStore = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.txtRetail = new System.Windows.Forms.TextBox();
            this.txtAmountOfProductExportDetail = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.dtgvInfoListOfBillExport = new System.Windows.Forms.DataGridView();
            this.MaHDB = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TenCH = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaKH = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TenKH = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NgayNhap = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TongTien = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TongNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GhiChu = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.grbInfoBill.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.grbDetailBillSale.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvDetailBillSale)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvInfoListOfBillExport)).BeginInit();
            this.SuspendLayout();
            // 
            // grbInfoBill
            // 
            this.grbInfoBill.Controls.Add(this.txtNote);
            this.grbInfoBill.Controls.Add(this.label17);
            this.grbInfoBill.Controls.Add(this.label16);
            this.grbInfoBill.Controls.Add(this.txtTax);
            this.grbInfoBill.Controls.Add(this.label14);
            this.grbInfoBill.Controls.Add(this.lkbClear);
            this.grbInfoBill.Controls.Add(this.cbCheckInfoCustomer);
            this.grbInfoBill.Controls.Add(this.txtNameStore);
            this.grbInfoBill.Controls.Add(this.btnUpdateBillExport);
            this.grbInfoBill.Controls.Add(this.btnDeleteBillExport);
            this.grbInfoBill.Controls.Add(this.btnAddBillExport);
            this.grbInfoBill.Controls.Add(this.dtpkDateTimeExport);
            this.grbInfoBill.Controls.Add(this.txtTotalDebtExport);
            this.grbInfoBill.Controls.Add(this.txtTotalPayExport);
            this.grbInfoBill.Controls.Add(this.txtNameCustomer);
            this.grbInfoBill.Controls.Add(this.txtIDCustomer);
            this.grbInfoBill.Controls.Add(this.txtIDBillExport);
            this.grbInfoBill.Controls.Add(this.label8);
            this.grbInfoBill.Controls.Add(this.label7);
            this.grbInfoBill.Controls.Add(this.label12);
            this.grbInfoBill.Controls.Add(this.label3);
            this.grbInfoBill.Controls.Add(this.label4);
            this.grbInfoBill.Controls.Add(this.label5);
            this.grbInfoBill.Controls.Add(this.label6);
            this.grbInfoBill.Location = new System.Drawing.Point(12, 41);
            this.grbInfoBill.Name = "grbInfoBill";
            this.grbInfoBill.Size = new System.Drawing.Size(566, 281);
            this.grbInfoBill.TabIndex = 0;
            this.grbInfoBill.TabStop = false;
            // 
            // txtNote
            // 
            this.txtNote.Location = new System.Drawing.Point(414, 142);
            this.txtNote.Multiline = true;
            this.txtNote.Name = "txtNote";
            this.txtNote.Size = new System.Drawing.Size(129, 49);
            this.txtNote.TabIndex = 23;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.label17.Location = new System.Drawing.Point(303, 158);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(55, 17);
            this.label17.TabIndex = 22;
            this.label17.Text = "Ghi chú";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.label16.Location = new System.Drawing.Point(17, 251);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(201, 16);
            this.label16.TabIndex = 21;
            this.label16.Text = "Lưu ý: Tổng tiền = (1+%VAT)*100";
            // 
            // txtTax
            // 
            this.txtTax.Location = new System.Drawing.Point(138, 158);
            this.txtTax.Name = "txtTax";
            this.txtTax.Size = new System.Drawing.Size(129, 20);
            this.txtTax.TabIndex = 20;
            this.txtTax.Text = "10";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.label14.Location = new System.Drawing.Point(17, 158);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(120, 17);
            this.label14.TabIndex = 19;
            this.label14.Text = "Tiền thuế VAT (%)";
            // 
            // lkbClear
            // 
            this.lkbClear.AutoSize = true;
            this.lkbClear.Location = new System.Drawing.Point(303, 254);
            this.lkbClear.Name = "lkbClear";
            this.lkbClear.Size = new System.Drawing.Size(31, 13);
            this.lkbClear.TabIndex = 18;
            this.lkbClear.TabStop = true;
            this.lkbClear.Text = "Clear";
            this.lkbClear.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lkbClear_LinkClicked);
            // 
            // cbCheckInfoCustomer
            // 
            this.cbCheckInfoCustomer.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbCheckInfoCustomer.Location = new System.Drawing.Point(306, 23);
            this.cbCheckInfoCustomer.Name = "cbCheckInfoCustomer";
            this.cbCheckInfoCustomer.Size = new System.Drawing.Size(219, 26);
            this.cbCheckInfoCustomer.TabIndex = 0;
            this.cbCheckInfoCustomer.Text = "Bạn đã có Thông tin Khách hàng";
            this.cbCheckInfoCustomer.UseVisualStyleBackColor = true;
            this.cbCheckInfoCustomer.Click += new System.EventHandler(this.cbCheckInfoCustomer_Click);
            // 
            // txtNameStore
            // 
            this.txtNameStore.Location = new System.Drawing.Point(138, 70);
            this.txtNameStore.Name = "txtNameStore";
            this.txtNameStore.Size = new System.Drawing.Size(129, 20);
            this.txtNameStore.TabIndex = 17;
            // 
            // btnUpdateBillExport
            // 
            this.btnUpdateBillExport.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdateBillExport.Location = new System.Drawing.Point(509, 249);
            this.btnUpdateBillExport.Name = "btnUpdateBillExport";
            this.btnUpdateBillExport.Size = new System.Drawing.Size(51, 25);
            this.btnUpdateBillExport.TabIndex = 16;
            this.btnUpdateBillExport.Text = "Sửa";
            this.btnUpdateBillExport.UseVisualStyleBackColor = true;
            // 
            // btnDeleteBillExport
            // 
            this.btnDeleteBillExport.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeleteBillExport.Location = new System.Drawing.Point(447, 249);
            this.btnDeleteBillExport.Name = "btnDeleteBillExport";
            this.btnDeleteBillExport.Size = new System.Drawing.Size(51, 25);
            this.btnDeleteBillExport.TabIndex = 16;
            this.btnDeleteBillExport.Text = "Xóa";
            this.btnDeleteBillExport.UseVisualStyleBackColor = true;
            // 
            // btnAddBillExport
            // 
            this.btnAddBillExport.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddBillExport.Location = new System.Drawing.Point(380, 249);
            this.btnAddBillExport.Name = "btnAddBillExport";
            this.btnAddBillExport.Size = new System.Drawing.Size(51, 25);
            this.btnAddBillExport.TabIndex = 16;
            this.btnAddBillExport.Text = "Thêm";
            this.btnAddBillExport.UseVisualStyleBackColor = true;
            // 
            // dtpkDateTimeExport
            // 
            this.dtpkDateTimeExport.CustomFormat = "dd/m/yyyy";
            this.dtpkDateTimeExport.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpkDateTimeExport.Location = new System.Drawing.Point(138, 116);
            this.dtpkDateTimeExport.Name = "dtpkDateTimeExport";
            this.dtpkDateTimeExport.Size = new System.Drawing.Size(129, 20);
            this.dtpkDateTimeExport.TabIndex = 15;
            this.dtpkDateTimeExport.Value = new System.DateTime(2018, 4, 25, 20, 54, 0, 0);
            // 
            // txtTotalDebtExport
            // 
            this.txtTotalDebtExport.Location = new System.Drawing.Point(414, 197);
            this.txtTotalDebtExport.Name = "txtTotalDebtExport";
            this.txtTotalDebtExport.Size = new System.Drawing.Size(129, 20);
            this.txtTotalDebtExport.TabIndex = 11;
            this.txtTotalDebtExport.Click += new System.EventHandler(this.txtTotalDebtExport_Click);
            // 
            // txtTotalPayExport
            // 
            this.txtTotalPayExport.Location = new System.Drawing.Point(138, 197);
            this.txtTotalPayExport.Name = "txtTotalPayExport";
            this.txtTotalPayExport.Size = new System.Drawing.Size(129, 20);
            this.txtTotalPayExport.TabIndex = 12;
            this.txtTotalPayExport.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtTotalPayExport_KeyPress_1);
            // 
            // txtNameCustomer
            // 
            this.txtNameCustomer.Location = new System.Drawing.Point(414, 116);
            this.txtNameCustomer.Name = "txtNameCustomer";
            this.txtNameCustomer.Size = new System.Drawing.Size(129, 20);
            this.txtNameCustomer.TabIndex = 14;
            // 
            // txtIDCustomer
            // 
            this.txtIDCustomer.Enabled = false;
            this.txtIDCustomer.Location = new System.Drawing.Point(414, 70);
            this.txtIDCustomer.Name = "txtIDCustomer";
            this.txtIDCustomer.ReadOnly = true;
            this.txtIDCustomer.Size = new System.Drawing.Size(129, 20);
            this.txtIDCustomer.TabIndex = 14;
            // 
            // txtIDBillExport
            // 
            this.txtIDBillExport.Enabled = false;
            this.txtIDBillExport.Location = new System.Drawing.Point(138, 28);
            this.txtIDBillExport.Name = "txtIDBillExport";
            this.txtIDBillExport.ReadOnly = true;
            this.txtIDBillExport.Size = new System.Drawing.Size(129, 20);
            this.txtIDBillExport.TabIndex = 14;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(303, 200);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(60, 17);
            this.label8.TabIndex = 5;
            this.label8.Text = "Tổng nợ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(17, 200);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(106, 17);
            this.label7.TabIndex = 6;
            this.label7.Text = "Tổng tiền (VAT)";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(303, 116);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(105, 17);
            this.label12.TabIndex = 7;
            this.label12.Text = "Tên khách hàng";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(303, 74);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(102, 17);
            this.label3.TabIndex = 7;
            this.label3.Text = "Mã khách hàng";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(17, 74);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(91, 17);
            this.label4.TabIndex = 8;
            this.label4.Text = "Tên cửa hàng";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(17, 116);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(75, 17);
            this.label5.TabIndex = 9;
            this.label5.Text = "Ngày nhập";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(17, 28);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(82, 17);
            this.label6.TabIndex = 10;
            this.label6.Text = "Mã hóa đơn";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.cmbUnitCalculator);
            this.groupBox2.Controls.Add(this.cbRetail);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.grbDetailBillSale);
            this.groupBox2.Controls.Add(this.groupBox3);
            this.groupBox2.Controls.Add(this.lkbClear1);
            this.groupBox2.Controls.Add(this.cmbIDBillExportDetail);
            this.groupBox2.Controls.Add(this.cmbIDProductDetailStore);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.textBox3);
            this.groupBox2.Controls.Add(this.txtRetail);
            this.groupBox2.Controls.Add(this.txtAmountOfProductExportDetail);
            this.groupBox2.Controls.Add(this.label18);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Location = new System.Drawing.Point(588, 44);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(492, 281);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            // 
            // cmbUnitCalculator
            // 
            this.cmbUnitCalculator.FormattingEnabled = true;
            this.cmbUnitCalculator.Location = new System.Drawing.Point(166, 80);
            this.cmbUnitCalculator.Name = "cmbUnitCalculator";
            this.cmbUnitCalculator.Size = new System.Drawing.Size(71, 21);
            this.cmbUnitCalculator.TabIndex = 18;
            // 
            // cbRetail
            // 
            this.cbRetail.AutoSize = true;
            this.cbRetail.Location = new System.Drawing.Point(395, 22);
            this.cbRetail.Name = "cbRetail";
            this.cbRetail.Size = new System.Drawing.Size(56, 17);
            this.cbRetail.TabIndex = 16;
            this.cbRetail.Text = "Bán lẻ";
            this.cbRetail.UseVisualStyleBackColor = true;
            this.cbRetail.CheckedChanged += new System.EventHandler(this.cbRetail_CheckedChanged);
            this.cbRetail.Click += new System.EventHandler(this.cbRetail_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.label13.Location = new System.Drawing.Point(272, 25);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(97, 17);
            this.label13.TabIndex = 15;
            this.label13.Text = "Hình thức bán";
            // 
            // grbDetailBillSale
            // 
            this.grbDetailBillSale.Controls.Add(this.dtgvDetailBillSale);
            this.grbDetailBillSale.Location = new System.Drawing.Point(0, 155);
            this.grbDetailBillSale.Name = "grbDetailBillSale";
            this.grbDetailBillSale.Size = new System.Drawing.Size(486, 123);
            this.grbDetailBillSale.TabIndex = 14;
            this.grbDetailBillSale.TabStop = false;
            // 
            // dtgvDetailBillSale
            // 
            this.dtgvDetailBillSale.AllowUserToAddRows = false;
            this.dtgvDetailBillSale.AllowUserToDeleteRows = false;
            this.dtgvDetailBillSale.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvDetailBillSale.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaHDB1,
            this.MaSPCH,
            this.SoLuong,
            this.DonViTinh,
            this.HinhThucBan,
            this.SoLuongMuaLe});
            this.dtgvDetailBillSale.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dtgvDetailBillSale.Location = new System.Drawing.Point(3, 16);
            this.dtgvDetailBillSale.Name = "dtgvDetailBillSale";
            this.dtgvDetailBillSale.ReadOnly = true;
            this.dtgvDetailBillSale.RowHeadersVisible = false;
            this.dtgvDetailBillSale.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtgvDetailBillSale.Size = new System.Drawing.Size(480, 104);
            this.dtgvDetailBillSale.TabIndex = 0;
            this.dtgvDetailBillSale.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgvDetailBillSale_CellClick);
            // 
            // MaHDB1
            // 
            this.MaHDB1.DataPropertyName = "MaHDB";
            this.MaHDB1.HeaderText = "Mã HDB";
            this.MaHDB1.Name = "MaHDB1";
            this.MaHDB1.ReadOnly = true;
            this.MaHDB1.Width = 75;
            // 
            // MaSPCH
            // 
            this.MaSPCH.DataPropertyName = "MaSPCH";
            this.MaSPCH.HeaderText = "Mã SPCH";
            this.MaSPCH.Name = "MaSPCH";
            this.MaSPCH.ReadOnly = true;
            this.MaSPCH.Width = 80;
            // 
            // SoLuong
            // 
            this.SoLuong.DataPropertyName = "SoLuong";
            this.SoLuong.HeaderText = "Số lượng";
            this.SoLuong.Name = "SoLuong";
            this.SoLuong.ReadOnly = true;
            this.SoLuong.Width = 75;
            // 
            // DonViTinh
            // 
            this.DonViTinh.DataPropertyName = "DonViTinh";
            this.DonViTinh.HeaderText = "Đơn vị tính";
            this.DonViTinh.Name = "DonViTinh";
            this.DonViTinh.ReadOnly = true;
            this.DonViTinh.Width = 85;
            // 
            // HinhThucBan
            // 
            this.HinhThucBan.DataPropertyName = "HinhThucBan";
            this.HinhThucBan.HeaderText = "Hình thức bán";
            this.HinhThucBan.Name = "HinhThucBan";
            this.HinhThucBan.ReadOnly = true;
            // 
            // SoLuongMuaLe
            // 
            this.SoLuongMuaLe.DataPropertyName = "SoLuongMuaLe";
            this.SoLuongMuaLe.HeaderText = "Số lượng mua lẻ";
            this.SoLuongMuaLe.Name = "SoLuongMuaLe";
            this.SoLuongMuaLe.ReadOnly = true;
            this.SoLuongMuaLe.Width = 120;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnUpdateProductExportDetail);
            this.groupBox3.Controls.Add(this.btnDeleteProductExportDetail);
            this.groupBox3.Controls.Add(this.btnAddProductExportDetail);
            this.groupBox3.Location = new System.Drawing.Point(17, 108);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(241, 41);
            this.groupBox3.TabIndex = 13;
            this.groupBox3.TabStop = false;
            // 
            // btnUpdateProductExportDetail
            // 
            this.btnUpdateProductExportDetail.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdateProductExportDetail.Location = new System.Drawing.Point(184, 15);
            this.btnUpdateProductExportDetail.Name = "btnUpdateProductExportDetail";
            this.btnUpdateProductExportDetail.Size = new System.Drawing.Size(51, 25);
            this.btnUpdateProductExportDetail.TabIndex = 16;
            this.btnUpdateProductExportDetail.Text = "Sửa";
            this.btnUpdateProductExportDetail.UseVisualStyleBackColor = true;
            // 
            // btnDeleteProductExportDetail
            // 
            this.btnDeleteProductExportDetail.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeleteProductExportDetail.Location = new System.Drawing.Point(92, 15);
            this.btnDeleteProductExportDetail.Name = "btnDeleteProductExportDetail";
            this.btnDeleteProductExportDetail.Size = new System.Drawing.Size(51, 25);
            this.btnDeleteProductExportDetail.TabIndex = 16;
            this.btnDeleteProductExportDetail.Text = "Xóa";
            this.btnDeleteProductExportDetail.UseVisualStyleBackColor = true;
            // 
            // btnAddProductExportDetail
            // 
            this.btnAddProductExportDetail.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddProductExportDetail.Location = new System.Drawing.Point(6, 15);
            this.btnAddProductExportDetail.Name = "btnAddProductExportDetail";
            this.btnAddProductExportDetail.Size = new System.Drawing.Size(51, 25);
            this.btnAddProductExportDetail.TabIndex = 16;
            this.btnAddProductExportDetail.Text = "Thêm";
            this.btnAddProductExportDetail.UseVisualStyleBackColor = true;
            // 
            // lkbClear1
            // 
            this.lkbClear1.AutoSize = true;
            this.lkbClear1.Location = new System.Drawing.Point(284, 131);
            this.lkbClear1.Name = "lkbClear1";
            this.lkbClear1.Size = new System.Drawing.Size(31, 13);
            this.lkbClear1.TabIndex = 18;
            this.lkbClear1.TabStop = true;
            this.lkbClear1.Text = "Clear";
            this.lkbClear1.Click += new System.EventHandler(this.lkbClear1_Click);
            // 
            // cmbIDBillExportDetail
            // 
            this.cmbIDBillExportDetail.FormattingEnabled = true;
            this.cmbIDBillExportDetail.Location = new System.Drawing.Point(134, 19);
            this.cmbIDBillExportDetail.Name = "cmbIDBillExportDetail";
            this.cmbIDBillExportDetail.Size = new System.Drawing.Size(103, 21);
            this.cmbIDBillExportDetail.TabIndex = 12;
            // 
            // cmbIDProductDetailStore
            // 
            this.cmbIDProductDetailStore.FormattingEnabled = true;
            this.cmbIDProductDetailStore.Location = new System.Drawing.Point(134, 49);
            this.cmbIDProductDetailStore.Name = "cmbIDProductDetailStore";
            this.cmbIDProductDetailStore.Size = new System.Drawing.Size(103, 21);
            this.cmbIDProductDetailStore.TabIndex = 12;
            this.cmbIDProductDetailStore.TextChanged += new System.EventHandler(this.cmbIDProductDetailStore_TextChanged_1);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(14, 49);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(91, 17);
            this.label9.TabIndex = 11;
            this.label9.Text = "Mã sản phẩm";
            // 
            // textBox3
            // 
            this.textBox3.Enabled = false;
            this.textBox3.Location = new System.Drawing.Point(434, 68);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(33, 20);
            this.textBox3.TabIndex = 9;
            this.textBox3.Text = "Kg";
            // 
            // txtRetail
            // 
            this.txtRetail.Location = new System.Drawing.Point(395, 68);
            this.txtRetail.Name = "txtRetail";
            this.txtRetail.Size = new System.Drawing.Size(33, 20);
            this.txtRetail.TabIndex = 9;
            this.txtRetail.Click += new System.EventHandler(this.txtRetail_Click);
            this.txtRetail.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtRetail_KeyPress);
            // 
            // txtAmountOfProductExportDetail
            // 
            this.txtAmountOfProductExportDetail.Location = new System.Drawing.Point(134, 81);
            this.txtAmountOfProductExportDetail.Name = "txtAmountOfProductExportDetail";
            this.txtAmountOfProductExportDetail.Size = new System.Drawing.Size(26, 20);
            this.txtAmountOfProductExportDetail.TabIndex = 9;
            this.txtAmountOfProductExportDetail.Click += new System.EventHandler(this.txtAmountOfProductExportDetail_Click);
            this.txtAmountOfProductExportDetail.TextChanged += new System.EventHandler(this.txtAmountOfProductExportDetail_TextChanged);
            this.txtAmountOfProductExportDetail.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtAmountOfProductExportDetail_KeyPress_1);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(274, 71);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(110, 17);
            this.label18.TabIndex = 8;
            this.label18.Text = "Số lượng mua lẻ";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(14, 81);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(109, 17);
            this.label10.TabIndex = 8;
            this.label10.Text = "Số lượng mua sỉ";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(14, 20);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(82, 17);
            this.label11.TabIndex = 7;
            this.label11.Text = "Mã hóa đơn";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(193, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(134, 15);
            this.label1.TabIndex = 1;
            this.label1.Text = "HÓA ĐƠN BÁN HÀNG";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(743, 13);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(150, 15);
            this.label2.TabIndex = 1;
            this.label2.Text = "CHI TIẾT HÓA ĐƠN BÁN";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.dtgvInfoListOfBillExport);
            this.groupBox4.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox4.Location = new System.Drawing.Point(12, 331);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(1068, 156);
            this.groupBox4.TabIndex = 2;
            this.groupBox4.TabStop = false;
            // 
            // dtgvInfoListOfBillExport
            // 
            this.dtgvInfoListOfBillExport.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgvInfoListOfBillExport.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaHDB,
            this.TenCH,
            this.MaKH,
            this.TenKH,
            this.NgayNhap,
            this.TongTien,
            this.TongNo,
            this.GhiChu});
            this.dtgvInfoListOfBillExport.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dtgvInfoListOfBillExport.Location = new System.Drawing.Point(3, 21);
            this.dtgvInfoListOfBillExport.Name = "dtgvInfoListOfBillExport";
            this.dtgvInfoListOfBillExport.ReadOnly = true;
            this.dtgvInfoListOfBillExport.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtgvInfoListOfBillExport.Size = new System.Drawing.Size(1062, 132);
            this.dtgvInfoListOfBillExport.TabIndex = 1;
            // 
            // MaHDB
            // 
            this.MaHDB.DataPropertyName = "MaHDB";
            this.MaHDB.HeaderText = "Mã HDB";
            this.MaHDB.Name = "MaHDB";
            this.MaHDB.ReadOnly = true;
            // 
            // TenCH
            // 
            this.TenCH.DataPropertyName = "TenCH";
            this.TenCH.HeaderText = "Tên cửa hàng";
            this.TenCH.Name = "TenCH";
            this.TenCH.ReadOnly = true;
            this.TenCH.Width = 155;
            // 
            // MaKH
            // 
            this.MaKH.DataPropertyName = "MaKH";
            this.MaKH.HeaderText = "Mã KH";
            this.MaKH.Name = "MaKH";
            this.MaKH.ReadOnly = true;
            // 
            // TenKH
            // 
            this.TenKH.DataPropertyName = "TenKH";
            this.TenKH.HeaderText = "Tên khách hàng";
            this.TenKH.Name = "TenKH";
            this.TenKH.ReadOnly = true;
            this.TenKH.Width = 170;
            // 
            // NgayNhap
            // 
            this.NgayNhap.DataPropertyName = "NgayNhap";
            this.NgayNhap.HeaderText = "Ngày Nhập";
            this.NgayNhap.Name = "NgayNhap";
            this.NgayNhap.ReadOnly = true;
            this.NgayNhap.Width = 110;
            // 
            // TongTien
            // 
            this.TongTien.DataPropertyName = "TongTien";
            this.TongTien.HeaderText = "Tổng tiền";
            this.TongTien.Name = "TongTien";
            this.TongTien.ReadOnly = true;
            this.TongTien.Width = 140;
            // 
            // TongNo
            // 
            this.TongNo.DataPropertyName = "TongNo";
            this.TongNo.HeaderText = "Tổng nợ";
            this.TongNo.Name = "TongNo";
            this.TongNo.ReadOnly = true;
            this.TongNo.Width = 140;
            // 
            // GhiChu
            // 
            this.GhiChu.DataPropertyName = "GhiChu";
            this.GhiChu.HeaderText = "Ghi chú";
            this.GhiChu.Name = "GhiChu";
            this.GhiChu.ReadOnly = true;
            this.GhiChu.Width = 98;
            // 
            // uctPhieuHoaDonBan
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.grbInfoBill);
            this.Name = "uctPhieuHoaDonBan";
            this.Size = new System.Drawing.Size(1096, 490);
            this.Load += new System.EventHandler(this.uctPhieuHoaDonBan_Load);
            this.grbInfoBill.ResumeLayout(false);
            this.grbInfoBill.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.grbDetailBillSale.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgvDetailBillSale)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgvInfoListOfBillExport)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grbInfoBill;
        private System.Windows.Forms.DateTimePicker dtpkDateTimeExport;
        private System.Windows.Forms.TextBox txtTotalDebtExport;
        private System.Windows.Forms.TextBox txtTotalPayExport;
        private System.Windows.Forms.TextBox txtIDBillExport;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtIDCustomer;
        private System.Windows.Forms.Button btnUpdateBillExport;
        private System.Windows.Forms.Button btnDeleteBillExport;
        private System.Windows.Forms.Button btnAddBillExport;
        private System.Windows.Forms.ComboBox cmbIDProductDetailStore;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtAmountOfProductExportDetail;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btnUpdateProductExportDetail;
        private System.Windows.Forms.Button btnAddProductExportDetail;
        private System.Windows.Forms.Button btnDeleteProductExportDetail;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.DataGridView dtgvInfoListOfBillExport;
        private System.Windows.Forms.TextBox txtNameCustomer;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtNameStore;
        private System.Windows.Forms.CheckBox cbCheckInfoCustomer;
        private System.Windows.Forms.LinkLabel lkbClear;
        private System.Windows.Forms.GroupBox grbDetailBillSale;
        private System.Windows.Forms.DataGridView dtgvDetailBillSale;
        private System.Windows.Forms.ComboBox cmbIDBillExportDetail;
        private System.Windows.Forms.CheckBox cbRetail;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtTax;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtNote;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.ComboBox cmbUnitCalculator;
        private System.Windows.Forms.TextBox txtRetail;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaHDB1;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaSPCH;
        private System.Windows.Forms.DataGridViewTextBoxColumn SoLuong;
        private System.Windows.Forms.DataGridViewTextBoxColumn DonViTinh;
        private System.Windows.Forms.DataGridViewTextBoxColumn HinhThucBan;
        private System.Windows.Forms.DataGridViewTextBoxColumn SoLuongMuaLe;
        private System.Windows.Forms.LinkLabel lkbClear1;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaHDB;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenCH;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaKH;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenKH;
        private System.Windows.Forms.DataGridViewTextBoxColumn NgayNhap;
        private System.Windows.Forms.DataGridViewTextBoxColumn TongTien;
        private System.Windows.Forms.DataGridViewTextBoxColumn TongNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn GhiChu;
    }
}

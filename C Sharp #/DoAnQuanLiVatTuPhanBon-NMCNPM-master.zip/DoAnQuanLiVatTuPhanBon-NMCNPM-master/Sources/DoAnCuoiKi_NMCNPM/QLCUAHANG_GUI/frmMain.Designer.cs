﻿namespace QLCUAHANG_GUI
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            DevExpress.XtraSplashScreen.SplashScreenManager splashScreenManager1 = new DevExpress.XtraSplashScreen.SplashScreenManager(this, typeof(global::QLCUAHANG_GUI.SplashScreen1), true, true);
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.repositoryItemRichTextEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemRichTextEdit();
            this.ribbonPage3 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPage5 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPage4 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup3 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.barButtonItem9 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem10 = new DevExpress.XtraBars.BarButtonItem();
            this.managerToolStripMenuItem = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.pageGroupInfoOfAgency = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.btnInfoAgency = new DevExpress.XtraBars.BarButtonItem();
            this.btnProductOfAgency = new DevExpress.XtraBars.BarButtonItem();
            this.pageGroupOfCustomer = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.btnInfoOfCustomer = new DevExpress.XtraBars.BarButtonItem();
            this.pageGroupOfBills = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.btnBill = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem7 = new DevExpress.XtraBars.BarButtonItem();
            this.pageGroupStore = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.btnProductOfStore = new DevExpress.XtraBars.BarButtonItem();
            this.btnBillOfExportProduct = new DevExpress.XtraBars.BarButtonItem();
            this.systemToolStripMenuItem = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup1 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.btnLogin = new DevExpress.XtraBars.BarButtonItem();
            this.btnChangePassWord = new DevExpress.XtraBars.BarButtonItem();
            this.btnLogout = new DevExpress.XtraBars.BarButtonItem();
            this.btnDecentralization1 = new DevExpress.XtraBars.BarButtonItem();
            this.ribbonPageGroup5 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.btnBackup = new DevExpress.XtraBars.BarButtonItem();
            this.btnRestore = new DevExpress.XtraBars.BarButtonItem();
            this.ribbonPageGroup4 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.skinRibbonGalleryBarItem1 = new DevExpress.XtraBars.SkinRibbonGalleryBarItem();
            this.menuToolStrip = new DevExpress.XtraBars.Ribbon.RibbonControl();
            this.imageCL1 = new DevExpress.Utils.ImageCollection(this.components);
            this.btnDecentralization = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem5 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem4 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem11 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem12 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem2 = new DevExpress.XtraBars.BarButtonItem();
            this.barEditItem1 = new DevExpress.XtraBars.BarEditItem();
            this.barHeaderItem1 = new DevExpress.XtraBars.BarHeaderItem();
            this.barEditItem2 = new DevExpress.XtraBars.BarEditItem();
            this.repositoryItemButtonEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.skinRibbonGalleryBarItem2 = new DevExpress.XtraBars.SkinRibbonGalleryBarItem();
            this.barEditItem3 = new DevExpress.XtraBars.BarEditItem();
            this.repositoryItemDateEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemDateEdit();
            this.barEditItem5 = new DevExpress.XtraBars.BarEditItem();
            this.repositoryItemRichTextEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemRichTextEdit();
            this.barEditItem6 = new DevExpress.XtraBars.BarEditItem();
            this.repositoryItemRichTextEdit3 = new DevExpress.XtraEditors.Repository.RepositoryItemRichTextEdit();
            this.barEditItem7 = new DevExpress.XtraBars.BarEditItem();
            this.repositoryItemRichTextEdit4 = new DevExpress.XtraEditors.Repository.RepositoryItemRichTextEdit();
            this.barEditItem8 = new DevExpress.XtraBars.BarEditItem();
            this.repositoryItemButtonEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.skinRibbonGalleryBarItem3 = new DevExpress.XtraBars.SkinRibbonGalleryBarItem();
            this.ribbonPage6 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup8 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPage8 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup10 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPage9 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup11 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup2 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup6 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPage10 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup12 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.rbsStatus = new DevExpress.XtraBars.Ribbon.RibbonStatusBar();
            this.ribbonPage7 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup9 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ctxtMenuTapDispaly = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.closeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.colseAllTabToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.barButtonItem1 = new DevExpress.XtraBars.BarButtonItem();
            this.barEditItem4 = new DevExpress.XtraBars.BarEditItem();
            this.tabDisplay = new System.Windows.Forms.TabControl();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemRichTextEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.menuToolStrip)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageCL1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemRichTextEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemRichTextEdit3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemRichTextEdit4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEdit2)).BeginInit();
            this.ctxtMenuTapDispaly.SuspendLayout();
            this.SuspendLayout();
            // 
            // splashScreenManager1
            // 
            splashScreenManager1.ClosingDelay = 10000;
            // 
            // repositoryItemRichTextEdit1
            // 
            this.repositoryItemRichTextEdit1.Name = "repositoryItemRichTextEdit1";
            this.repositoryItemRichTextEdit1.ShowCaretInReadOnly = false;
            // 
            // ribbonPage3
            // 
            this.ribbonPage3.Name = "ribbonPage3";
            this.ribbonPage3.Text = "ribbonPage3";
            // 
            // ribbonPage5
            // 
            this.ribbonPage5.Name = "ribbonPage5";
            this.ribbonPage5.Text = "ribbonPage5";
            // 
            // ribbonPage4
            // 
            this.ribbonPage4.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup3});
            this.ribbonPage4.Name = "ribbonPage4";
            this.ribbonPage4.Text = "Trợ giúp";
            // 
            // ribbonPageGroup3
            // 
            this.ribbonPageGroup3.ItemLinks.Add(this.barButtonItem9);
            this.ribbonPageGroup3.ItemLinks.Add(this.barButtonItem10);
            this.ribbonPageGroup3.Name = "ribbonPageGroup3";
            this.ribbonPageGroup3.Text = "Thông tin phần mềm";
            // 
            // barButtonItem9
            // 
            this.barButtonItem9.Caption = "Hướng dẫn sử dụng";
            this.barButtonItem9.Id = 18;
            this.barButtonItem9.Name = "barButtonItem9";
            // 
            // barButtonItem10
            // 
            this.barButtonItem10.Caption = "Thông tin tác gủa";
            this.barButtonItem10.Id = 19;
            this.barButtonItem10.Name = "barButtonItem10";
            // 
            // managerToolStripMenuItem
            // 
            this.managerToolStripMenuItem.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.pageGroupInfoOfAgency,
            this.pageGroupOfCustomer,
            this.pageGroupOfBills,
            this.pageGroupStore});
            this.managerToolStripMenuItem.Name = "managerToolStripMenuItem";
            this.managerToolStripMenuItem.Text = "Quản lí";
            // 
            // pageGroupInfoOfAgency
            // 
            this.pageGroupInfoOfAgency.ItemLinks.Add(this.btnInfoAgency);
            this.pageGroupInfoOfAgency.ItemLinks.Add(this.btnProductOfAgency);
            this.pageGroupInfoOfAgency.Name = "pageGroupInfoOfAgency";
            this.pageGroupInfoOfAgency.Text = "Đại lí";
            // 
            // btnInfoAgency
            // 
            this.btnInfoAgency.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.btnInfoAgency.Caption = "Thông tin Đại lí";
            this.btnInfoAgency.Id = 11;
            this.btnInfoAgency.ImageOptions.Image = global::QLCUAHANG_GUI.Properties.Resources.agency;
            this.btnInfoAgency.ImageOptions.ImageIndex = 23;
            this.btnInfoAgency.Name = "btnInfoAgency";
            this.btnInfoAgency.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnInfoAgency_ItemClick);
            // 
            // btnProductOfAgency
            // 
            this.btnProductOfAgency.Caption = "Sản phẩm của Đại Lí";
            this.btnProductOfAgency.Id = 12;
            this.btnProductOfAgency.ImageOptions.Image = global::QLCUAHANG_GUI.Properties.Resources.product_1;
            this.btnProductOfAgency.ImageOptions.ImageIndex = 25;
            this.btnProductOfAgency.Name = "btnProductOfAgency";
            this.btnProductOfAgency.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnProductOfAgency_ItemClick);
            // 
            // pageGroupOfCustomer
            // 
            this.pageGroupOfCustomer.ItemLinks.Add(this.btnInfoOfCustomer);
            this.pageGroupOfCustomer.Name = "pageGroupOfCustomer";
            this.pageGroupOfCustomer.Text = "Khách hàng";
            // 
            // btnInfoOfCustomer
            // 
            this.btnInfoOfCustomer.Caption = "Thông tin Khách hàng";
            this.btnInfoOfCustomer.Id = 13;
            this.btnInfoOfCustomer.ImageOptions.Image = global::QLCUAHANG_GUI.Properties.Resources.customer_1;
            this.btnInfoOfCustomer.ImageOptions.ImageIndex = 24;
            this.btnInfoOfCustomer.Name = "btnInfoOfCustomer";
            this.btnInfoOfCustomer.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnInfoOfCustomer_ItemClick);
            // 
            // pageGroupOfBills
            // 
            this.pageGroupOfBills.ItemLinks.Add(this.btnBill, true);
            this.pageGroupOfBills.ItemLinks.Add(this.barButtonItem7);
            this.pageGroupOfBills.Name = "pageGroupOfBills";
            this.pageGroupOfBills.Text = "Hóa đơn";
            // 
            // btnBill
            // 
            this.btnBill.Caption = "Hóa đơn";
            this.btnBill.Id = 15;
            this.btnBill.ImageOptions.DisabledImage = ((System.Drawing.Image)(resources.GetObject("btnBill.ImageOptions.DisabledImage")));
            this.btnBill.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnBill.ImageOptions.Image")));
            this.btnBill.Name = "btnBill";
            this.btnBill.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            this.btnBill.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnBill_ItemClick);
            // 
            // barButtonItem7
            // 
            this.barButtonItem7.Id = 16;
            this.barButtonItem7.Name = "barButtonItem7";
            // 
            // pageGroupStore
            // 
            this.pageGroupStore.ItemLinks.Add(this.btnProductOfStore);
            this.pageGroupStore.Name = "pageGroupStore";
            this.pageGroupStore.Text = "Cửa hàng";
            // 
            // btnProductOfStore
            // 
            this.btnProductOfStore.Caption = "Sản phẩm ";
            this.btnProductOfStore.Id = 24;
            this.btnProductOfStore.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnProductOfStore.ImageOptions.Image")));
            this.btnProductOfStore.Name = "btnProductOfStore";
            this.btnProductOfStore.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnProductOfStore_ItemClick);
            // 
            // btnBillOfExportProduct
            // 
            this.btnBillOfExportProduct.Caption = "Phiếu hóa đơn bán hàng";
            this.btnBillOfExportProduct.Id = 17;
            this.btnBillOfExportProduct.Name = "btnBillOfExportProduct";
            // 
            // systemToolStripMenuItem
            // 
            this.systemToolStripMenuItem.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup1,
            this.ribbonPageGroup5,
            this.ribbonPageGroup4});
            this.systemToolStripMenuItem.Name = "systemToolStripMenuItem";
            this.systemToolStripMenuItem.Text = "Hệ thống";
            // 
            // ribbonPageGroup1
            // 
            this.ribbonPageGroup1.ItemLinks.Add(this.btnLogin);
            this.ribbonPageGroup1.ItemLinks.Add(this.btnChangePassWord);
            this.ribbonPageGroup1.ItemLinks.Add(this.btnLogout);
            this.ribbonPageGroup1.ItemLinks.Add(this.btnDecentralization1);
            this.ribbonPageGroup1.Name = "ribbonPageGroup1";
            this.ribbonPageGroup1.Text = "Hệ thống";
            // 
            // btnLogin
            // 
            this.btnLogin.Caption = "Đăng nhập";
            this.btnLogin.Id = 1;
            this.btnLogin.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnLogin.ImageOptions.Image")));
            this.btnLogin.ImageOptions.ImageIndex = 22;
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            // 
            // btnChangePassWord
            // 
            this.btnChangePassWord.Caption = "Đổi mật khẩu";
            this.btnChangePassWord.Id = 2;
            this.btnChangePassWord.ImageOptions.ImageIndex = 12;
            this.btnChangePassWord.Name = "btnChangePassWord";
            // 
            // btnLogout
            // 
            this.btnLogout.Caption = "Đăng xuất";
            this.btnLogout.Id = 3;
            this.btnLogout.ImageOptions.ImageIndex = 11;
            this.btnLogout.Name = "btnLogout";
            // 
            // btnDecentralization1
            // 
            this.btnDecentralization1.Caption = "Phân quyền người dùng";
            this.btnDecentralization1.Id = 8;
            this.btnDecentralization1.ImageOptions.ImageIndex = 21;
            this.btnDecentralization1.Name = "btnDecentralization1";
            this.btnDecentralization1.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)(((DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText) 
            | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            // 
            // ribbonPageGroup5
            // 
            this.ribbonPageGroup5.ItemLinks.Add(this.btnBackup);
            this.ribbonPageGroup5.ItemLinks.Add(this.btnRestore);
            this.ribbonPageGroup5.Name = "ribbonPageGroup5";
            this.ribbonPageGroup5.Text = "Dữ liệu";
            // 
            // btnBackup
            // 
            this.btnBackup.Caption = "Sao lưu dữ liệu";
            this.btnBackup.Id = 6;
            this.btnBackup.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnBackup.ImageOptions.Image")));
            this.btnBackup.ImageOptions.ImageIndex = 5;
            this.btnBackup.Name = "btnBackup";
            // 
            // btnRestore
            // 
            this.btnRestore.Caption = "Phục hồi dữ liệu";
            this.btnRestore.Id = 7;
            this.btnRestore.ImageOptions.ImageIndex = 14;
            this.btnRestore.Name = "btnRestore";
            // 
            // ribbonPageGroup4
            // 
            this.ribbonPageGroup4.ItemLinks.Add(this.skinRibbonGalleryBarItem1);
            this.ribbonPageGroup4.Name = "ribbonPageGroup4";
            this.ribbonPageGroup4.Text = "Giao diện";
            // 
            // skinRibbonGalleryBarItem1
            // 
            this.skinRibbonGalleryBarItem1.Caption = "skinRibbonGalleryBarItem1";
            this.skinRibbonGalleryBarItem1.Id = 22;
            this.skinRibbonGalleryBarItem1.Name = "skinRibbonGalleryBarItem1";
            // 
            // menuToolStrip
            // 
            this.menuToolStrip.BackColor = System.Drawing.Color.Yellow;
            this.menuToolStrip.ExpandCollapseItem.Id = 0;
            this.menuToolStrip.Images = this.imageCL1;
            this.menuToolStrip.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.menuToolStrip.ExpandCollapseItem,
            this.btnLogin,
            this.btnChangePassWord,
            this.btnLogout,
            this.btnDecentralization,
            this.barButtonItem5,
            this.btnBackup,
            this.btnRestore,
            this.btnDecentralization1,
            this.btnInfoAgency,
            this.btnProductOfAgency,
            this.btnInfoOfCustomer,
            this.barButtonItem4,
            this.btnBill,
            this.barButtonItem7,
            this.btnBillOfExportProduct,
            this.barButtonItem9,
            this.barButtonItem10,
            this.barButtonItem11,
            this.barButtonItem12,
            this.skinRibbonGalleryBarItem1,
            this.btnProductOfStore,
            this.barButtonItem2,
            this.barEditItem1,
            this.barHeaderItem1,
            this.barEditItem2,
            this.skinRibbonGalleryBarItem2,
            this.barEditItem3,
            this.barEditItem5,
            this.barEditItem6,
            this.barEditItem7,
            this.barEditItem8,
            this.skinRibbonGalleryBarItem3});
            this.menuToolStrip.Location = new System.Drawing.Point(0, 0);
            this.menuToolStrip.MaxItemId = 38;
            this.menuToolStrip.Name = "menuToolStrip";
            this.menuToolStrip.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.systemToolStripMenuItem,
            this.managerToolStripMenuItem,
            this.ribbonPage6,
            this.ribbonPage8,
            this.ribbonPage9,
            this.ribbonPage10});
            this.menuToolStrip.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemButtonEdit1,
            this.repositoryItemDateEdit1,
            this.repositoryItemRichTextEdit2,
            this.repositoryItemRichTextEdit3,
            this.repositoryItemRichTextEdit4,
            this.repositoryItemButtonEdit2});
            this.menuToolStrip.Size = new System.Drawing.Size(1247, 143);
            this.menuToolStrip.StatusBar = this.rbsStatus;
            // 
            // imageCL1
            // 
            this.imageCL1.ImageStream = ((DevExpress.Utils.ImageCollectionStreamer)(resources.GetObject("imageCL1.ImageStream")));
            this.imageCL1.InsertGalleryImage("bouser_32x32.png", "images/business%20objects/bouser_32x32.png", DevExpress.Images.ImageResourceCache.Default.GetImage("images/business%20objects/bouser_32x32.png"), 0);
            this.imageCL1.Images.SetKeyName(0, "bouser_32x32.png");
            // 
            // btnDecentralization
            // 
            this.btnDecentralization.Caption = "Phân quyền người dùng";
            this.btnDecentralization.Id = 4;
            this.btnDecentralization.Name = "btnDecentralization";
            // 
            // barButtonItem5
            // 
            this.barButtonItem5.Caption = "barButtonItem5";
            this.barButtonItem5.Id = 5;
            this.barButtonItem5.Name = "barButtonItem5";
            // 
            // barButtonItem4
            // 
            this.barButtonItem4.Caption = "barButtonItem4";
            this.barButtonItem4.Id = 14;
            this.barButtonItem4.Name = "barButtonItem4";
            // 
            // barButtonItem11
            // 
            this.barButtonItem11.Caption = "Hướng dẫn sử dụng";
            this.barButtonItem11.Id = 20;
            this.barButtonItem11.Name = "barButtonItem11";
            // 
            // barButtonItem12
            // 
            this.barButtonItem12.Caption = "Thôn tin tác giả";
            this.barButtonItem12.Id = 21;
            this.barButtonItem12.Name = "barButtonItem12";
            // 
            // barButtonItem2
            // 
            this.barButtonItem2.Caption = "Thông tin tác giả";
            this.barButtonItem2.Id = 25;
            this.barButtonItem2.Name = "barButtonItem2";
            // 
            // barEditItem1
            // 
            this.barEditItem1.Caption = "barEditItem1";
            this.barEditItem1.Edit = this.repositoryItemRichTextEdit1;
            this.barEditItem1.Id = 26;
            this.barEditItem1.Name = "barEditItem1";
            // 
            // barHeaderItem1
            // 
            this.barHeaderItem1.Caption = "barHeaderItem1";
            this.barHeaderItem1.Id = 27;
            this.barHeaderItem1.Name = "barHeaderItem1";
            // 
            // barEditItem2
            // 
            this.barEditItem2.Caption = "Version 2";
            this.barEditItem2.Edit = this.repositoryItemButtonEdit1;
            this.barEditItem2.Id = 28;
            this.barEditItem2.Name = "barEditItem2";
            // 
            // repositoryItemButtonEdit1
            // 
            this.repositoryItemButtonEdit1.AutoHeight = false;
            this.repositoryItemButtonEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.repositoryItemButtonEdit1.Name = "repositoryItemButtonEdit1";
            // 
            // skinRibbonGalleryBarItem2
            // 
            this.skinRibbonGalleryBarItem2.Alignment = DevExpress.XtraBars.BarItemLinkAlignment.Right;
            this.skinRibbonGalleryBarItem2.Caption = "Display";
            this.skinRibbonGalleryBarItem2.Id = 29;
            this.skinRibbonGalleryBarItem2.Name = "skinRibbonGalleryBarItem2";
            // 
            // barEditItem3
            // 
            this.barEditItem3.Caption = "Date";
            this.barEditItem3.Edit = this.repositoryItemDateEdit1;
            this.barEditItem3.Id = 30;
            this.barEditItem3.Name = "barEditItem3";
            this.barEditItem3.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barEditItem3_ItemClick);
            // 
            // repositoryItemDateEdit1
            // 
            this.repositoryItemDateEdit1.AutoHeight = false;
            this.repositoryItemDateEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemDateEdit1.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemDateEdit1.Name = "repositoryItemDateEdit1";
            // 
            // barEditItem5
            // 
            this.barEditItem5.Alignment = DevExpress.XtraBars.BarItemLinkAlignment.Right;
            this.barEditItem5.Caption = "barEditItem5";
            this.barEditItem5.Edit = this.repositoryItemRichTextEdit2;
            this.barEditItem5.Id = 33;
            this.barEditItem5.Name = "barEditItem5";
            // 
            // repositoryItemRichTextEdit2
            // 
            this.repositoryItemRichTextEdit2.Name = "repositoryItemRichTextEdit2";
            this.repositoryItemRichTextEdit2.ShowCaretInReadOnly = false;
            // 
            // barEditItem6
            // 
            this.barEditItem6.Caption = "barEditItem6";
            this.barEditItem6.Edit = this.repositoryItemRichTextEdit3;
            this.barEditItem6.Id = 34;
            this.barEditItem6.Name = "barEditItem6";
            // 
            // repositoryItemRichTextEdit3
            // 
            this.repositoryItemRichTextEdit3.Name = "repositoryItemRichTextEdit3";
            this.repositoryItemRichTextEdit3.ShowCaretInReadOnly = false;
            // 
            // barEditItem7
            // 
            this.barEditItem7.Caption = "Author";
            this.barEditItem7.Edit = this.repositoryItemRichTextEdit4;
            this.barEditItem7.Id = 35;
            this.barEditItem7.Name = "barEditItem7";
            // 
            // repositoryItemRichTextEdit4
            // 
            this.repositoryItemRichTextEdit4.Name = "repositoryItemRichTextEdit4";
            this.repositoryItemRichTextEdit4.ShowCaretInReadOnly = false;
            // 
            // barEditItem8
            // 
            this.barEditItem8.Alignment = DevExpress.XtraBars.BarItemLinkAlignment.Right;
            this.barEditItem8.Caption = "Author: DPSG Team";
            this.barEditItem8.Edit = this.repositoryItemButtonEdit2;
            this.barEditItem8.Id = 36;
            this.barEditItem8.Name = "barEditItem8";
            // 
            // repositoryItemButtonEdit2
            // 
            this.repositoryItemButtonEdit2.AutoHeight = false;
            this.repositoryItemButtonEdit2.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.repositoryItemButtonEdit2.Name = "repositoryItemButtonEdit2";
            // 
            // skinRibbonGalleryBarItem3
            // 
            this.skinRibbonGalleryBarItem3.Alignment = DevExpress.XtraBars.BarItemLinkAlignment.Right;
            this.skinRibbonGalleryBarItem3.Caption = "Display";
            this.skinRibbonGalleryBarItem3.Id = 37;
            this.skinRibbonGalleryBarItem3.Name = "skinRibbonGalleryBarItem3";
            // 
            // ribbonPage6
            // 
            this.ribbonPage6.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup8});
            this.ribbonPage6.Name = "ribbonPage6";
            this.ribbonPage6.Text = "Thống kê";
            // 
            // ribbonPageGroup8
            // 
            this.ribbonPageGroup8.Name = "ribbonPageGroup8";
            this.ribbonPageGroup8.Text = "ribbonPageGroup8";
            // 
            // ribbonPage8
            // 
            this.ribbonPage8.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup10});
            this.ribbonPage8.Name = "ribbonPage8";
            this.ribbonPage8.Text = "Báo cáo";
            // 
            // ribbonPageGroup10
            // 
            this.ribbonPageGroup10.Name = "ribbonPageGroup10";
            this.ribbonPageGroup10.Text = "ribbonPageGroup10";
            // 
            // ribbonPage9
            // 
            this.ribbonPage9.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup11,
            this.ribbonPageGroup2,
            this.ribbonPageGroup6});
            this.ribbonPage9.Name = "ribbonPage9";
            this.ribbonPage9.Text = "Trợ giúp";
            // 
            // ribbonPageGroup11
            // 
            this.ribbonPageGroup11.ItemLinks.Add(this.barButtonItem11);
            this.ribbonPageGroup11.Name = "ribbonPageGroup11";
            this.ribbonPageGroup11.Text = "Thông tin phần mềm";
            // 
            // ribbonPageGroup2
            // 
            this.ribbonPageGroup2.ItemLinks.Add(this.barButtonItem2);
            this.ribbonPageGroup2.Name = "ribbonPageGroup2";
            this.ribbonPageGroup2.Text = "Thông tin tác giả";
            // 
            // ribbonPageGroup6
            // 
            this.ribbonPageGroup6.Name = "ribbonPageGroup6";
            this.ribbonPageGroup6.Text = "ribbonPageGroup6";
            // 
            // ribbonPage10
            // 
            this.ribbonPage10.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup12});
            this.ribbonPage10.Name = "ribbonPage10";
            this.ribbonPage10.Text = "Thoát";
            // 
            // ribbonPageGroup12
            // 
            this.ribbonPageGroup12.Name = "ribbonPageGroup12";
            this.ribbonPageGroup12.Text = "ribbonPageGroup12";
            // 
            // rbsStatus
            // 
            this.rbsStatus.ItemLinks.Add(this.barEditItem2);
            this.rbsStatus.ItemLinks.Add(this.barEditItem3);
            this.rbsStatus.ItemLinks.Add(this.barEditItem8);
            this.rbsStatus.ItemLinks.Add(this.skinRibbonGalleryBarItem3);
            this.rbsStatus.Location = new System.Drawing.Point(0, 527);
            this.rbsStatus.Name = "rbsStatus";
            this.rbsStatus.Ribbon = this.menuToolStrip;
            this.rbsStatus.Size = new System.Drawing.Size(1247, 31);
            // 
            // ribbonPage7
            // 
            this.ribbonPage7.Name = "ribbonPage7";
            // 
            // ribbonPageGroup9
            // 
            this.ribbonPageGroup9.Name = "ribbonPageGroup9";
            // 
            // ctxtMenuTapDispaly
            // 
            this.ctxtMenuTapDispaly.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSeparator1,
            this.closeToolStripMenuItem,
            this.toolStripSeparator2,
            this.colseAllTabToolStripMenuItem});
            this.ctxtMenuTapDispaly.Name = "ctxtMenuTapDispaly";
            this.ctxtMenuTapDispaly.Size = new System.Drawing.Size(143, 60);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(139, 6);
            // 
            // closeToolStripMenuItem
            // 
            this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
            this.closeToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.closeToolStripMenuItem.Text = "Close";
            this.closeToolStripMenuItem.Click += new System.EventHandler(this.closeToolStripMenuItem_Click_1);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(139, 6);
            // 
            // colseAllTabToolStripMenuItem
            // 
            this.colseAllTabToolStripMenuItem.Name = "colseAllTabToolStripMenuItem";
            this.colseAllTabToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.colseAllTabToolStripMenuItem.Text = "Colse All Tab";
            this.colseAllTabToolStripMenuItem.Click += new System.EventHandler(this.colseAllTapToolStripMenuItem_Click);
            // 
            // barButtonItem1
            // 
            this.barButtonItem1.Caption = "barButtonItem1";
            this.barButtonItem1.Id = 23;
            this.barButtonItem1.Name = "barButtonItem1";
            this.barButtonItem1.RememberLastCommand = true;
            // 
            // barEditItem4
            // 
            this.barEditItem4.Edit = null;
            this.barEditItem4.Id = -1;
            this.barEditItem4.Name = "barEditItem4";
            // 
            // tabDisplay
            // 
            this.tabDisplay.ContextMenuStrip = this.ctxtMenuTapDispaly;
            this.tabDisplay.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabDisplay.DrawMode = System.Windows.Forms.TabDrawMode.OwnerDrawFixed;
            this.tabDisplay.Location = new System.Drawing.Point(0, 143);
            this.tabDisplay.Name = "tabDisplay";
            this.tabDisplay.SelectedIndex = 0;
            this.tabDisplay.Size = new System.Drawing.Size(1247, 384);
            this.tabDisplay.TabIndex = 3;
            this.tabDisplay.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.tabDisplay_DrawItem_1);
            this.tabDisplay.MouseDown += new System.Windows.Forms.MouseEventHandler(this.tabDisplay_MouseDown);
            // 
            // frmMain
            // 
            this.Appearance.BackColor = System.Drawing.Color.Yellow;
            this.Appearance.Options.UseBackColor = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayoutStore = System.Windows.Forms.ImageLayout.Tile;
            this.BackgroundImageStore = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImageStore")));
            this.ClientSize = new System.Drawing.Size(1247, 558);
            this.Controls.Add(this.tabDisplay);
            this.Controls.Add(this.rbsStatus);
            this.Controls.Add(this.menuToolStrip);
            this.Name = "frmMain";
            this.Ribbon = this.menuToolStrip;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.StatusBar = this.rbsStatus;
            this.Text = "QUẢN LÍ CỬA HÀNG VẬT TƯ - PHÂN BÓN";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMain_FormClosing);
            this.Load += new System.EventHandler(this.frmMain_Load);
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemRichTextEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.menuToolStrip)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.imageCL1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemRichTextEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemRichTextEdit3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemRichTextEdit4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemButtonEdit2)).EndInit();
            this.ctxtMenuTapDispaly.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage3;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage5;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage4;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup3;
        private DevExpress.XtraBars.Ribbon.RibbonPage managerToolStripMenuItem;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup pageGroupInfoOfAgency;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup pageGroupOfCustomer;
        private DevExpress.XtraBars.Ribbon.RibbonPage systemToolStripMenuItem;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup1;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup5;
        private DevExpress.XtraBars.Ribbon.RibbonControl menuToolStrip;
        private DevExpress.XtraBars.Ribbon.RibbonStatusBar rbsStatus;
        private DevExpress.XtraBars.BarButtonItem btnLogin;
        private DevExpress.XtraBars.BarButtonItem btnChangePassWord;
        private DevExpress.XtraBars.BarButtonItem btnLogout;
        private DevExpress.XtraBars.BarButtonItem btnDecentralization1;
        private DevExpress.XtraBars.BarButtonItem btnBackup;
        private DevExpress.XtraBars.BarButtonItem btnRestore;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup4;
        private DevExpress.XtraBars.BarButtonItem btnDecentralization;
        private DevExpress.XtraBars.BarButtonItem barButtonItem5;
        private DevExpress.Utils.ImageCollection imageCL1;
        private DevExpress.XtraBars.BarButtonItem barButtonItem9;
        private DevExpress.XtraBars.BarButtonItem barButtonItem10;
        private DevExpress.XtraBars.BarButtonItem btnInfoAgency;
        private DevExpress.XtraBars.BarButtonItem btnProductOfAgency;
        private DevExpress.XtraBars.BarButtonItem btnInfoOfCustomer;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup pageGroupOfBills;
        private DevExpress.XtraBars.BarButtonItem btnBill;
        private DevExpress.XtraBars.BarButtonItem barButtonItem7;
        private DevExpress.XtraBars.BarButtonItem btnBillOfExportProduct;
        private DevExpress.XtraBars.BarButtonItem barButtonItem4;
        private DevExpress.XtraBars.BarButtonItem barButtonItem11;
        private DevExpress.XtraBars.BarButtonItem barButtonItem12;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage6;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup8;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage8;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup10;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage9;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup11;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage7;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup9;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage10;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup12;
        private DevExpress.XtraBars.SkinRibbonGalleryBarItem skinRibbonGalleryBarItem1;
        private System.Windows.Forms.ContextMenuStrip ctxtMenuTapDispaly;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem closeToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem colseAllTabToolStripMenuItem;
        private DevExpress.XtraBars.BarButtonItem barButtonItem1;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup pageGroupStore;
        private DevExpress.XtraBars.BarButtonItem btnProductOfStore;
        private DevExpress.XtraBars.BarButtonItem barButtonItem2;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup2;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup6;
        private DevExpress.XtraBars.BarEditItem barEditItem1;
        private DevExpress.XtraBars.BarHeaderItem barHeaderItem1;
        private DevExpress.XtraBars.BarEditItem barEditItem2;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit repositoryItemButtonEdit1;
        private DevExpress.XtraBars.SkinRibbonGalleryBarItem skinRibbonGalleryBarItem2;
        private DevExpress.XtraBars.BarEditItem barEditItem3;
        private DevExpress.XtraEditors.Repository.RepositoryItemDateEdit repositoryItemDateEdit1;
        private DevExpress.XtraEditors.Repository.RepositoryItemRichTextEdit repositoryItemRichTextEdit1;
        private DevExpress.XtraBars.BarEditItem barEditItem5;
        private DevExpress.XtraEditors.Repository.RepositoryItemRichTextEdit repositoryItemRichTextEdit2;
        private DevExpress.XtraBars.BarEditItem barEditItem6;
        private DevExpress.XtraEditors.Repository.RepositoryItemRichTextEdit repositoryItemRichTextEdit3;
        private DevExpress.XtraBars.BarEditItem barEditItem7;
        private DevExpress.XtraEditors.Repository.RepositoryItemRichTextEdit repositoryItemRichTextEdit4;
        private DevExpress.XtraBars.BarEditItem barEditItem4;
        private DevExpress.XtraBars.BarEditItem barEditItem8;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit repositoryItemButtonEdit2;
        private DevExpress.XtraBars.SkinRibbonGalleryBarItem skinRibbonGalleryBarItem3;
        private System.Windows.Forms.TabControl tabDisplay;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BanVeXeKhach.UserControls
{
    public partial class UcTextbox_1 : UserControl
    {
        public UcTextbox_1()
        {
            InitializeComponent();
        }
    }
}

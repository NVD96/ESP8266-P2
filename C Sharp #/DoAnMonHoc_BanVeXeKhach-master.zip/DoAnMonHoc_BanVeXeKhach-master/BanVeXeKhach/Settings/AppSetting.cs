﻿
namespace BanVeXeKhach.Settings
{
    public class AppSetting
    {
        public static bool ConfiguredEmail = false;
        public static bool ConfiguredSqlServer = false;
        public static bool ConfiguredDefaultData = false;

        public static bool RunInstallationProcess = true;
        public static bool CompletedInstallationProcess = false;
    }
}

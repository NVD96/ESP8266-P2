﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;

namespace TCPserver
{
    class Program
    {
        static void Main(string[] args)
        {

            int port = 8001;            
            IPAddress ipAddress = IPAddress.Any;        
            TcpClient client = null;
            ASCIIEncoding encoder = new ASCIIEncoding();
            byte[] buffer;
            TcpListener listener = null;
            try
            {
                listener = new TcpListener(ipAddress, port);
                listener.Start();
                Console.WriteLine("Server is running");
                Console.WriteLine("Listening on port " + port);
                Console.WriteLine("Waiting for connections...");
                while (true)
                {
                    client = listener.AcceptTcpClient();

                    using (NetworkStream stream = client.GetStream())
                    {
                        buffer = new byte[1024];
                        stream.Read(buffer, 0, buffer.Length);
                        Console.WriteLine(encoder.GetString(buffer));
                        // server odpovie dakujem za spravicku
                        stream.Write(encoder.GetBytes("dakujem za spravicku"), 0, ("dakujem za spravicku").Length);                    
                    }
                }
            }
            catch (Exception ex1)
            {
                Console.WriteLine(ex1.Message);
            }
            finally
            {
                if (client != null)
                {
                    client.Close();
                }
                listener.Stop();
            }
        }
    }
}

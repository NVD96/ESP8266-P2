﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Sockets;
using System.Threading;


namespace TCP_client
{
    /// <summary>
    /// TCP client - www.projectik.eu
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            try
            {

                string ipServer = "127.0.0.1";
                int portServer = 8001;
                String str = String.Empty;
                int timeout = 1000;
                int myTime = 0;
                bool statusTimeOut = false;
                List<byte> buffer = new List<byte>();

                Console.WriteLine("Connecting.....");

                //zadame text na odoslanie
                Console.WriteLine("Enter the string to be transmitted : ");

                //nacitanie zadaneho textu do premennej
                str = Console.ReadLine();

                using (TcpClient client = new TcpClient(ipServer, portServer))
                {
                    //Client sa uspesne pripojil
                    Console.WriteLine("Connected");

                    client.ReceiveTimeout = 3000;
                    client.SendTimeout = 3000;


                    using (NetworkStream stream = client.GetStream())
                    {
                        stream.Write(ASCIIEncoding.ASCII.GetBytes(str), 0, str.Length);

                        //cakanie na odpoved od servera
                        while (stream.DataAvailable == false)
                        {                           
                            Thread.Sleep(1);
                            if (++myTime > timeout)
                            {
                                statusTimeOut = true;
                                break;
                            }
                        }

                        if (statusTimeOut)
                        {
                             Console.Write("Time out.");
                            return;
                        }
                        //citaj pokial su data
                        while (stream.DataAvailable)
                        {
                            buffer.Add((byte)stream.ReadByte());
                        }
                    }
                    Console.WriteLine("Server reply : ");
                    //Vypiseme co poslal server
                    Console.WriteLine(ASCIIEncoding.ASCII.GetString(buffer.ToArray()));
                    Console.ReadLine();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Error..... " + e.Message);
            }
        }
    }
}

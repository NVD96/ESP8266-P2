﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Sockets;
using System.Net;

namespace TCP_client
{
    /// <summary>
    /// TCP client - www.projectik.eu
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                String str = String.Empty;
                IPEndPoint iep = new IPEndPoint(IPAddress.Any, 8001);
                byte[] buffer = new byte[4096]; //buffer 4kB

                Console.WriteLine("Connecting.....");
                //zadame text na odoslanie
                Console.WriteLine("Enter the string to be transmitted : ");
                //nacitanie zadaneho textu do premennej
                str = Console.ReadLine();

                using (Socket sock = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp))
                {
                    sock.Connect(iep);

                    //Client sa uspesne pripojil
                    Console.WriteLine("Connected");

                    //set timeout
                    sock.ReceiveTimeout = 3000;
                    sock.SendTimeout = 3000;

                    //Convertovenie stringu na byte array
                    byte[] data = Encoding.ASCII.GetBytes(str);

                    //odoslanie spravy
                    sock.Send(data, data.Length, SocketFlags.None);

                    //prijatie odpovede od servera
                    int numberOfBytes = sock.Receive(buffer);

                    byte[] formatedBytes = new byte[numberOfBytes];
                    Array.Copy(buffer, formatedBytes, numberOfBytes);

                    //Vypiseme co poslal server
                    Console.WriteLine("Server reply : ");
                    Console.WriteLine(ASCIIEncoding.ASCII.GetString(formatedBytes.ToArray()));
                    Console.ReadLine();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Error..... " + e.Message);
            }
        }
    }
}

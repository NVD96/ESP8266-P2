﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.Net.Sockets;

namespace TCPserver
{
    class Program
    {
        static void Main(string[] args)
        {

            byte[] buffer = new byte[4096];//4kb buffer

            try
            {

                Console.WriteLine("Server is running");
                Console.WriteLine("Waiting for connections...");

                using (Socket sock = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp))
                {

                    //nacuvanie od vsetkych IP adries
                    IPEndPoint iep = new IPEndPoint(IPAddress.Any, 8001);

                    sock.Bind(iep);
                    sock.Listen(1);

                    while (true)
                    {
                        Socket listener = sock.Accept();
                        // sock.Poll(0, SelectMode.SelectRead);                        

                        if (listener.Connected)
                        {
                            //prijatie odpovede od servera
                            int numberOfBytes = listener.Receive(buffer);

                            byte[] formatedBytes = new byte[numberOfBytes];
                            Array.Copy(buffer, formatedBytes, numberOfBytes);

                            //Vypiseme co poslal server
                            Console.WriteLine("Client send : ");
                            Console.WriteLine(ASCIIEncoding.ASCII.GetString(formatedBytes));                         

                            //Odpoved servera
                            byte[] data = Encoding.ASCII.GetBytes("dakujem za spravicku");
                            listener.Send(data, data.Length, SocketFlags.None);
                        }
                    }
                }               
            }
            catch (Exception ex1)
            {
                Console.WriteLine(ex1.Message);
            }        
        }
    }
}


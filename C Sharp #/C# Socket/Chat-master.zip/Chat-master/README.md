<h3>C# TCP Client - Server Chat Application</h3>

This project is Client - Server messaging application using TCP with C#. 
Private messaging is encrypted with the RSA algorithm.


<img src="https://raw.githubusercontent.com/candan-ahmet/Chat/master/server.jpg" />
<img src="https://raw.githubusercontent.com/candan-ahmet/Chat/master/client.jpg" />
<img src="https://raw.githubusercontent.com/candan-ahmet/Chat/master/client-private-message.jpg" />

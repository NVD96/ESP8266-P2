using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace SettingsLib
{
	/// <summary>
	/// Descrizione di riepilogo per UserControl1.
	/// </summary>
	public class Impostazioni : System.Windows.Forms.UserControl
	{
		private System.Windows.Forms.TabControl SettingsTab;
		private System.Windows.Forms.TabPage Visualizzazione;
		private System.Windows.Forms.TabPage Opzioni;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.FontDialog fontDialog1;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.GroupBox FontBox;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.ColorDialog colorDialog1;
		private System.Windows.Forms.Button CambiaFontLocale;
		private System.Windows.Forms.Button CambiaFontRemoto;
		private System.Windows.Forms.Button CambiaColoreLocale;
		private System.Windows.Forms.Button CambiaColoreRemoto;
		public System.Windows.Forms.TextBox Local;
		public System.Windows.Forms.TextBox Remote;
		public  System.Windows.Forms.TextBox UserName;
		public  System.Windows.Forms.TextBox LogPath;
		
		/// <summary>
		/// Variabile di progettazione necessaria.
		/// </summary>
		private System.ComponentModel.Container components = null;
		private System.Windows.Forms.GroupBox BackBox;
		private System.Windows.Forms.OpenFileDialog openFileDialog1;
		public System.Windows.Forms.PictureBox pictureBox1;
		public System.Windows.Forms.Label BackPath;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Button ButtonBrowseImg;
		private System.Windows.Forms.Button CancButton;
		private System.Windows.Forms.Button ButtonBrowseLog;
		private System.Windows.Forms.SaveFileDialog saveFileDialog1;

		public bool AcceptChanges;

		public Impostazioni()
		{
			//
			// Necessario per il supporto di Progettazione Windows Form
			//
			InitializeComponent();

			this.fontDialog1.ShowColor=true;
			this.fontDialog1.ShowEffects=true;
			
			
			this.colorDialog1.AnyColor=true;
			
		

		}

	

		/// <summary>
		/// Pulire le risorse in uso.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Metodo necessario per il supporto della finestra di progettazione. Non modificare
		/// il contenuto del metodo con l'editor di codice.
		/// </summary>
		private void InitializeComponent()
		{
			this.SettingsTab = new System.Windows.Forms.TabControl();
			this.Visualizzazione = new System.Windows.Forms.TabPage();
			this.BackBox = new System.Windows.Forms.GroupBox();
			this.label5 = new System.Windows.Forms.Label();
			this.ButtonBrowseImg = new System.Windows.Forms.Button();
			this.BackPath = new System.Windows.Forms.Label();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.FontBox = new System.Windows.Forms.GroupBox();
			this.CambiaColoreRemoto = new System.Windows.Forms.Button();
			this.CambiaColoreLocale = new System.Windows.Forms.Button();
			this.CambiaFontRemoto = new System.Windows.Forms.Button();
			this.CambiaFontLocale = new System.Windows.Forms.Button();
			this.Remote = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.Local = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.Opzioni = new System.Windows.Forms.TabPage();
			this.ButtonBrowseLog = new System.Windows.Forms.Button();
			this.LogPath = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.UserName = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.fontDialog1 = new System.Windows.Forms.FontDialog();
			this.colorDialog1 = new System.Windows.Forms.ColorDialog();
			this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
			this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
			this.SettingsTab.SuspendLayout();
			this.Visualizzazione.SuspendLayout();
			this.BackBox.SuspendLayout();
			this.FontBox.SuspendLayout();
			this.Opzioni.SuspendLayout();
			this.SuspendLayout();
			// 
			// SettingsTab
			// 
			this.SettingsTab.Controls.AddRange(new System.Windows.Forms.Control[] {
																					  this.Visualizzazione,
																					  this.Opzioni});
			this.SettingsTab.Location = new System.Drawing.Point(8, 8);
			this.SettingsTab.Name = "SettingsTab";
			this.SettingsTab.SelectedIndex = 0;
			this.SettingsTab.Size = new System.Drawing.Size(560, 312);
			this.SettingsTab.TabIndex = 0;
			// 
			// Visualizzazione
			// 
			this.Visualizzazione.Controls.AddRange(new System.Windows.Forms.Control[] {
																						  this.BackBox,
																						  this.FontBox});
			this.Visualizzazione.Location = new System.Drawing.Point(4, 22);
			this.Visualizzazione.Name = "Visualizzazione";
			this.Visualizzazione.Size = new System.Drawing.Size(552, 286);
			this.Visualizzazione.TabIndex = 0;
			this.Visualizzazione.Text = "Visualizzazione";
			// 
			// BackBox
			// 
			this.BackBox.Controls.AddRange(new System.Windows.Forms.Control[] {
																				  this.label5,
																				  this.ButtonBrowseImg,
																				  this.BackPath,
																				  this.pictureBox1});
			this.BackBox.Location = new System.Drawing.Point(8, 176);
			this.BackBox.Name = "BackBox";
			this.BackBox.Size = new System.Drawing.Size(536, 100);
			this.BackBox.TabIndex = 3;
			this.BackBox.TabStop = false;
			this.BackBox.Text = "Background";
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(104, 16);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(424, 23);
			this.label5.TabIndex = 3;
			this.label5.Text = "Permette di specificare un\'immagine di sfondo, che deve essere in formato 460x405" +
				"";
			this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// ButtonBrowseImg
			// 
			this.ButtonBrowseImg.Location = new System.Drawing.Point(448, 64);
			this.ButtonBrowseImg.Name = "ButtonBrowseImg";
			this.ButtonBrowseImg.TabIndex = 2;
			this.ButtonBrowseImg.Text = "Sfoglia";
			this.ButtonBrowseImg.Click += new System.EventHandler(this.Browse_Click);
			// 
			// BackPath
			// 
			this.BackPath.Location = new System.Drawing.Point(112, 56);
			this.BackPath.Name = "BackPath";
			this.BackPath.Size = new System.Drawing.Size(320, 40);
			this.BackPath.TabIndex = 1;
			this.BackPath.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// pictureBox1
			// 
			this.pictureBox1.Location = new System.Drawing.Point(8, 16);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(88, 80);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox1.TabIndex = 0;
			this.pictureBox1.TabStop = false;
			// 
			// FontBox
			// 
			this.FontBox.Controls.AddRange(new System.Windows.Forms.Control[] {
																				  this.CambiaColoreRemoto,
																				  this.CambiaColoreLocale,
																				  this.CambiaFontRemoto,
																				  this.CambiaFontLocale,
																				  this.Remote,
																				  this.label4,
																				  this.Local,
																				  this.label3});
			this.FontBox.Location = new System.Drawing.Point(8, 8);
			this.FontBox.Name = "FontBox";
			this.FontBox.Size = new System.Drawing.Size(536, 160);
			this.FontBox.TabIndex = 2;
			this.FontBox.TabStop = false;
			this.FontBox.Text = "Font";
			// 
			// CambiaColoreRemoto
			// 
			this.CambiaColoreRemoto.Location = new System.Drawing.Point(200, 104);
			this.CambiaColoreRemoto.Name = "CambiaColoreRemoto";
			this.CambiaColoreRemoto.TabIndex = 7;
			this.CambiaColoreRemoto.Text = "Pi� colori";
			this.CambiaColoreRemoto.Click += new System.EventHandler(this.CambiaColoreRemoto_Click);
			// 
			// CambiaColoreLocale
			// 
			this.CambiaColoreLocale.Location = new System.Drawing.Point(200, 32);
			this.CambiaColoreLocale.Name = "CambiaColoreLocale";
			this.CambiaColoreLocale.TabIndex = 6;
			this.CambiaColoreLocale.Text = "Pi� colori";
			this.CambiaColoreLocale.Click += new System.EventHandler(this.CambiaColoreLocale_Click);
			// 
			// CambiaFontRemoto
			// 
			this.CambiaFontRemoto.Location = new System.Drawing.Point(112, 104);
			this.CambiaFontRemoto.Name = "CambiaFontRemoto";
			this.CambiaFontRemoto.TabIndex = 5;
			this.CambiaFontRemoto.Text = "Cambia font";
			this.CambiaFontRemoto.Click += new System.EventHandler(this.CambiaFontRemoto_Click);
			// 
			// CambiaFontLocale
			// 
			this.CambiaFontLocale.Location = new System.Drawing.Point(112, 32);
			this.CambiaFontLocale.Name = "CambiaFontLocale";
			this.CambiaFontLocale.TabIndex = 4;
			this.CambiaFontLocale.Text = "Cambia font";
			this.CambiaFontLocale.Click += new System.EventHandler(this.CambiaFontLocale_Click);
			// 
			// Remote
			// 
			this.Remote.AutoSize = false;
			this.Remote.Location = new System.Drawing.Point(304, 88);
			this.Remote.Name = "Remote";
			this.Remote.Size = new System.Drawing.Size(224, 56);
			this.Remote.TabIndex = 3;
			this.Remote.Text = "Testo di esempio";
			this.Remote.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(24, 104);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(88, 24);
			this.label4.TabIndex = 2;
			this.label4.Text = "Utente Remoto";
			this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// Local
			// 
			this.Local.AutoSize = false;
			this.Local.Location = new System.Drawing.Point(304, 16);
			this.Local.Name = "Local";
			this.Local.Size = new System.Drawing.Size(224, 56);
			this.Local.TabIndex = 0;
			this.Local.Text = "Testo di esempio";
			this.Local.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(24, 32);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(88, 24);
			this.label3.TabIndex = 1;
			this.label3.Text = "Utente Locale";
			this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// Opzioni
			// 
			this.Opzioni.Controls.AddRange(new System.Windows.Forms.Control[] {
																				  this.ButtonBrowseLog,
																				  this.LogPath,
																				  this.label2,
																				  this.UserName,
																				  this.label1});
			this.Opzioni.Location = new System.Drawing.Point(4, 22);
			this.Opzioni.Name = "Opzioni";
			this.Opzioni.Size = new System.Drawing.Size(552, 310);
			this.Opzioni.TabIndex = 1;
			this.Opzioni.Text = "Opzioni utente";
			// 
			// ButtonBrowseLog
			// 
			this.ButtonBrowseLog.Location = new System.Drawing.Point(440, 72);
			this.ButtonBrowseLog.Name = "ButtonBrowseLog";
			this.ButtonBrowseLog.TabIndex = 4;
			this.ButtonBrowseLog.Text = "Sfoglia";
			this.ButtonBrowseLog.Click += new System.EventHandler(this.ButtonBrowseLog_Click);
			// 
			// LogPath
			// 
			this.LogPath.Location = new System.Drawing.Point(120, 72);
			this.LogPath.Name = "LogPath";
			this.LogPath.Size = new System.Drawing.Size(304, 20);
			this.LogPath.TabIndex = 3;
			this.LogPath.Text = "";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(8, 72);
			this.label2.Name = "label2";
			this.label2.TabIndex = 2;
			this.label2.Text = "Log path";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// UserName
			// 
			this.UserName.Location = new System.Drawing.Point(120, 24);
			this.UserName.Name = "UserName";
			this.UserName.Size = new System.Drawing.Size(184, 20);
			this.UserName.TabIndex = 1;
			this.UserName.Text = "";
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(16, 24);
			this.label1.Name = "label1";
			this.label1.TabIndex = 0;
			this.label1.Text = "Nome Utente";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// saveFileDialog1
			// 
			this.saveFileDialog1.FileName = "doc1";
			// 
			// Impostazioni
			// 
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.SettingsTab});
			this.Name = "Impostazioni";
			this.Size = new System.Drawing.Size(576, 328);
			this.SettingsTab.ResumeLayout(false);
			this.Visualizzazione.ResumeLayout(false);
			this.BackBox.ResumeLayout(false);
			this.FontBox.ResumeLayout(false);
			this.Opzioni.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		private void CambiaFontLocale_Click(object sender, System.EventArgs e)
		{
		
			this.fontDialog1.Font=this.Local.Font;
			this.fontDialog1.Color=this.Local.ForeColor;

			this.fontDialog1.ShowDialog();

			this.Local.Font=this.fontDialog1.Font;
			this.Local.ForeColor=this.fontDialog1.Color;
			this.Local.Update();
		}
		
		private void CambiaFontRemoto_Click(object sender, System.EventArgs e)
		{
			this.fontDialog1.Font=this.Remote.Font;
			this.fontDialog1.Color=this.Local.ForeColor;

			this.fontDialog1.ShowDialog();

			this.Remote.Font=this.fontDialog1.Font;
			this.Remote.ForeColor=this.fontDialog1.Color;
			this.Remote.Update();
		
		}
		private void CambiaColoreLocale_Click(object sender, System.EventArgs e)
		{
			
			this.colorDialog1.ShowDialog();
			this.Local.ForeColor=this.colorDialog1.Color;
			this.Local.Update();
		}

		private void CambiaColoreRemoto_Click(object sender, System.EventArgs e)
		{
			this.colorDialog1.ShowDialog();
			this.Remote.ForeColor=this.colorDialog1.Color;
			this.Remote.Update();
		}

		private void Browse_Click(object sender, System.EventArgs e)
		{
			this.openFileDialog1.Filter="File Grafici (*.jpg;*.bmp;*.gif)|*.jpg;*.bmp;*.gif|Tutti i file (*.*)|*.*";
			this.openFileDialog1.ShowDialog();

			if (this.openFileDialog1.FileName!=null)
			{
				try
				{
					
					this.pictureBox1.Image=Image.FromFile(this.openFileDialog1.FileName);
					this.BackPath.Text=this.openFileDialog1.FileName;
				}
				catch
				{
					//Strumenti.Error("File non valido");
				}

			}
		}

		private void ButtonBrowseLog_Click(object sender, System.EventArgs e)
		{
			this.saveFileDialog1.Filter="File Rich Text Format (*.rtf)|*.rtf|Tutti i file (*.*)|*.*";
			this.saveFileDialog1.InitialDirectory=this.LogPath.Text;
			this.saveFileDialog1.FileName=this.LogPath.Text;
			this.saveFileDialog1.ShowDialog();
			if (this.saveFileDialog1.FileName!=null)
			{
				this.LogPath.Text=this.saveFileDialog1.FileName;
			}
			
		}


		private void CancelButton_Click(object sender, System.EventArgs e)
		{
			this.AcceptChanges=false;
			//this.Close();
		}

		
		private void OkButton_Click(object sender, System.EventArgs e)
		{
			this.AcceptChanges=true;
			//this.Close();
		}

		
		

		
		
		
		
	}
}

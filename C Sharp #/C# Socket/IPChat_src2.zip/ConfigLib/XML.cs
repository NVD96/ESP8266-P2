using System;
using System.IO;
using System.Xml;
using System.Xml.Schema;
using System.Collections;
using System.Data;
//using LidoZ.Modules.Tech.Admin.GuidoZ;

namespace ConfigLib.Config
{
	/// <summary>
	/// Consente di eseguire la validazione di un file XML utilizzando uno schema file .XSD
	/// </summary>
	public class ValidatoreXML 
	{//By GM
		

		private XmlValidatingReader myXmlValidatingReader = null;
		private XmlTextReader myXmlTextReader = null;
		
		
		private Boolean Success = true;
		private Boolean Debug = false; //impostare a false per evitare l'output indesiderato
		
		
		/// <summary>
		/// Restituisce lo stato della validazione (true=documento valido, false=vdocumento non valido)
		/// </summary>
		/// <returns></returns>
		public Boolean GetStat()
		{
			return Success;
		}

		
		/// <summary>
		/// Consente l'accesso a una variabile che definisce la quantit� di output che viene genereato
		/// in seguito all'esecuzione dei vari membtri. L'output generato � del tipo Console.Writeline(..);
		/// </summary>
		public Boolean DebugStat
		{
			get
			{
				return Debug;
			}

			set
			{
				Debug=value;	
			}
		}

		
		/// <summary>
		/// Iniza la validazione del file XML.
		/// </summary>
		/// <param name="arg0">File XML da Validare</param>
		/// <param name="arg1">Schema .XSD da usare per validare</param>
		public void Run(String arg0, String arg1) //arg0 � il file XML; arg1 � il file XSD
		{//By GM
			
			try
			{
          
				XmlSchemaCollection myXmlSchemaCollection = new XmlSchemaCollection();
				myXmlSchemaCollection.Add("articolo.xsd" , new XmlTextReader(arg1));

				

				Success = true;
				Console.WriteLine();
				if (Debug) {Console.WriteLine("Validazione del file XML {0} con lo schema file {1} ...<br>",arg0,arg1);}
				//messaggi="Validazione del file XML "+arg0+" con lo schema file "+arg1+" ...";
				myXmlTextReader = new XmlTextReader (arg0);
				myXmlValidatingReader = new XmlValidatingReader(myXmlTextReader);
				myXmlValidatingReader.Schemas.Add(myXmlSchemaCollection);
				myXmlValidatingReader.ValidationType = ValidationType.Schema;
				Validate();
			}

			catch (Exception e)
			{
				if (Debug) {Console.WriteLine("<b>Eccezzione: </b>" + e.ToString()+"<br>");}
				Success = false;
			}

			finally
			{
				// Ha finito con XmlTextReader
				if (myXmlValidatingReader != null)
					myXmlValidatingReader.Close();
			}
		}

		
		
		/// <summary>
		/// Esegue la validazione, dopo che Run() ha configurato alcuni parametri.
		/// </summary>
		private void Validate()
		{//By GM
			try
			{
				//Imposta il gestore delgi eventi di validazione
				myXmlValidatingReader.ValidationEventHandler += new ValidationEventHandler (this.ValidationEventHandle);

				// Legge XML 
				while (myXmlValidatingReader.Read()){}
				if (Debug) {Console.WriteLine ("<br>Validazione: <b><u><font size=+1 color={0}", (Success==true ? "green>riuscita</font></u></b><br>" : "red> fallita</font></u></b><br>"));}
			}
			catch (XmlException e)
			{
				if (Debug) {Console.WriteLine ("<br><b>XmlException:</b> " + e.ToString()+"<br>");}
				Success = false;
			}

			catch (Exception e)
			{
				if (Debug) {Console.WriteLine ("<br><b>Exception:</b> " + e.ToString()+"<br>");}
				Success = false;
			}
		}

		
		
		/// <summary>
		/// Viene chiamato come gestore degli eventi di validazione
		/// </summary>
		
		public void ValidationEventHandle (object sender, ValidationEventArgs args)
		{
			Success = false;

			if (Debug) {Console.WriteLine("<br><font color=red><b>Errore di validazione:</b></font><font color=color=#990066> " + args.Message+"</font><br>");}

			if (args.Severity == XmlSeverityType.Warning)
			{
				if (Debug) {Console.WriteLine("<br>Nessuno schema trovato per effettuare la validazione<br>");}
			} 
			else
				if (args.Severity == XmlSeverityType.Error)
			{
			if (Debug) {Console.WriteLine("Si � verificato un errore di validazione durante la validazione dell'istanza del dovumento.<br>");}
			} 

			if (args.Exception != null) // errore di validazione dello chema XSD
			{
				if (Debug) {Console.WriteLine(args.Exception.SourceUri + "," +  args.Exception.LinePosition + "," +  args.Exception.LineNumber+"<br>");}
				else{Console.WriteLine("<br>Errore XML alla riga "+args.Exception.LineNumber+" colonna " +args.Exception.LinePosition);}
			}

			//if (myXmlValidatingReader.Reader.LineNumber > 0)
			//{
			//    Console.WriteLine("Line: "+ myXmlValidatingReader.Reader.LineNumber + " Position: " + myXmlValidatingReader.Reader.LinePosition);
			//}
		

		}
	

	} // FIne di ValidaXML



	//*****************************************************************************************//


	/// <summary>
	/// Fornisce alcuni metodi aggiuntivi per utilizzare, scrivere e validare documenti XML.
	/// </summary>

	public class ControlloreXML: Base
	{

		//passata una directory al costruttore, i metodi sono usati per trovare il nome del
		//file XML presente in quella directory, per validarlo, o per leggerlo

		string XMLPath;
		string XMLFileName;
		string XMLRename;
		string FixedFile;
		public bool ReName;
		public bool DeletetempFiles;
		XmlDataDocument XMLDataDoc;
		ArrayList TempFiles;

		/* Errori
		 * =0 OK; 
		 * =1 IOException; 
		 * =2 Nessun File XML Trovato prima di eseguire la validazione;
		 * =3 Validazione Fallita per qualche motivo (es. documento non valido)
		 * =4 Impossibile eliminare la directory
		 * =5 Impossibile rinominare il file validato
		 * =6 Impossibile modificare XMLDataDocument
		 * =9 L'oggetto non � ancora stato configurato
		 */
		
		
		/// <summary>
		/// Inizializza l'oggetto legandolo ad un file XML
		/// </summary>
		/// <param name="laPath">path del file XML su cui lavorare. Usare TrovaXML per associare
		/// il nome di un file XML</param>
		public ControlloreXML(string laPath)
		{//By GM
			Inizializza(laPath);
			
		}


		/// <summary>
		/// Inizializza l'oggetto legandolo ad un file XML
		/// </summary>
		/// <param name="laPath">path del file XML su cui lavorare</param>
		/// <param name="ilNome">nome del file xml su cui lavorare</param>
		public ControlloreXML(string laPath, string ilNome)
		{//By GM
			XMLFileName=ilNome;
			Inizializza(laPath);
		}

		
		
		/// <summary>
		/// Usato dal costruttore per inizializzare l'oggetto
		/// </summary>
		/// <param name="laPath">path del file XML, senza il suo nome</param>
		private void Inizializza(string laPath)
		{//By GM

			this.TempFiles=new ArrayList();
			FixedFile="";
			ReName=true;
			XMLPath=laPath;
			XMLRename="valido.xml";
			XMLDataDoc = new XmlDataDocument();
			VerificatiErrori=9;
			this.DeletetempFiles=true;
		
		}

		
		
		/// <summary>
		/// Nome da assegnare o gi� assegnato al file XML
		/// </summary>
		public string NomeXMLValidato
		{//By GM
			get
			{return XMLRename;}
			set
			{XMLRename=value;}
	
		}

		
		
		/// <summary>
		/// Cerca, salva nell'oggetto corrente e restituisce il nome del primo file XML trovato all'interno della directory 
		/// associata all'oggetto.
		/// </summary>
		/// <returns>Restituisce il nome completo path+nome del file presente nella direcory 
		/// associata all'oggetto corrente
		/// </returns>
		public string TrovaXML()
		{//By GM
			//ritorna il nome della directory+nome del file xml, se esiste. Una stringa di errore altrimenti
			
			try
			{
				DirectoryInfo di = new DirectoryInfo(XMLPath);
				FileInfo[] fiArr = di.GetFiles();
				XMLFileName="";
				foreach (FileInfo fri in fiArr)
				{
					if ((fri.Extension.ToLower().Equals(".xml")))
					{
						XMLFileName=fri.Name.ToLower().ToString();
						VerificatiErrori=0;
						if (DebugOn) output+="Trovato il file:"+XMLPath+"\\"+XMLFileName;
						return XMLPath+"\\"+XMLFileName;

					}
				}
				

			}
			catch (IOException e)
			
			{	
				VerificatiErrori=1;
				if (DebugOn) output+="0"+e.ToString();
				return "0"+e.ToString();

			}
			
			VerificatiErrori=2;
			if (DebugOn)  output+="Nessun file XML Presente";
			return "Nessun file XML Presente";

		}


		
		/// <summary>
		/// Restituisce la directory associata all'oggetto corrente
		/// </summary>
		public string GetXMLPath()
		{//By GM
			return XMLPath;
		}

		
		
		/// <summary>
		/// Restituisce il nome del file XML associato all'oggetto corrente
		/// </summary>
		public string GetXMLFileName()
		{//By GM
			return XMLFileName;
		}

		
		
		/// <summary>
		/// Restituisce il nome completo path+nome del file XML associato all'oggetto corrente.
		/// </summary>
		public string GetXMLFullName()
		{//By GM
			return XMLPath+"\\"+XMLFileName;
		}

		

		/// <summary>
		/// Imposta il nome (senza path) del file XML da usare per le operazioni
		/// </summary>
		/// <param name="nome"></param>
		public void SetXMLName(string nome)
		{
			XMLFileName=nome;
		}


		/// <summary>
		/// Cancella la directory associata all'oggetto corrente 
		/// </summary>
		public void CancellaDir()
		{//By GM
			DirectoryInfo XMLDir=new DirectoryInfo(XMLPath);
			try
			{
				XMLDir.Delete(true);
				//VerificatiErrori=0;
			}
			
			
			catch (IOException e)
			{	
				VerificatiErrori=4;
				 if (DebugOn) output+=e.ToString();
			}

		}

		
		
		/// <summary>
		/// Rinomina il file XML associato all'oggetto con il nome specificato dalla propriet�
		///  NomeXMLValidato
		/// </summary>
		private void RinominaXML()
		{//By GM
			FileInfo FileXML=new FileInfo(this.GetXMLFullName());
			try
			{
				FileXML.MoveTo(this.XMLPath+"\\"+this.XMLRename);
				//VerificatiErrori=0;
			}
			
			
			catch (IOException e)
			{	
				VerificatiErrori=5;
				
				if (DebugOn)
				{
					output+="Errore";
					output+=e.ToString();
				}
			}
		}

		
		/// <summary>
		/// 
		/// </summary>
		/// <param name="XMLFile">File in cui verificare la presenza del tag: 
		/// articolo xmlns="articolo.xsd". Se non presente, viene aggiunto</param>
		/// <returns>Restituisce l'url di un file XML uguale a quello d'ingresso ma
		/// con in pi� il tag</returns>
		public string FixXMLTag(string XMLFile)
		{
			this.LeggiXMLDataDoc(XMLFile);
			this.ModifyXMLNodeAttribute("articolo","articolo.xsd","xmlns");
			this.SalvaXMLDataDoc(XMLFile+".tmp");
			this.TempFiles.Add(XMLFile+".tmp");
			return XMLFile+".tmp";
		}


		/// <summary>
		/// Valida il file XML associato all'oggetto, con loo schema XSD fornito come
		/// parametro
		/// </summary>
		/// <param name="schema">Schema con cui validare il file XML</param>
		public string ValidaXML(string schema)
		{
			return this.ValidaXML(this.GetXMLFullName(),schema);
		}


		/// <summary>
		/// Valida il file XML passato come parametro, con uno schema passato come parametro e
		///  rinomina il file XML associato all'oggetto (non quello passato qui) con il nome 
		///  impostato con la propriet� NomeXMLValidato
		/// </summary>
		/// <param name="schema">Path completa (directory+nomefile) dello schema XSD da usare
		/// per validare il documento XML.</param>
		/// <param name="XMLFile">Nome completo (path+nomefile) del file XML da 
		/// validare.</param>
		public string ValidaXML(string XMLFile, string schema)
		{//By GM
			
			

			StringWriter writer = new StringWriter(); //ValidatoreXML scrive su STDOutput
			Console.SetOut(writer);
			if (this.GetErr==0) //se trova � stato eseguito correttamente 
			{
				ValidatoreXML myValidaXML = new ValidatoreXML();
				myValidaXML.DebugStat=this.DebugOn;

				try
				{
					myValidaXML.Run(XMLFile,schema);
				}
				catch(Exception e)
				{
					if (DebugOn) output+="Impossibile eseguire la validazione: " + e.ToString();
				}
				
				if (myValidaXML.GetStat()&&this.ReName)
				{
					this.RinominaXML();
				
				}
				else
				{
					VerificatiErrori=3;
					if (!DebugOn)
						this.CancellaDir();
				}//se non era valido, cancello i dati uploadati
				
				if (DebugOn) output+=writer.ToString();
				return writer.ToString();
			}
			else //Se non c'era un file da validare o altro.
			{
				return "Nessun file da validare";
			}
		}

		
		
		
		/// <summary>
		/// Cerca un item all'interno dell'XML associato, che deve essere prima caricato con +
		/// LeggiXMLDataDoc(). Restituisce un'ArrayList contenente tutti i XmlNode.InnerText trovati
		/// </summary>
		/// <param name="NomeItem">Nome dell'item da cercare</param>
		public ArrayList TrovaXMLItem(string NomeItem)
		{//by GM


			//Cerca gli Item specificati all'interno di XMLDataDoc, che
			//deve essere precedentemente riempito usando LeggiXMLDataDoc()
			//N.B. gli item sono identificati dai nomi dei Tag
			ArrayList ItemTrovati=new ArrayList();
			
			try
			{
			
				XmlNodeList xnl=XMLDataDoc.GetElementsByTagName(NomeItem);
				foreach (XmlNode n in xnl)
				{
					ItemTrovati.Add(n.InnerText);
				}

				return ItemTrovati;
			}
			
			catch(Exception e)
			{
				if (DebugOn) output+="Impossible accedere all'oggetto XmlDataDocument; controlla che sia stato letto precedentemente; "+e.ToString();
				VerificatiErrori=1;
				return null;
			}
			

		}



		/// <summary>
		/// Modifica il contenuto di un Item; le modifiche saranno salvate su disco chiamando
		/// <code>SalvaXMLDataDoc()</code>.
		/// </summary>
		/// <param name="NomeItem">Item da trovare</param>
		/// <param name="NuovoTesto">Valore da assegnare all'item (il primo) trovato.</param>
		public bool ModificaXMLItemText(string NomeItem,string NuovoTesto)
		{	//by GM
		
			//da usare per modificare il primo nodo trovato con nome= NomeItem
			
			return this.ModificaXMLItemText(NomeItem,NuovoTesto,0);
		}




		/// <summary>
		/// Modifica il contenuto di un Item; le modifiche saranno salvate su disco chiamando
		/// <code>SalvaXMLDataDoc()</code>.
		/// </summary>
		/// <param name="NomeItem">Item da trovare</param>
		/// <param name="NuovoTesto">Valore da assegnare all'item trovato.</param>
		/// <param name="Indice">Nel caso si preveda di trovare pi� di un Item, questo � 
		/// l'indice dell'item cui si vuole accedere</param>
		/// <returns></returns>
		public bool ModificaXMLItemText(string NomeItem,string NuovoTesto,int Indice)
		{//by GM
			//Cerca i nodi con nome "NomeItem", prende quello con indice "Indice" 
			//e sovrascrive il suo vecchio innerText con NuovoVal
			
			try
			{
				XmlNode Nodo=XMLDataDoc.GetElementsByTagName(NomeItem).Item(Indice);

				Nodo.InnerText=NuovoTesto;

				return true;
			}
			
			catch(Exception e)
			{
				if (DebugOn) output+="Impossible accedere all'oggetto XmlDataDocument; controlla che sia stato letto precedentemente; "+e.ToString();
				VerificatiErrori=6;
				return false;
			}
			

		}

		public bool ModifyXMLNodeAttribute(string NomeItem,string NuovoValore,string NomeAttrib)
		{//by GM
			//Cerca i nodi con nome "NomeItem", prende quello con indice 0 
			//e aggiunge o sovrascrive con NuovoValore il valore vecchio
			
			try
			{
				//XmlNode Nodo=XMLDataDoc.GetElementsByTagName(NomeItem).Item(0);
				XmlNode Nodo=XMLDataDoc.GetElementsByTagName(NomeItem).Item(0);
				
				
				XmlAttribute ATT=XMLDataDoc.CreateAttribute(NomeAttrib);
				ATT.Value=NuovoValore;
				Nodo.Attributes.Append(ATT);
				//Nodo.InnerText="xmlns=\"articolo.xsd\"";
			
				//Nodo.Attributes.Append(

				return true;
			}
			
			catch(Exception e)
			{
				if (DebugOn) output+="Impossible accedere all'oggetto XmlDataDocument; controlla che sia stato letto precedentemente; "+e.ToString();
				VerificatiErrori=6;
				return false;
			}
			

		}




		/// <summary>
		/// Carica nell'oggetto corrente un file XML
		/// </summary>
		/// <param name="FileName">Nome completo (path+nomefile) del file da caricare</param>
		/// <returns></returns>
		public bool LeggiXMLDataDoc(string FileName)
		{//by GM
			//Inizializza l'oggetto con i dati di un file XML

			XMLDataDoc = new XmlDataDocument();
			try
			{
				
				XMLDataDoc.Load(FileName);
				VerificatiErrori=0;
				return true;
			}
			catch(IOException IOe)
			{
				VerificatiErrori=1;//Errore di IO: file non trovato;
				if (DebugOn) output+="Impossibile leggere il file XML; "+IOe.ToString();		
				return false;
			}

		}
		
		
		
		/// <summary>
		/// Carica nell'oggetto corrente i dati contenuti nel file XML associato all'oggetto corrente.
		/// </summary>
		/// <returns></returns>
		public bool LeggiXMLDataDoc()
		{//by GM
			
			return this.LeggiXMLDataDoc(this.GetXMLFullName());
			
			
		}

		
		
		/// <summary>
		/// Salva in un file XML i dati XML contenuti nell'oggetto corrente 
		/// </summary>
		/// <param name="FileName">Nome completo (path+nomefile) del file su cui salvare</param>
		public bool SalvaXMLDataDoc(string FileName)
		{//by GM

			//scrive su un file XML i valori correnti dell'oggetto ControlloreXML
			try
			{
				XMLDataDoc.Save(FileName);
				return true;
			}

			catch(IOException e)
			{
				VerificatiErrori=1;//Errore di IO: impossibile scrivere
				if (DebugOn) output+=e.ToString();		
				return false;
			}
		}

		
		
		/// <summary>
		/// Salva nel file XML associato all'oggetto corrente i dati
		///  XML contenuti nell'oggetto corrente 
		/// </summary>
		public bool SalvaXMLDataDoc()
		{//by GM

			return this.SalvaXMLDataDoc(this.GetXMLFullName());
			
		}

	
		/// <summary>
		/// Cancella tutti i file temporanei eventualmente creati
		/// </summary>
		/// <returns>Restituisce il numero di file cancellati</returns>
		public int ClearTemp()
		{
			int n=0;
			foreach (string s in this.TempFiles)
			{
				System.IO.File.Delete(s);
				n++;
			}
			return n;

		}
		/// <summary>
		/// Imposta la cacellazione automatica di eventuali file temporanei creati
		/// </summary>
		public bool DelTempFiles
		{
			get{return this.DeletetempFiles;}
			set{this.DeletetempFiles=value;}
		}
	}
}

using System;
using System.Collections;
using System.Collections.Specialized;
using System.Xml;
//using LidoZ.Modules.Tech.Admin.GuidoZ;

namespace ConfigLib.Config
{
	/// <summary>
	/// Contiene la lista di tutti i campi che possono essere presenti nel file
	/// di configurazione
	/// </summary>
	public class Cfg
	{
		
		static public string Log="logfile";
		static public string User="username";
		
		static public string LocChar="localchar";
		static public string LocCharSize="localsize"; 
		static public string LocCharCol="localcolor";
		static public string LocCharStyle="localstyle";
		static public string RemChar="remotechar";
		static public string RemCharSize="remotesize";
		static public string RemCharCol="remotecolor";
		static public string RemCharStyle="remotestyle";

		static public string LocalBckGrnd="LocalBckGrndImage";
		static public string LocalBckGrndColor="LocalBckGrndColor";
		static public string LocalBackImg="LocalBackgroundImage";
		
		static public string ListPort="lastlistenport";
		static public string ListIP="lastlistenaddr";
		static public string ConnPort="lastconnectport";
		static public string ConnIP="lastconnectaddr";

		static public string SaveOnExit="autosavesettings";
		static public string ResourcesDir="resdir";
		
	
	}
	
	public class myConfig
	{
		System.Collections.Specialized.NameValueCollection NVC;

		
		ControlloreXML XMLConf;

		/// <summary>
		/// Carica da un file xml il testo dei nodi con nome specificato, in un NameValueCollection
		/// associando ai valori i nomi dei nodi
		/// </summary>
		/// <param name="XMLConfigDir"></param>
		/// <param name="ParameterList"></param>
		public myConfig(string XMLConfigDir, ArrayList ParameterList)
		{
			
			this.NVC = new NameValueCollection();
			this.XMLConf= new ControlloreXML(XMLConfigDir);
			this.XMLConf.TrovaXML();
			this.XMLConf.LeggiXMLDataDoc();

			/*XmlDocument XMLDat=new XmlDocument();
			XMLDat.LoadXml("D:\\Documenti\\Progetti di Visual Studio\\Listener\\config.xml");
			IEnumerator ienum=XMLDat.DocumentElement.GetEnumerator();
			while (ienum.MoveNext()) 
			{     
				System.Windows.Forms.MessageBox.Show(((XmlNode)ienum.Current).InnerXml);
			}*/



			
			
			foreach (string ItemName in ParameterList)
			{
				try
				{
					NVC.Add(ItemName,this.XMLConf.TrovaXMLItem(ItemName)[0].ToString());
				}
				catch
				{
					NVC.Add(ItemName,"Valore non trovato nel file XML");
				}
			}
			

		}

		public string GetEl(string ElemName)
		{
			return NVC.Get(ElemName);

		}

		public bool SetEl(ArrayList ParameterList, string[] ValueList)
		{
			if (ParameterList.Count!=ValueList.GetLength(0)) return false;
			
			int i=0;
			foreach (string ItemName in ParameterList)
			{
				this.XMLConf.ModificaXMLItemText(ItemName,ValueList[i++]);
			}
			this.XMLConf.TrovaXML();
			this.XMLConf.SalvaXMLDataDoc();
			return true;
		}




	}
}

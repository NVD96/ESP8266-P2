using System;

namespace ConfigLib
{
	/// <summary>
	/// Classe usata per fornire a tutte le derivate una interfaccia per
	/// recuperare lo stato di errore e gli output dell'esecuzione dei vari metodi.
	/// Questo metodo non garantisce un uso corretto dei metodi delle calssi derivate
	/// nel giusto ordine, ma alcune cose da non fare vengono rilevate
	/// </summary>
	public class Base
	{//By GM

		protected string output;
		protected int VerificatiErrori;
		private bool accessibile;
		protected bool DebugOn;
		

		public Base()
		{//By GM
			accessibile=true;
			DebugOn=false;
			output="";
			VerificatiErrori=0;
		}

		/// <summary>
		///Imposta l'accessibilit� dell'output
		/// </summary>
		/// <param name="visibile">true=accessibile; false=non accessibile</param>
		
		public void SetAcc(bool visibile)
		{//By GM
			accessibile=visibile;
		}

		
		/// <summary>
		///Cancella gli output precedentemente generati
		/// </summary>
				
		public void ResetOutPut()
		{//By GM
			output="";
		}
		
		/// <summary>
		///resetta lo stato di errore
		/// </summary>
		/// 
		public void ResetErr() 
		{//By GM
			VerificatiErrori=0;
		}

		/// <summary>
		///Restituisce gli output generati (� influenzato da DebugState);
		/// </summary>
		public string GetOutPut
		{//By GM
			get
			{	if (accessibile)
				return output;
				else return "Impossibile visualizzare messaggi di errore";
			}
		}

		
		/// <summary>
		///Restituisce lo stato di errore (0=nessun errore)
		/// </summary>
		
		public int GetErr //Restituisce il numero dell'ultimo errore verificatosi
		{//By GM
			get
			{
				return VerificatiErrori;
			}
		}
		
		/// <summary>
		///Imposta la quantit� di output generato dalle classi che ereditano da base: true = Output completo; false=Nessun Output
		/// </summary>
		public bool DebugState //
		{//By GM
			get
			{return DebugOn;}
			set
			{DebugOn=value;}
		}

		/// <summary>
		/// Invia agli amministratori un insieme di informazioni riferite allo stato
		/// corrente dell'applicazione.
		/// </summary>
		
		public static string Avvisa(string msg)
		{
		
			
		/*/	LidoZ.General.Database.DbData dbData = Application["TechDB"] as DbData;
			string connection = dbData.GetSqlConnectionString();

			UsaSQL Indirizzi=new UsaSQL();
			Indirizzi.SetConnectionString(connection);
			
			string AdmnID=Indirizzi.ElencaXDropDown("IDdiritto","diritti","descr_diritto='Amministratore'")[0].ToString();
*/
			return "";

			
		}

	}
}

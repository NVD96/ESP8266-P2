using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

using ConfigLib.Config;
using Listener.Utils;

namespace Listener_config
{
	/// <summary>
	/// Descrizione di riepilogo per Ask.
	/// </summary>
	public class Ask : System.Windows.Forms.Form
	{
		private System.Windows.Forms.TextBox LogPath;
		private System.Windows.Forms.SaveFileDialog saveFileDialog1;
		private System.Windows.Forms.Button ButtonBrowse;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private string ApplExecPath, ResPath;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TextBox UserName;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.Button ButtonBrowseIMG;
		private System.Windows.Forms.OpenFileDialog openFileDialog1;
		private System.Windows.Forms.ComboBox comboBox1;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label6;
		/// <summary>
		/// Variabile di progettazione necessaria.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Ask()
		{
			//
			// Necessario per il supporto di Progettazione Windows Form
			//
			InitializeComponent();

			//
			// TODO: aggiungere il codice del costruttore dopo la chiamata a InitializeComponent.
			//

			this.LogPath.Text=Application.StartupPath+"\\log.rtf";
			this.textBox1.Text=Application.StartupPath+"\\risorse\\grad.jpg";
			try
			{
				this.comboBox1.DataSource=Strumenti.GetAddresses();
			}
			catch
			{
				Strumenti.Error("Non � stata trovata nessuna interfaccia di rete attiva."+
					"Ricordarsi di impostare successivamente l'ind IP su cui ascoltare");
			}
			
			
			ApplExecPath=Application.StartupPath;
			ResPath=ApplExecPath+"\\risorse\\";
			
			


		}

		/// <summary>
		/// Pulire le risorse in uso.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Metodo necessario per il supporto della finestra di progettazione. Non modificare
		/// il contenuto del metodo con l'editor di codice.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Ask));
			this.LogPath = new System.Windows.Forms.TextBox();
			this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
			this.ButtonBrowse = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.button1 = new System.Windows.Forms.Button();
			this.label3 = new System.Windows.Forms.Label();
			this.UserName = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.ButtonBrowseIMG = new System.Windows.Forms.Button();
			this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
			this.comboBox1 = new System.Windows.Forms.ComboBox();
			this.label5 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// LogPath
			// 
			this.LogPath.Location = new System.Drawing.Point(8, 40);
			this.LogPath.Name = "LogPath";
			this.LogPath.Size = new System.Drawing.Size(448, 20);
			this.LogPath.TabIndex = 0;
			this.LogPath.Text = "";
			// 
			// saveFileDialog1
			// 
			this.saveFileDialog1.FileName = "doc1";
			// 
			// ButtonBrowse
			// 
			this.ButtonBrowse.Location = new System.Drawing.Point(472, 40);
			this.ButtonBrowse.Name = "ButtonBrowse";
			this.ButtonBrowse.TabIndex = 1;
			this.ButtonBrowse.Text = "Sfoglia";
			this.ButtonBrowse.Click += new System.EventHandler(this.ButtonBrowse_Click);
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(8, 16);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(448, 16);
			this.label1.TabIndex = 2;
			this.label1.Text = "Directory in cui salvare il file di log";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(8, 192);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(552, 64);
			this.label2.TabIndex = 3;
			this.label2.Text = "Queste impostazioni potranno essere modificate dopo l\'installazione. Se l\'indiriz" +
				"zo IP desiderato non � qui disponibile, continuare l\'installazione, attivare l\'i" +
				"nterfaccia legata all\'indirizzo IP e quindi eseguire il programma.";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(496, 352);
			this.button1.Name = "button1";
			this.button1.TabIndex = 4;
			this.button1.Text = "Ok";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(8, 128);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(200, 16);
			this.label3.TabIndex = 5;
			this.label3.Text = "Nome utente";
			// 
			// UserName
			// 
			this.UserName.Location = new System.Drawing.Point(8, 152);
			this.UserName.Name = "UserName";
			this.UserName.Size = new System.Drawing.Size(200, 20);
			this.UserName.TabIndex = 6;
			this.UserName.Text = "GM";
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(8, 72);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(168, 16);
			this.label4.TabIndex = 7;
			this.label4.Text = "Immagine di sfondo";
			// 
			// textBox1
			// 
			this.textBox1.Location = new System.Drawing.Point(8, 96);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(440, 20);
			this.textBox1.TabIndex = 8;
			this.textBox1.Text = "";
			// 
			// ButtonBrowseIMG
			// 
			this.ButtonBrowseIMG.Location = new System.Drawing.Point(472, 96);
			this.ButtonBrowseIMG.Name = "ButtonBrowseIMG";
			this.ButtonBrowseIMG.TabIndex = 9;
			this.ButtonBrowseIMG.Text = "Sfoglia";
			this.ButtonBrowseIMG.Click += new System.EventHandler(this.ButtonBrowseIMG_Click);
			// 
			// comboBox1
			// 
			this.comboBox1.Location = new System.Drawing.Point(288, 152);
			this.comboBox1.Name = "comboBox1";
			this.comboBox1.Size = new System.Drawing.Size(121, 21);
			this.comboBox1.TabIndex = 10;
			this.comboBox1.Text = "comboBox1";
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(288, 128);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(120, 16);
			this.label5.TabIndex = 11;
			this.label5.Text = "Indirizzo IP";
			// 
			// label6
			// 
			this.label6.Font = new System.Drawing.Font("Comic Sans MS", 36F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label6.ForeColor = System.Drawing.Color.Red;
			this.label6.Location = new System.Drawing.Point(8, 280);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(552, 64);
			this.label6.TabIndex = 12;
			this.label6.Text = "GM\'s Messenger";
			this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// Ask
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(576, 386);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.label6,
																		  this.label5,
																		  this.comboBox1,
																		  this.ButtonBrowseIMG,
																		  this.textBox1,
																		  this.label4,
																		  this.UserName,
																		  this.label3,
																		  this.button1,
																		  this.label2,
																		  this.label1,
																		  this.ButtonBrowse,
																		  this.LogPath});
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "Ask";
			this.Text = "Preconfigurazione";
			this.ResumeLayout(false);

		}
		#endregion

		private void ButtonBrowse_Click(object sender, System.EventArgs e)
		{
			this.saveFileDialog1.InitialDirectory=Application.StartupPath;
			this.saveFileDialog1.FileName=this.LogPath.Text;
			this.saveFileDialog1.ShowDialog();
			
			if (this.saveFileDialog1.FileName.Length>0)
				this.LogPath.Text=this.saveFileDialog1.FileName;
		}

		private void ButtonBrowseIMG_Click(object sender, System.EventArgs e)
		{
		
			this.openFileDialog1.Filter="File Grafici (*.jpg;*.bmp;*.gif)|*.jpg;*.bmp;*.gif|Tutti i file (*.*)|*.*";
			this.openFileDialog1.InitialDirectory=Application.StartupPath;
			this.openFileDialog1.ShowDialog();
			if (this.openFileDialog1.FileName.Length>0)
				this.textBox1.Text=this.openFileDialog1.FileName;
		}

		private void button1_Click(object sender, System.EventArgs e)
		{
			ControlloreXML c=new ControlloreXML(ApplExecPath,"config.xml");
			c.DebugState=true;
			
			c.LeggiXMLDataDoc();
			
			c.ModifyXMLNodeAttribute(Cfg.ResourcesDir,"ok", "res");
			
			c.ModificaXMLItemText(Cfg.LocalBackImg,this.textBox1.Text);
			c.ModificaXMLItemText(Cfg.Log,this.LogPath.Text);
			c.ModificaXMLItemText(Cfg.User,this.UserName.Text);
			try
			{
				c.ModificaXMLItemText(Cfg.ListIP,this.comboBox1.SelectedItem.ToString());
				if (this.comboBox1.SelectedItem.ToString()=="127.0.0.1")
					Strumenti.Error(Errori.OnlyIPLoopBack);
			}
			catch
			{
				Strumenti.Error("Non � stata trovata nessuna interfaccia di rete attiva."+
					"Ricordarsi di impostare successivamente l'ind IP su cui ascoltare");
			}
			
			c.ModificaXMLItemText(Cfg.ResourcesDir,ResPath);

			c.SalvaXMLDataDoc();

			this.label2.Text=c.GetOutPut;

			this.Close();
		}

		
	}
}

using System;
using System.Threading;
using System.Windows.Forms;

using ConfigLib.Config;
using Listener.Utils;


namespace Listener_config
{
	/// <summary>
	/// Descrizione di riepilogo per Class1.
	/// </summary>
	class config
	{
		
		/// <summary>
		/// Il punto di ingresso principale dell'applicazione.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			

			
		
			Console.WriteLine("Configurazione delle directory delle risorse...");

			Application.Run(new Ask());
		
			

		

		}
	}
}

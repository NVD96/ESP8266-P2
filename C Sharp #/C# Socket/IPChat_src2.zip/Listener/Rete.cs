using System;
using System.Net.Sockets;
using System.Net;
using System.Runtime.Remoting.Channels;
using System.Collections;
using System.Threading;
using System.Windows.Forms;
using System.Drawing;
using System.IO;


using Listener.Utils;




namespace Listener.Core
{

	
	





	
	/// <summary>
	/// 
	/// </summary>
	
	public class Poller
	{
		/// <summary>
		/// IP End point a cui connettersi.
		/// </summary>
		IPEndPoint RIPE;
		/// <summary>
		/// IP End point su cui si � in ascolto (� potenzialmente diverso da usedsocket.LocalEndPoint)
		/// </summary>
		IPEndPoint LIPE;
		IPAddress  RIP, LIP;
		Socket UsedScocket, ListenSocket;
		bool IsConnectedAsTX, IsRunningPollingTX;
		bool IsConnectedAsRX, IsRunningPollingRX;
		bool IsListen, IsPresentNewData;
		
		public RichTextManager RTM;
		//public string LocalName, RemoteName;
		public ListBox debugList;
		Thread RXPolling, TXPolling;
		string LastMSG;
		
		
		

		/// <summary>
		/// Permette di realizzare una connessione bidirezionale client-server, visualizzando
		/// i dati trasmessi nel testo di un controllo
		/// </summary>
		/// <param name="t">Controllo che deve essere aggiornato</param>
		public Poller(Control t)
		{
			
			this.RTM=new RichTextManager(t as RichTextBox);
			
			this.LocalName="nomelocale default poller";
			this.RemoteName="nomeremoto default poller";
			

			
			
			this.IsConnectedAsTX=false;
			this.IsConnectedAsRX=false;
			this.IsRunningPollingTX=false;
			this.IsRunningPollingRX=false;
			this.IsListen=false;
			this.IsPresentNewData=false;

			this.ListenSocket=null;
			this.UsedScocket=null;
						
			this.LastMSG=null;

			this.TXPolling=null;
			this.RXPolling=null;

			RIP=IPAddress.Parse("10.0.0.1");
			LIP=IPAddress.Parse("10.0.0.1");
			RIPE=new IPEndPoint(RIP,666);
			LIPE=new IPEndPoint(LIP,666);

			
			
		}

		public void SetLocalEP(IPAddress ipa, int port)
		{
			this.LIPE=new IPEndPoint(ipa,port);
		}

		public void SetRemoteEP(IPAddress ipa, int port)
		{
			this.RIPE=new IPEndPoint(ipa,port);
		}

		#region Init
		/// <summary>
		/// Si connette ad un server in ascolto, o se era gi� l'oggetto stesso in stato di ascolto, e aveva
		/// gi� ricevuto e accettato una Connect, usa la connessione gi� stabilita dal client remoto.
		/// </summary>
		public void InizializzaTX()
		{
			if ((!this.IsConnected)) //Se non � gi� il server di un dialogo, si connette a un server
				//||
				//(this.RIPE.ToString()!=this.UsedScocket.RemoteEndPoint.ToString())) //e se � cambiato il remote IP, si connette
			{
				try
				{
					this.UsedScocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
					this.UsedScocket.Connect(this.RIPE);
					this.IsConnectedAsTX=true;
					
					//Invia il nome del client come in PollingRX il server invia il nome del server
					this.PushString(MSGTag.UserName+/*"Client "+*/this.LocalName);
					
					this.ControlClear();

					//Imposta 
					this.RTM.RemoteIP=this.UsedScocket.RemoteEndPoint.ToString(); //E'= a RIPE
					this.RTM.LocalIP=this.UsedScocket.LocalEndPoint.ToString();

					
				}
				catch(Exception e)
				{
					string Testo="Errore: "+e.Message+"\n Probabilmente il server remoto non � in grado di accettare comunicazioni su questa porta";
					Strumenti.Error(Testo);
					
				}
			}
			
		}

		/// <summary>
		/// Si mette in ascolto, indipendentemente da tutto il resto. Potrei fare si che se � gi� vero
		/// IsConnectedAsTX, non faccia nulla, dato che non ha bisogno di altre connessioni. NB. il meccanismo
		/// prevede che si faccia una sola volta la accept;
		/// </summary>
		public bool InizializzaRX()
		{
			//System.Net.IPEndPoint ServerIPE=new IPEndPoint(IPAddress.Parse("10.0.0.1"),Convert.ToInt32("666"));
			if (this.IsListen)
				this.FermaListening();
			
			this.ListenSocket=new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
			try
			{
				this.ListenSocket.Bind(LIPE);
				this.ListenSocket.Listen(10);
				this.IsListen=true;
				return true;
				
			}
			catch(Exception e)
			{
				string Testo="Impossibile eseguire Listen(10)\n"+e.Message+
					"\nProbabilmente un'altra applicazione usa questa porta"+
					"\n\n Provare ad ascoltare su una diversa porta, e ri-inizializzare manualmente l'ascolto";
				Strumenti.Error(Testo);
				this.ListenSocket=null;
				this.IsListen=false;
				return false;
			}

		}

		/// <summary>
		/// Lancia un Thread che riceve i msg sulla connessione
		/// che ha aperto con un server
		/// </summary>
		public bool StartPollingTX()
		{
			try
			{
				if (!this.IsRunningPollingTX)
				{
					ThreadStart TXPollingDelegate = new ThreadStart(this.PollingTX);
					TXPolling= new Thread(TXPollingDelegate);
					TXPolling.Name="TXPolling";
					TXPolling.Start();
					this.IsRunningPollingTX=true;
					this.DebugRefresh("PollingTX: (Start) eseguito");

				}
				return true;
			}
			catch
			{return false;}
		}

		/// <summary>
		/// Lancia un Thread che riceve i msg sulla connessione
		/// che ha accettato da un client
		/// </summary>
		public void StartPollingRX()
		{
			if (!this.IsRunningPollingRX)
			{
				ThreadStart RXPollingDelegate = new ThreadStart(this.PollingRX);
				RXPolling= new Thread(RXPollingDelegate);
				RXPolling.Name="RXPolling";
				RXPolling.Start();
				this.IsRunningPollingRX=true;
				this.DebugRefresh("PollingRX: (Start) eseguito");

			}
			
		}

		#endregion

		#region Polling
		/// <summary>
		/// Controlla la presenza di dati sul socket aperto attivamente (client)
		/// </summary>
		private void PollingTX()
		{
			
			string s="inizio";
			while (s!=MSGTag.ConnectionStop+"\n")
			{
				if (this.UsedScocket!=null)
				{
					s=this.CheckAndRetrive();
				}
				int n=0;
				if (s!=null)
					n=s.Length;
				this.DebugRefresh("PollingTX: eseguito("+n+" bytes)");
				
				System.Threading.Thread.Sleep(500);
			}
			this.DebugRefresh("PollingTX: ricevuto EXIT");
			this.KillTX();//E se poi uccidendo PollingTX uccido anche tutti i thread figli (cio� Kill)
		}

		
		/// <summary>
		/// Controlla la presenza di dati sul socket aperto passivamente (server). Se il socket
		/// non � aperto, attende una connessione, a patto che InizializzaRX() abbia gi� impostato
		/// ListenSocket.
		/// </summary>
		private void PollingRX()
		{
			string s="Inizio";
			while (s!=MSGTag.ConnectionStop+"\n")
			{
				if (this.UsedScocket==null&&this.ListenSocket!=null)
				{
					this.DebugRefresh("PollingRX: fermo in accept() su"+ this.LIPE.Port);
					this.IsListen=true;
					this.UsedScocket=this.ListenSocket.Accept();
					this.DebugRefresh("PollingRX: Accept() eseguita");
					this.IsConnectedAsRX=true;
					
					
					//Comunica il nome al client, come in InizializzaTX() il client comunica il suo nome al server
				
					this.PushString(MSGTag.UserName/*+"Server "*/+this.LocalName);
				
					this.RTM.RemoteIP=this.UsedScocket.RemoteEndPoint.ToString();
					this.RTM.LocalIP=this.LIPE.ToString(); //Non uso UsedScocket.LocalEndPoint xch� non � definito l'IP locale
					
					this.ControlClear();
				}
				
				s=this.CheckAndRetrive();
				int n=0;
				if (s!=null)
					n=s.Length;
				this.DebugRefresh("PollingRX: eseguito ("+n+" bytes)");
				System.Threading.Thread.Sleep(500);
			}
			this.DebugRefresh("PollingRX: ricevuto EXIT");
			this.KillRX();

		}


		/// <summary>
		/// Se this.UsedSocket.Connected, riceve eventuali dati presenti, 
		/// restituendoli in una stringa.
		/// </summary>
		private string CheckAndRetrive()
		{
			string s=null;		
			if (this.UsedScocket!=null)
			{
				if (this.UsedScocket.Connected)
				{
					s=Strumenti.GetStringFromSocket(this.UsedScocket);
					if (s!=null)
					{
						s=Framing.ArrayString2String(Framing.DeCapsulaMSG(s),"\n");
						if (Framing.IsUserName(s))
						{
							this.RemoteName=this.RTM.RemoteUser=Framing.GetName(s);
							
						}
						else
						{
							
							this.ControlRefresh(s,User.Remote);
							this.FormNotify();
							this.IsPresentNewData=true;
						}
					}
				}
				}
			this.LastMSG=s;
			return s;
		}


		
		/// <summary>
		/// Spedisce una string di dati sul socket correntemente utilizzato, forzando la connessione
		/// all'end point corrente
		/// </summary>
		/// <param name="dati"></param>
		public int PushString(string dati)
		{
			this.InizializzaTX();
			if (this.IsConnectedAsTX)
				this.StartPollingTX();

			this.ControlRefresh(dati+"\n",User.Local);
			return Strumenti.PutStringInSocket(this.UsedScocket,dati);
		}

		#endregion

		public bool Connect(string IPaddress, string port)
		{
			IPAddress LOC;
			try
			{
				if (char.IsDigit(IPaddress[0]))
				{
					LOC=IPAddress.Parse(IPaddress);
				}
				else 
				{
					LOC=Dns.Resolve(IPaddress).AddressList[0];
				}
			
				this.RIPE=new IPEndPoint(LOC,Convert.ToInt32(port));
				
				this.InizializzaTX();
				
			}
			catch(Exception e)
			{
				Strumenti.Error(e.Message);
			}
			return this.IsConnected;

		}

		public bool Connect(IPEndPoint IPE)
		{
			this.RIPE=IPE;
			this.InizializzaTX();
			return this.IsConnected;
		}



		#region Stop
		/// <summary>
		/// Ferma il polling sulla connessione fatta da un client. Ok, va
		/// </summary>
		public void FermaPollingTX()
		{
			if (this.IsRunningPollingTX)//Okkio! Quando il TX riceve exit perch� il server si � "chiuso", il thread PollingTX lancia FermaTX, che uccide il thread prima che qyesto abbia finito di chiudere tutto. Dovrei fare un Kill thread.
			{
				this.TXPolling.Abort();
				this.DebugRefresh("FermaTX(polling): eseguito");
			} 
			else
			{
				this.DebugRefresh("FermaTX(polling): � gi� fermo");
			}
			this.IsRunningPollingTX=false;
			
		}

		/// <summary>
		/// Ferma il polling sulla connessione accettata da un server. Ok, va
		/// </summary>
		public void FermaPollingRX()
		{
			if (this.IsRunningPollingRX)
			{
				this.RXPolling.Abort();
				this.DebugRefresh("FermaRX(Polling): eseguito");
			}
			else
			{
				this.DebugRefresh("FermaRX(Polling): � gi� fermo");
			}
			this.IsRunningPollingRX=false;
			
		}

		/// <summary>
		/// Disconnette un client
		/// </summary>
		public void FermaTX()
		{
			//NB Okkio che PushString() avvia PollingTX

			this.DebugRefresh("FermaTX: inizio");
			
			if (this.UsedScocket!=null)
			{
				if (this.LastMSG!=MSGTag.ConnectionStop+"\n")
					this.PushString(MSGTag.ConnectionStop);
				this.FermaPollingTX();
				this.UsedScocket.Shutdown(SocketShutdown.Both);
				this.UsedScocket.Close();
				this.UsedScocket=null;
				this.SaveMSG();
			}
			//this.IsListen=false;
			this.IsConnectedAsTX=false;
			this.DebugRefresh("FermaTX: eseguito");
			//this.SaveMSG();

		}

		/// <summary>
		/// Disconnette eventuali client, ferma il pollingRX, ma NON ferma il listening
		/// </summary>
		public void FermaRX()
		{
			bool WasListening=this.IsListen;
			this.DebugRefresh("FermaRX: Iniziato");
			this.FermaListening();
			this.DebugRefresh("FermaRX eseguito");
			
			
			if (WasListening)	//se stava ascoltando, si rimette in ascolto
			{
				this.InizializzaRX();
				this.StartPollingRX();
			}

			
		}


		/// <summary>
		///  Disconnette eventuali client, ferma il pollingRX, e ferma il listening
		/// </summary>
		public void FermaListening()
		{
			this.FermaPollingRX();
			if (this.UsedScocket!=null)
			{
				if (this.IsConnectedAsRX) //Se � connesso come TX, non deve chiudere UsedSocket
				{
					
					//Evita che rimandi un messaggio di chiusura a chi l'aveva spedito
					if (this.LastMSG!=MSGTag.ConnectionStop+"\n")
						this.PushString(MSGTag.ConnectionStop);
					
					this.UsedScocket.Shutdown(SocketShutdown.Both);
					this.UsedScocket.Close();
					this.IsListen=false; //dovrebbe bastare sotto, ma ho dei dubbi
					this.SaveMSG();
					this.UsedScocket=null;
					this.DebugRefresh("FermaListening: UsedScocket.Close()");
				}
				
				
				
				
			}
			this.IsConnectedAsRX=false;			
			if (this.ListenSocket!=null)
			{
				this.ListenSocket.Close();
				this.DebugRefresh("FermaListening: ListenSocket.Close()");
				this.IsListen=false;
				this.ListenSocket=null;
			}
			else
			{
				this.DebugRefresh("FermaListening: � gi� fermo");
			}

		}

		/// <summary>
		/// Se il Thread di polling si uccidesse da solo con Ferma..(), interromperebbe la sequenza di
		/// operazioni appena FermaPolling..() esegue .Abort(), senza chiudere la connessione.
		/// </summary>
		public void KillTX()
		{
			ThreadStart SKTX=new ThreadStart(this.FermaTX);
			Thread KTX=new Thread(SKTX);
			KTX.Name="KillTX";
			KTX.Start();
			this.DebugRefresh("KillTX: kill lanciato");

		}

		/// <summary>
		/// Se il Thread di polling si uccidesse da solo con Ferma..(), interromperebbe la sequenza di
		/// operazioni appena FermaPolling..() esegue .Abort(), senza chiudere la connessione.
		/// </summary>
		public void KillRX()
		{
		
			ThreadStart SKRX=new ThreadStart(this.FermaRX);
			Thread KRX=new Thread(SKRX);
			KRX.Name="KillRX";
			KRX.Start();
			this.DebugRefresh("KillRX: kill lanciato");
		
		}
		
		#endregion

		
		#region Refresh

		public void ControlRefresh(string s, User user)
		{
			if (this.IsConnected)
			{
				/*switch (this.tb.GetType().ToString())
				{
					case "System.Windows.Forms.RichTextBox": this.RichTextRefresh(s, user); break;
				
				
					default: tb.Text+=s; break;
				}
				//System.Windows.Forms.MessageBox.Show(this.tb.GetType().ToString());
				tb.Refresh();*/
				this.RichTextRefresh(s,user);
			}
		
		}


		public void ControlClear()
		{
		
		/*	switch (this.tb.GetType().ToString())
			{
				case "System.Windows.Forms.RichTextBox": this.RichTextClear(); break;
				
				
				default: tb.Text=""; break;
			}
		*/

			this.RichTextClear();
		}
	
		private void RichTextRefresh(string testo, User user)
		{
			this.RTM.RichTextRefresh(testo,user);
		
		}

		public void RichTextClear()
		{
			
			this.RTM.RichTextClear();
		}

		public void DebugRefresh(string testo)
		{
			if (debugList.Items.Count>5000)
				debugList.Items.RemoveAt(2);
			string s=Thread.CurrentThread.Name;
			s=s.PadRight(11,".".ToCharArray()[0]);
			debugList.Items.Add(s+testo);
		}

		public void FormNotify()
		{
			Form f=(this.RTM.RTB.TopLevelControl as Form);
			if (f.Visible==true) //se la finestra era visibile (normale o minimizzata)
			{
				f.Activate();
				f.Show();
			}
			else //se era solo in SysTray
			{
				
				f.Show();
				f.WindowState=FormWindowState.Minimized;
				f.Activate();
			}
		}

		public void SaveMSG()
		{
			
			this.RTM.SaveLog();
		}
		#endregion
		


		#region Propriet� Pubbliche
	
		/// <summary>
		/// Mi restituisce se � connesso RX o TX. Non so se � del tutto affidabile
		/// </summary>
		public bool IsConnected
		{get{return (this.IsConnectedAsRX||this.IsConnectedAsTX);}}

		public bool IsConnectedRX
		{get{return this.IsConnectedAsRX;}}

		public bool IsConnectedTX
		{get{return this.IsConnectedAsTX;}}

		/// <summary>
		/// NB: Restituisce true anche se Accept() � gi� stata eseguita da PollingRX()
		/// </summary>
		public bool IsListening
		{get{return this.IsListen;}}

		
		public bool IsRunningRXPolling
		{get{return this.IsRunningPollingRX;}}
		
		public bool IsRunningTXPolling
		{get{return this.IsRunningPollingTX;}}
		
		/// <summary>
		/// Viene impostato a true quando CheckAndRetrive() riceve dati non di controllo.
		/// L'utente deve curarsi di impostarlo su false dopo la lettura dei dati.
		/// </summary>
		public bool IsNewDataPresent
		{
			get{return this.IsPresentNewData;}
			set{this.IsPresentNewData=value;}
		}

		public Socket Current
		{get {return this.UsedScocket;}}

		/// <summary>
		/// Restituisce direttamnete UsedSocket.Connected
		/// </summary>
		public bool IsReallyConnected
		{
				get
		 {
			 if (this.UsedScocket!=null)
				 return this.UsedScocket.Connected;
			 else
				 return false;
		 
		 }
		}

		/// <summary>
		/// Imposta o ottiene il valore del RichTextManager.RemoteUser
		/// </summary>
		public string RemoteName
		{
			get{return this.RTM.RemoteUser;}
			set{this.RTM.RemoteUser=value+"";}
		}

		/// <summary>
		/// Imposta o ottiene il valore del RichTextManager.LocalUser
		/// </summary>
		public string LocalName
		{
			get{return this.RTM.LocalUser;}
			set{this.RTM.LocalUser=value+"";}
		}

		/// <summary>
		/// Imposta o ottiene il valore del RichTextManager.LogPath
		/// </summary>
		public string LogPath
		{
			get{return this.RTM.LogPath;}
			set{this.RTM.LogPath=value;}
		}

		#endregion



	}


	//####################################################################################################
}
namespace Listener.Utils{
	
	
//####################################################################################################

	#region Client
	/*
	public class Client
	{
		
		System.Net.Sockets.Socket soc;
		public System.Windows.Forms.TextBox tb;


		public Client()
		{
			
			
		}

		public void Ricevi()
		{	string s=null;
			while (s!="exit")
			{
				s=null;
				if (soc!=null)
					 if(soc.Connected)
						 s=Strumenti.GetStringFromSocket(this.soc);

				if (s!=null)
					tb.Text+=s;
				System.Threading.Thread.Sleep(1000);
			}
		
		}
		
		public string Spedisci(string Ind, string Porta, string dati)
		{
			System.Net.IPEndPoint IPE=new IPEndPoint(IPAddress.Parse(Ind),Convert.ToInt32(Porta));
			byte[] b=Encoding.ASCII.GetBytes(Framing.IncapsulaMSG(dati));
			int num=0;
			if (soc==null)
				soc = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
			string ret="Tutto OK";
			
			try
			{
				if (!soc.Connected)
					soc.Connect(IPE);

				num=soc.Send(b);
		
			}
			catch (Exception e)
			{
				ret=e.ToString();
				System.Windows.Forms.MessageBox.Show("Errore durante l'invio: "+ret);
			}

			return ret+". Spediti "+num.ToString() ;
		}

		public string DiSconnetti()
		{
			if (this.soc.Connected)
				soc.Close();
			return "a";
		}
	}
	*/
	#endregion
	//**************************************************************************************//
	#region server	
/*	public class Server
	{
		public System.Net.IPEndPoint IPE;
		public Socket sck;
		public System.Windows.Forms.TextBox tb;

		public Server()
		{
			sck=null;
		}

		public int SetAddr(IPEndPoint hostaddr)
		{
			this.IPE=hostaddr;
			if (sck==null)
			{
				sck=new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
				sck.Bind(IPE);
			}
			
			

			return 1;
		}

		public void AvviaAscolto()
		{
			try
			{
				sck.Listen(10);
			}
			catch(Exception e)
			{
				System.Windows.Forms.MessageBox.Show("Impossibile eseguire sck.Listen(10)\n"+e.ToString());
			}
		
			
			string s=null;
			
			sck.Blocking=true;
			
			Socket newsck=null;
			try
			{
					
				while (s!="exit")
				{
					s=null;
					try
					{
						if (newsck==null)
						{
							newsck=sck.Accept();
							Byte[] sendBytes=System.Text.Encoding.Default.GetBytes("Complimenti, ti sei connesso");
							newsck.Send(sendBytes);

						}
					}
					catch
					{
						System.Windows.Forms.MessageBox.Show("sck.Accept(); \n FALLITA");
					}
					if (newsck!=null)
					{
						
						
						string output=null;
						output=Strumenti.GetStringFromSocket(newsck);
						
						if (output!=null)
						{
							foreach (string st in Framing.DeCapsulaMSG(output))
								s+=st;
							tb.Text+=newsck.RemoteEndPoint.ToString().ToUpper()+": "+s+"\n";
						}
					}
					else
					{
						
						tb.Text+="newsck � nullo \r";
						
					}
					tb.Update();
					System.Threading.Thread.Sleep(1000);
					
				}
				
			}
			catch(Exception e)
			{
			
				System.Windows.Forms.MessageBox.Show(s=e.ToString());
			
			}
			tb.Text+="FINE ACCEPT, e Listening";

			sck.Close();
			

		
		}


	
	}*/
#endregion
}

using System;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Windows.Forms;
using System.Drawing;


namespace Listener.Utils
{
	#region Utils
	
	/// <summary>
	/// In realt� � come un'enumerazione, con valori tipo stringa
	/// </summary>
	public class MSGTag
	{
		static public string Start="MSG#Start";
		static public string End="MSG#End";
		static public string ConnectionStop="sperochenessunoscrivaunacosadelgenereAAaaaaaaa!\n";
		static public string UserName="se ricevi questo il testo dopo � il nome utente#";
	}

	public class Errori
	{
	
		static public string OnlyIPLoopBack="Non � stata trovata nessuna interfaccia di rete attiva."+
			"L'indirizzo IP di ascolto � stato impostato sull'indirizzo di Loopback\n"
			+"Se si uole cambiare l'indirizzo, sar� necessario attivare un'interfaccia di rete PRIMA di eseguire il programma";
		
		
	
	}


	public enum User
	{Local=0, Remote=1}

	
	public class Framing
	{
	
		public static string IncapsulaMSG(string dati)
		{
			return MSGTag.Start+dati+MSGTag.End;
		}

		/// <summary>
		/// Restituisce il corpo del messaggio, oppure il messaggio stesso in caso di errore.
		/// </summary>
		/// <param name="dati"></param>
		/// <returns></returns>
		public static string[] DeCapsulaMSG(string dati)
		{
			
			if (dati!=null)
			{
				string [] MSG=new string[50];
				int MSGStart=-1, //se metto 0, non becco il primo start perch� cerca da MSGStart+1.
					MSGEnd=0,
					NMSG=0;

				
				try
				{
					while(MSGEnd!=-1)
					{
						MSGStart=dati.IndexOf(MSGTag.Start,MSGStart+1);
						MSGEnd = dati.IndexOf(MSGTag.End,MSGEnd+1);
				
				
						if (MSGEnd!=-1)
						{
							MSG[NMSG++]=dati.Substring(MSGStart+MSGTag.Start.Length,MSGEnd-(MSGStart+MSGTag.Start.Length));
							//MSG[NMSG++]=dati.Substring(MSGStart+MSGHeader.Start.Length,MSGEnd-(MSGStart+MSGHeader.Start.Length));//cos� � ok per 1
							//	System.Windows.Forms.MessageBox.Show("MSGStart="+MSGStart+"; MSGEnd="+MSGEnd+"\n"+dati+"\n"+MSG[NMSG-1]);
						}
					}
					return MSG;
				}
				catch
				{
					return new string[]{dati};
				}
			}
			return null;
		}
	
		/// <summary>
		/// /// Concatena in un'unica stringa tutte le stringhe di un array di stringhe, separandole con 
		/// "; "
		/// </summary>
		/// <param name="array"></param>
		/// <returns></returns>
		public static string ArrayString2String(string [] array)
		{
			return Framing.ArrayString2String(array,";\n ");	
		
		}

		/// <summary>
		/// Concatena in un'unica stringa tutte le stringhe di un array di stringhe, separandole con 
		/// un separatore
		/// </summary>
		/// <param name="array"></param>
		/// <param name="separatore"></param>
		/// <returns></returns>
		public static string ArrayString2String(string [] array, string separatore)
		{
			string s=null;
			if (array!=null)
			{
				
				foreach (string str in array)
				{
					if (str!=null)
						s+=str+separatore;
				}
			}
			return s;
		}


		public static bool IsUserName(string NameMsg)
		{
			return NameMsg.StartsWith(MSGTag.UserName);
		
		}

		/// <summary>
		/// Estrae da un messaggio con intestazione MSGTag.UserName il nome dell'utente
		/// </summary>
		/// <param name="NameMsg"></param>
		/// <returns></returns>
		public static string GetName(string NameMsg)
		{
		
			if (IsUserName(NameMsg))
			{
				return NameMsg.Substring(MSGTag.UserName.Length,NameMsg.Length-MSGTag.UserName.Length);
			}
			else
			{
				return NameMsg;
			}
		}
	}


	public class Strumenti
	{
	
		Strumenti()
		{}


		/// <summary>
		/// Restituisce un array di IPAddress contenente tutti gli indirizzi delle interfacce 
		/// presenti sul pc su cui � eseguito.
		/// </summary>
		/// <returns></returns>
		public static IPAddress[] GetAddresses()
		{
			IPHostEntry ipHostInfo = Dns.Resolve(Dns.GetHostName());
			return ipHostInfo.AddressList;
		
		}


		/// <summary>
		/// Restituisce sotto forma di stringa UTF8 i dati prelevati da un socket (max 10000 byte). 
		/// Il socket s deve essere connesso.
		/// </summary>
		/// <param name="s">Socket da cui ricevere i dati. Deve essere un socket connesso</param>
		/// <returns>Stringa con i </returns>
		public static string GetStringFromSocket(Socket s)
		{
			Byte[] recBytes=new Byte[10001];
			int i=0;					
			string st=null;
			if (s.Available>0)
			{
				i=s.Receive(recBytes,0,s.Available,SocketFlags.None);
				char[] ac=Encoding.UTF8.GetChars(recBytes,0,i);
				
				foreach (char c in ac)
				{
					st+=c.ToString();
				}
			}
			return st;
		}


		/// <summary>
		/// Spedisce una stringa su un socket aperto, codificandola UTF8
		/// </summary>
		/// <param name="s"></param>
		/// <param name="msg"></param>
		/// <returns></returns>
		public static int PutStringInSocket(Socket s, string msg)
		{
			Byte[] sendBytes=Encoding.UTF8.GetBytes(Framing.IncapsulaMSG(msg));
			if (s.Connected)
				return s.Send(sendBytes);
			else return 0;
		
		
		}

		public static void Error(string txt)
		{
			string Titolo="Attenzione!";
			MessageBox.Show(txt,Titolo,MessageBoxButtons.OK,MessageBoxIcon.Warning);
		}




		public static Font CreaFont(string nome, string stile, string size)
		{
			FontStyle fs;
			

			switch (stile)
			{
				case "Bold": fs=FontStyle.Bold; break;
				default: fs=FontStyle.Regular; break;
			}
			
			Font f= new Font(nome,Convert.ToSingle(size),fs);
		
			return f;
		}
	}



	
	#endregion

	#region RichTextManager

	public class RichTextManager
	{
		public string LocalUser,RemoteUser, LocalIP, RemoteIP;
		
		public RichTextBox RTB;
		public Font LocalUFont, RemoteUFont,LocalMSGFont, RemoteMSGFont;
		public Color LocalUColor, RemoteUColor, LocalMSGColor, RemoteMSGColor;

		private bool LogNotYetSet;
		private string logpath;
		
		public RichTextManager(RichTextBox rtb)
		{
			this.RTB=rtb;
			this.logpath="C:\\rtf\\log.rtf";

			this.LocalMSGFont=new Font("Comic Sans MS", 11, FontStyle.Bold);
			this.LocalUFont=new Font("Verdana", 11, FontStyle.Bold);
			this.LocalMSGColor=Color.Gray;
			this.LocalUColor=Color.LightBlue;
			this.LocalUser="RTM Default Local\n";
			this.LocalIP="IPLocale non definito";

			this.RemoteMSGFont=new Font("Comic Sans MS", 11, FontStyle.Bold);
			this.RemoteUFont=new Font("Verdana", 11, FontStyle.Bold);
			this.RemoteMSGColor=Color.Blue;
			this.RemoteUColor=Color.LightBlue;
			this.RemoteUser="RTM Default Remote\n";
			this.RemoteIP="IPRemoto non definito";

			this.LogNotYetSet=true;
			
			this.InitContextMenu();
			
			
			
		}


		private void InitContextMenu()
		{
		
			ContextMenu CM1= new ContextMenu();
			MenuItem Copia= new MenuItem();
			Copia.Text="Copia";
			Copia.Click += new System.EventHandler(this.Copia_Click);

			CM1.MenuItems.Add(Copia);
			this.RTB.ContextMenu=CM1;
		}

		private void Copia_Click(object sender, System.EventArgs e)
		{
			this.RTB.Copy();
		}

		public void RichTextRefresh(string testo, User user)
		{
			Font usrFont=null, msgFont=null;
			Color usrColor, msgColor;
			string nome=null;
			if (user==User.Remote)
			{
				usrFont=this.RemoteUFont;
				usrColor=this.RemoteUColor;
				msgFont=this.RemoteMSGFont;
				msgColor=this.RemoteMSGColor;
				nome=this.RemoteUser;
			}
			else
			{
				usrFont=this.LocalUFont;
				usrColor=this.LocalUColor;
				msgFont=this.LocalMSGFont;
				msgColor=this.LocalMSGColor;
				nome=this.LocalUser+"\n"; //questo perch� se � remoto, il decapsulatore ci ha gi� messo un a capo in CheckAndRetrive()
			}
			
			if (testo==MSGTag.ConnectionStop+"\n")
				testo="CONNESSIONE TERMINATA";
						
			
			
			//User info
			
			RTB.SelectionFont=usrFont; 
			RTB.SelectionColor=usrColor;
			RTB.AppendText(nome.Remove(nome.Length-1,1));
			
			
			string hour, minute, second,time;
			int temp;

			temp=DateTime.Now.Hour;
			hour=temp.ToString();
			if (temp<10)
				hour="0"+hour;

			temp=DateTime.Now.Minute;
			minute=temp.ToString();
			if (temp<10)
				minute="0"+minute;

			temp=DateTime.Now.Second;
			second=temp.ToString();
			if (temp<10)
				second="0"+second;
	


			time=hour+":"+minute+":"+second;
			RTB.SelectionFont=new Font("Times New Roman",8);
//			RTB.SelectionColor=Color.Black;
			RTB.AppendText(" ("+time+")\n");

			
			
			//Messaggio
			RTB.SelectionFont=msgFont;
			RTB.SelectionColor=msgColor;
			RTB.AppendText(testo);
			
			RTB.AppendText("\n");
			
		//	Strumenti.Error(RTB.Controls.Count.ToString());
			RTB.Select();
			
			RTB.ScrollToCaret();
		//	RTB.Update();
			
			

		}

		public void RichTextClear()
		{
			this.RTB.Clear();
		}

		public void SaveLog()
		{
			
		
			RichTextBox Log=new RichTextBox(), temp=new RichTextBox();

			string date=DateTime.Now.Year.ToString()+"\\"+DateTime.Now.Month.ToString()+"\\"+DateTime.Now.Day.ToString();
			string time=DateTime.Now.Hour.ToString()+":"+DateTime.Now.Minute.ToString()+":"+DateTime.Now.Second.ToString();

			try
			{
			
				if (System.IO.File.Exists(logpath))
					Log.LoadFile(logpath);
				Log.AppendText("\n\n\n\n################################################################################\n");
				Log.AppendText("Giorno "+date+"; Ora "+time+"\n");
				Log.AppendText("Local User: "+this.LocalUser+"; Remote User: "+this.RemoteUser);
				Log.AppendText("Local End Point: "+this.LocalIP+"; Remote End Point: "+this.RemoteIP+"\n\n");
				Log.SelectAll();
				Log.Copy();
				Log.Select(0,0);
				temp.Paste();
			
				RTB.SelectAll();
				RTB.Copy();
				RTB.Select(0,0);
				temp.Paste();

			}
			catch
			{
			
			}


			string DirName=logpath.Substring(0,logpath.LastIndexOf("\\"));
			
			try
			{
			
				if (!System.IO.Directory.Exists(DirName))
				{
					System.IO.Directory.CreateDirectory(DirName);
				}
			
				temp.SaveFile(logpath);
			}
			catch
			{
				try
				{
					//Strumenti.Error("Non � stato possibile salvare il log in \n"+DirName+"\n Il log � stato salvato in c:\\log.rtf");
					temp.SaveFile("C:\\log.rtf");
				}
				catch
				{
					//Strumenti.Error("Problemi durante il salvataggio del log");
				}
			
			}
			
		
		}

		/// <summary>
		/// Imposta il percorso del log file, e se era gi� esistente, lo rinomina
		/// anche con il nuovo valore impostato. (forse)
		/// </summary>
		public string LogPath
		{
			get{return this.logpath;}
			set
			{
				string newpath=value;
				string DirName=newpath.Substring(0,logpath.LastIndexOf("\\"));
				
				/*
				  Se imposto il nome per la prima volta, non faccio nulla.
				  */
				if (!this.LogNotYetSet)

				{
				/*
				Se esisteva un vecchio file, lo rinomina e lo sposta nella nuova posizione, 
				creando una copia di backup del file eventualmente gi� presente nel nuovo 
				percorso 
				*/
					if (System.IO.File.Exists(this.logpath)) 
						if (newpath!=this.logpath) //se sono uguali, non fa nulla
						{
							if (System.IO.File.Exists(newpath)) // se esisteva gi� un file nella nuova posizione, lo rinomina
								System.IO.File.Move(newpath,newpath+".old");
					
							if (!System.IO.Directory.Exists(DirName)) // se la dir di destinazione non esiste, la crea
								System.IO.Directory.CreateDirectory(DirName);
						
						
							System.IO.File.Move(this.logpath,newpath);
						}
					this.LogNotYetSet=false;
				}
					
				
				this.logpath=newpath;
			}
		}


	}
	
	#endregion

}

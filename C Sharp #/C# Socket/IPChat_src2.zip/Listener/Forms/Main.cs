using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.IO;
using System.Threading;
using System.Net;

using Listener.Utils;
using Listener.Core;
//using LidoZ.Modules.Tech.Admin.GuidoZ;
using ConfigLib.Config;

namespace Listener.Forms
{
	/// <summary>
	/// Descrizione di riepilogo per Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button button1;
		private System.ComponentModel.IContainer components;
		private System.Windows.Forms.Button button2;
		public System.Windows.Forms.TextBox Messaggio;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox DestAddr;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.TextBox DestPort;
		private System.Windows.Forms.TextBox Stato;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.TextBox ListPort;
		private System.Windows.Forms.Button button3;
		private System.Windows.Forms.Button button5;
		private System.Windows.Forms.RichTextBox richTextBox1;
		private System.Windows.Forms.ComboBox ListencomboBox1;
		private System.Windows.Forms.Button StopPTX;
		private System.Windows.Forms.Button StopPRX;
		private System.Windows.Forms.Button StartPTX;
		private System.Windows.Forms.Button StartPRX;
		private System.Windows.Forms.Label RXStat;
		private System.Windows.Forms.Label TXStat;
		private System.Windows.Forms.Button button6;
		private System.Windows.Forms.Label Listening;
		private System.Windows.Forms.NotifyIcon notifyIcon1;
		
		
		debug d;
		Poller p;
		Icon ListeningRunning, ListeningStarting,ListeningStopped, MSGIncoming1, MSGIncoming2,
			MSGIncoming3, Connected;
		Thread GUIRefresh;
		/// <summary>
		/// Usata in GUIRefresh() per notificare il ricevimento di messaggi con una sequenza di icone
		/// che dura NLoop;
		/// </summary>
		int LoopLeft, NLoop;
		string ApplRoot, ApplExecPath, LogPath, ResPath, UserName, BackImgPath;
		

		private System.Windows.Forms.GroupBox DebugBox;
		private System.Windows.Forms.MainMenu mainMenu1;
		private System.Windows.Forms.Button StopListen;
		private System.Windows.Forms.GroupBox Conversazione;
		private System.Windows.Forms.MenuItem MenuConnect;
		private System.Windows.Forms.MenuItem MenuDisconnect;
		private System.Windows.Forms.MenuItem MenuHide;
		private System.Windows.Forms.MenuItem MenuHelp;
		private System.Windows.Forms.MenuItem MenuAbout;
		private System.Windows.Forms.StatusBar statusBar1;
		private System.Windows.Forms.StatusBarPanel PCremoto;
		private System.Windows.Forms.StatusBarPanel StatBarStato;
		private System.Windows.Forms.MenuItem MenuListen;
		private System.Windows.Forms.MenuItem MenuStopListen;
		private System.Windows.Forms.ContextMenu contextMenu1;
		private System.Windows.Forms.MenuItem MenuConnessione;
		private System.Windows.Forms.MenuItem MenuVisualizzazione;
		private System.Windows.Forms.MenuItem MenuHelpExt;
		private System.Windows.Forms.Button ButtonClose;
		private System.Windows.Forms.MenuItem MenuTools;
		private System.Windows.Forms.MenuItem MenuDebug;
		private System.Windows.Forms.GroupBox Connessione;
		private System.Windows.Forms.MenuItem MenuSettings;
		private System.Windows.Forms.MenuItem MenuSet;
		private System.Windows.Forms.MenuItem MenuLoadConf;
		private System.Windows.Forms.MenuItem MenuSaveConf;
		private System.Windows.Forms.MenuItem MenuPrint;
		private System.Windows.Forms.PrintDialog printDialog1;
		private System.Windows.Forms.MenuItem MenuAutoSave;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.MenuItem MenuLogView;
		private System.Windows.Forms.MenuItem MenuClearText;
		private System.Windows.Forms.Label ConnectInfo; 

		


		public Form1()
		{
			//
			// Necessario per il supporto di Progettazione Windows Form
			//

			InitializeComponent();

			this.InitPath();
			
			Thread.CurrentThread.Name="Main";
			
			this.InitNotifyIcon();
			
			this.LoopLeft=0;
			this.NLoop=4;
			
			this.MaximizeBox=false;
			
			
			p = new Poller(this.richTextBox1);

			d= new debug();
		
			p.debugList=d.listBox1;
			this.ListencomboBox1.DataSource=Strumenti.GetAddresses();
	
			
			this.LoadConfig();
			this.ApplyConfig();
			
		
			this.ListencomboBox1.Update();
			this.StartGUIRefreshThread();
			this.Start_RX();
			
			/*Strumenti.Error("UserAppDataPath"+Application.UserAppDataPath+"\nCommonAppDataPath"+Application.CommonAppDataPath
				+"\nLocalUserAppDataPath"+Application.LocalUserAppDataPath);
			
			//this.Hide_Click(new Object(), new EventArgs());*/
			


		}

		~Form1()
		{}

		/// <summary>
		/// Imposta le directory predefinite per le risorse e il log. Verranno poi sovrascritte
		/// da LoadConfig();
		/// </summary>
		public void InitPath()
		{
		
			
			try
			{
				int i=Application.StartupPath.LastIndexOf("\\bin\\Debug");
				this.ApplRoot=Application.ExecutablePath.Substring(0,i);
			}
			catch //se non trovo bin\\debug, vuol dire che ho gi� installato, e quindi l'exe � nella root
			{
				this.ApplRoot=Application.StartupPath;
						
			}
			int i2=Application.ExecutablePath.LastIndexOf("\\");
			this.ApplExecPath=Application.ExecutablePath.Substring(0,i2);
			

			this.LogPath=this.ApplRoot+"\\log.rtf";
			this.ResPath=this.ApplRoot+"\\risorse\\";
		}
		
		
		
		public void LoadConfig()
		{
		
			ArrayList all=new ArrayList();
			ArrayList font=new ArrayList();

			font.Add(Cfg.LocChar);
			font.Add(Cfg.LocCharCol);
			font.Add(Cfg.LocCharSize);
			font.Add(Cfg.LocCharStyle);

			font.Add(Cfg.RemChar);
			font.Add(Cfg.RemCharCol);
			font.Add(Cfg.RemCharSize);
			font.Add(Cfg.RemCharStyle);

			
			
			all.Add(Cfg.Log);
			all.Add(Cfg.ConnIP);
			all.Add(Cfg.ConnPort);
			all.Add(Cfg.ListIP);
			all.Add(Cfg.ListPort);
			all.Add(Cfg.User);
			
			all.Add(Cfg.LocalBackImg);

			all.Add(Cfg.SaveOnExit);
			all.AddRange(font);
			
			myConfig cfg=new myConfig(this.ApplExecPath,all);
			
			
			this.ListPort.Text=cfg.GetEl(Cfg.ListPort);
		
			int IPIndex=0, ct=0;
			foreach (IPAddress ip in Strumenti.GetAddresses())
			{
				
				if (ip.ToString()==cfg.GetEl(Cfg.ListIP))
				{
						IPIndex=ct;
				}
				ct++;
			}

			
			this.ListencomboBox1.SelectedIndex=IPIndex;
			if (this.ListencomboBox1.SelectedItem.ToString()=="127.0.0.1")
				Strumenti.Error(Errori.OnlyIPLoopBack);

			this.DestPort.Text=cfg.GetEl(Cfg.ConnPort);
			this.DestAddr.Text=cfg.GetEl(Cfg.ConnIP);
			
			//Strumenti.Error(cfg.GetEl(Cfg.LocChar)+"\n"+cfg.GetEl(Cfg.LocCharCol)+"\n"+cfg.GetEl(Cfg.LocCharSize)+"\n"+cfg.GetEl(Cfg.LocCharStyle)+"\n");
			
			p.RTM.LocalMSGColor=  Color.FromArgb(Convert.ToInt32(cfg.GetEl(Cfg.LocCharCol)));
			p.RTM.LocalMSGFont=Strumenti.CreaFont(cfg.GetEl(Cfg.LocChar),cfg.GetEl(Cfg.LocCharStyle),cfg.GetEl(Cfg.LocCharSize));
			
			p.RTM.RemoteMSGColor=  Color.FromArgb(Convert.ToInt32(cfg.GetEl(Cfg.RemCharCol)));
			p.RTM.RemoteMSGFont=Strumenti.CreaFont(cfg.GetEl(Cfg.RemChar),cfg.GetEl(Cfg.RemCharStyle),cfg.GetEl(Cfg.RemCharSize));
			

			p.LogPath=this.LogPath=cfg.GetEl(Cfg.Log);
			p.LocalName=this.UserName=cfg.GetEl(Cfg.User);

			this.BackImgPath=cfg.GetEl(Cfg.LocalBackImg);

			this.MenuAutoSave.Checked=(bool.TrueString==cfg.GetEl(Cfg.SaveOnExit));
			this.ApplyConfig();
		
		}

		public void ApplyConfig()
		{
			try
			{
				this.BackgroundImage=Image.FromFile(this.BackImgPath);
			}
			catch
			{
				bool NotOk=true;
				while (NotOk)
				{
					OpenFileDialog o= new OpenFileDialog();
					o.Filter="File Grafici (*.jpg;*.bmp;*.gif)|*.jpg;*.bmp;*.gif|Tutti i file (*.*)|*.*";

					Strumenti.Error("Impossibile aprire il file per il background che si trova in\n"
						+this.BackImgPath+"\n Scegliere un file valido");
					
					o.InitialDirectory=this.ApplRoot+"\\risorse";
					o.ShowDialog();
					try
					{
						this.BackgroundImage=Image.FromFile(o.FileName);
						this.BackImgPath=o.FileName;
						NotOk=false;
					}
					catch
					{
						Strumenti.Error("File non valido");
						
					}
				

				}

			}
			
		}
		
		public void SaveConfig()
		{
			ArrayList all=new ArrayList();
			ArrayList font=new ArrayList();

			font.Add(Cfg.LocChar);
			font.Add(Cfg.LocCharCol);
			font.Add(Cfg.LocCharSize);
			font.Add(Cfg.LocCharStyle);

			font.Add(Cfg.RemChar);
			font.Add(Cfg.RemCharCol);
			font.Add(Cfg.RemCharSize);
			font.Add(Cfg.RemCharStyle);



			all.Add(Cfg.Log);
			all.Add(Cfg.ConnIP);
			all.Add(Cfg.ConnPort);
			all.Add(Cfg.ListIP);
			all.Add(Cfg.ListPort);
			all.Add(Cfg.User);
			all.Add(Cfg.LocalBackImg);

			all.Add(Cfg.SaveOnExit);
			
			
			all.AddRange(font);
			
			

			string[] fontInfo=new String[]{this.p.RTM.LocalMSGFont.FontFamily.Name, this.p.RTM.LocalMSGColor.ToArgb().ToString(),
											  this.p.RTM.LocalMSGFont.Size.ToString(), this.p.RTM.LocalMSGFont.Style.ToString(),
											this.p.RTM.RemoteMSGFont.FontFamily.Name, this.p.RTM.RemoteMSGColor.ToArgb().ToString(),
											  this.p.RTM.RemoteMSGFont.Size.ToString(), this.p.RTM.RemoteMSGFont.Style.ToString(), 
											
			};
			

			myConfig cfg=new myConfig(this.ApplExecPath,all);
			
			string[] Val=new string[]{this.LogPath, this.DestAddr.Text,this.DestPort.Text, this.ListencomboBox1.SelectedItem.ToString(),
										 this.ListPort.Text, this.UserName, this.BackImgPath,this.MenuAutoSave.Checked.ToString(),
										 fontInfo[0], fontInfo[1], fontInfo[2], fontInfo[3],
										 fontInfo[4], fontInfo[5],  fontInfo[6],  fontInfo[7]
									 };
			
			if (!cfg.SetEl(all,Val))
				Strumenti.Error("Errore durante il salvataggio delle impostazioni");

		}

		public void InitNotifyIcon()
		{
			
			this.notifyIcon1.Click+=new EventHandler(this.IconClick);
			this.notifyIcon1.Text="GM's Messenger";
			
			
			this.InitContextMenu();
			
	
			this.ListeningStopped=new Icon(ResPath+"TRFFC10C.ICO");
			this.ListeningStarting=new Icon(ResPath+"TRFFC10B.ICO");
			this.ListeningRunning=new Icon(ResPath+"TRFFC10A.ICO");		
			
			this.Connected=new Icon(ResPath+"KEY06.ICO");

			this.MSGIncoming1=new Icon(ResPath+"MAIL02A.ICO");
			this.MSGIncoming2=new Icon(ResPath+"MAIL01A.ICO");
			this.MSGIncoming3=new Icon(ResPath+"MAIL01B.ICO");

		}

		public void InitContextMenu()
		{
			MenuItem m=new MenuItem("Chiudi",new System.EventHandler(this.ButtonClose_Click));
			
			this.contextMenu1.MenuItems.Add(this.MenuConnessione.CloneMenu());
			this.contextMenu1.MenuItems.Add(this.MenuVisualizzazione.CloneMenu());
			this.contextMenu1.MenuItems.Add(this.MenuSettings.CloneMenu());
			this.contextMenu1.MenuItems.Add(this.MenuTools.CloneMenu());
			this.contextMenu1.MenuItems.Add(this.MenuHelp.CloneMenu());
			
			this.contextMenu1.MenuItems.Add(m);
			this.notifyIcon1.ContextMenu=this.contextMenu1;
		}


		public void IconClick(object sender, EventArgs e)
		{
			
			this.Show();
			this.WindowState=FormWindowState.Normal;
			
		}

		public void StartGUIRefreshThread()
		{
			ThreadStart GuiRefreshDelegate=new ThreadStart(this.GUIRefreshThread);
			GUIRefresh= new Thread(GuiRefreshDelegate);
			GUIRefresh.Name="GUIRefresh";
			GUIRefresh.Start();
		
		}
		
		
		/// <summary>
		/// Aggiorna l'interfaccia e la NotifyIcon in base allo stato dell'applicazione
		/// </summary>
		public void GUIRefreshThread()
		{
			int localDelay, totalDelay=1200, newDataPresentIconDelay=300;
				//quante volte, dopo la ricezione di un msg, viene visualizzata
							//la sequenza di icone 
			
	
			while (true)
			{
				try
				{
					localDelay=totalDelay;
					if (!(this.WindowState==FormWindowState.Minimized))
					{
					#region DebugRefresh
						if (this.DebugBox.Visible)
						{
					
							if (p.IsListening)
							{
								this.Listening.BackColor=Color.Green;
								this.Listening.Text="In ascolto..";
							}
							else
							{
						
								this.Listening.BackColor=Color.Red;
								this.Listening.Text="Fermo";
							}


							//Stato polling RX
							if (p.IsRunningRXPolling)
							{this.RXStat.BackColor=Color.Green;}
							else
							{{this.RXStat.BackColor=Color.Red;}}


							//Stato polling TX
							if (p.IsRunningTXPolling)
							{this.TXStat.BackColor=Color.Green;}
							else
							{{this.TXStat.BackColor=Color.Red;}}

							if (p.IsConnected)
							{
								this.ConnectInfo.BackColor=Color.Green;
					
							}
							else
							{
								this.ConnectInfo.BackColor=Color.Red;
							}

						}
					#endregion
					
						//Stato d'ascolto
						if (p.IsListening)
						{
						
							this.ListencomboBox1.Enabled=false;
							this.ListPort.Enabled=false;
				
							if (!this.p.IsReallyConnected)// per evitare che scambi velocemente le icone Listening/Connected
							{
								this.notifyIcon1.Icon=this.ListeningRunning;

								this.statusBar1.Panels[0].Text="In ascolto";
								this.statusBar1.Panels[0].Icon=this.ListeningRunning;
								this.MenuListen.Checked=true;
							}
						}
						else //se non � in ascolto
						{
							this.ListencomboBox1.Enabled=true;
							this.ListPort.Enabled=true;
						
							if (!this.p.IsReallyConnected)// per evitare che scambi velocemente le icone Listening/Connected
							{

								this.notifyIcon1.Icon=this.ListeningStopped;
								this.statusBar1.Panels[0].Text="Fermo";
								this.statusBar1.Panels[0].Icon=this.ListeningStopped;
								this.MenuListen.Checked=false;
							}
						}
			
					
						//Controlla la connessione del socket usato
						if (p.IsReallyConnected)
						{
						
							this.Connessione.Enabled=false;
							this.Conversazione.Enabled=true;
							this.Text="GM's Messenger - Connesso a "+p.Current.RemoteEndPoint.ToString();
					
							this.statusBar1.Panels[0].Text="Connesso";
							this.statusBar1.Panels[0].Icon=this.Connected;
							this.statusBar1.Panels[1].Text="PC Remoto="+p.Current.RemoteEndPoint.ToString();
							this.notifyIcon1.Icon=this.Connected;
						}
						else //Se non � connesso
						{	
							this.Connessione.Enabled=true;
							this.Conversazione.Enabled=false;
							this.Text="GM's Messenger - Non connesso";

							this.statusBar1.Panels[1].Text="PC Remoto non connesso";
						}


						//controlla la presenza di nuovi dati e aggiorna le icone
						if (p.IsNewDataPresent)
						{
							LoopLeft=NLoop;
							p.IsNewDataPresent=false;
						
						}
						if (LoopLeft-->0)
						{
							this.notifyIcon1.Icon=this.MSGIncoming1;
							Thread.Sleep(newDataPresentIconDelay);
							localDelay-=newDataPresentIconDelay;

							this.notifyIcon1.Icon=this.MSGIncoming2;
							Thread.Sleep(newDataPresentIconDelay);
							localDelay-=newDataPresentIconDelay;

							this.notifyIcon1.Icon=this.MSGIncoming3;
							Thread.Sleep(newDataPresentIconDelay);
							localDelay-=newDataPresentIconDelay;

					
				
						}

			
						if (localDelay<0) totalDelay=20;
					
					}
				
					else //se la finestra non � aperta, � inutile aggiornarla
					{
						localDelay=6000;
					}
				
				
					if (p.IsReallyConnected!=p.IsConnected)
						p.DebugRefresh("OKKIO!!! IsReallyConnected!=Connected");
					Thread.Sleep(localDelay);
				}
				
				
				catch
				{
				}
			}
		
		}

		/// <summary>
		/// Pulire le risorse in uso.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Metodo necessario per il supporto della finestra di progettazione. Non modificare
		/// il contenuto del metodo con l'editor di codice.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(Form1));
			this.button1 = new System.Windows.Forms.Button();
			this.Listening = new System.Windows.Forms.Label();
			this.ListencomboBox1 = new System.Windows.Forms.ComboBox();
			this.Messaggio = new System.Windows.Forms.TextBox();
			this.button2 = new System.Windows.Forms.Button();
			this.label2 = new System.Windows.Forms.Label();
			this.DestAddr = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.DestPort = new System.Windows.Forms.TextBox();
			this.Stato = new System.Windows.Forms.TextBox();
			this.label5 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.ListPort = new System.Windows.Forms.TextBox();
			this.button3 = new System.Windows.Forms.Button();
			this.ButtonClose = new System.Windows.Forms.Button();
			this.button5 = new System.Windows.Forms.Button();
			this.richTextBox1 = new System.Windows.Forms.RichTextBox();
			this.StopPTX = new System.Windows.Forms.Button();
			this.StopPRX = new System.Windows.Forms.Button();
			this.StartPTX = new System.Windows.Forms.Button();
			this.StartPRX = new System.Windows.Forms.Button();
			this.RXStat = new System.Windows.Forms.Label();
			this.TXStat = new System.Windows.Forms.Label();
			this.button6 = new System.Windows.Forms.Button();
			this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
			this.ConnectInfo = new System.Windows.Forms.Label();
			this.DebugBox = new System.Windows.Forms.GroupBox();
			this.label1 = new System.Windows.Forms.Label();
			this.StopListen = new System.Windows.Forms.Button();
			this.mainMenu1 = new System.Windows.Forms.MainMenu();
			this.MenuConnessione = new System.Windows.Forms.MenuItem();
			this.MenuConnect = new System.Windows.Forms.MenuItem();
			this.MenuDisconnect = new System.Windows.Forms.MenuItem();
			this.MenuListen = new System.Windows.Forms.MenuItem();
			this.MenuStopListen = new System.Windows.Forms.MenuItem();
			this.MenuVisualizzazione = new System.Windows.Forms.MenuItem();
			this.MenuHide = new System.Windows.Forms.MenuItem();
			this.MenuSettings = new System.Windows.Forms.MenuItem();
			this.MenuSet = new System.Windows.Forms.MenuItem();
			this.MenuLoadConf = new System.Windows.Forms.MenuItem();
			this.MenuSaveConf = new System.Windows.Forms.MenuItem();
			this.MenuAutoSave = new System.Windows.Forms.MenuItem();
			this.MenuTools = new System.Windows.Forms.MenuItem();
			this.MenuPrint = new System.Windows.Forms.MenuItem();
			this.MenuDebug = new System.Windows.Forms.MenuItem();
			this.MenuLogView = new System.Windows.Forms.MenuItem();
			this.MenuHelpExt = new System.Windows.Forms.MenuItem();
			this.MenuHelp = new System.Windows.Forms.MenuItem();
			this.MenuAbout = new System.Windows.Forms.MenuItem();
			this.Conversazione = new System.Windows.Forms.GroupBox();
			this.statusBar1 = new System.Windows.Forms.StatusBar();
			this.StatBarStato = new System.Windows.Forms.StatusBarPanel();
			this.PCremoto = new System.Windows.Forms.StatusBarPanel();
			this.contextMenu1 = new System.Windows.Forms.ContextMenu();
			this.Connessione = new System.Windows.Forms.GroupBox();
			this.printDialog1 = new System.Windows.Forms.PrintDialog();
			this.MenuClearText = new System.Windows.Forms.MenuItem();
			this.DebugBox.SuspendLayout();
			this.Conversazione.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.StatBarStato)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.PCremoto)).BeginInit();
			this.Connessione.SuspendLayout();
			this.SuspendLayout();
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(8, 48);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(104, 23);
			this.button1.TabIndex = 1;
			this.button1.Text = "Inizia Ascolto";
			this.button1.Click += new System.EventHandler(this.StartListen_Click);
			// 
			// Listening
			// 
			this.Listening.BackColor = System.Drawing.Color.Red;
			this.Listening.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Listening.ForeColor = System.Drawing.Color.White;
			this.Listening.Location = new System.Drawing.Point(240, 48);
			this.Listening.Name = "Listening";
			this.Listening.Size = new System.Drawing.Size(104, 23);
			this.Listening.TabIndex = 2;
			this.Listening.Text = "Fermo";
			this.Listening.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// ListencomboBox1
			// 
			this.ListencomboBox1.Location = new System.Drawing.Point(272, 16);
			this.ListencomboBox1.Name = "ListencomboBox1";
			this.ListencomboBox1.Size = new System.Drawing.Size(104, 23);
			this.ListencomboBox1.TabIndex = 3;
			this.ListencomboBox1.Text = "comboBox1";
			// 
			// Messaggio
			// 
			this.Messaggio.Location = new System.Drawing.Point(14, 249);
			this.Messaggio.Multiline = true;
			this.Messaggio.Name = "Messaggio";
			this.Messaggio.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.Messaggio.Size = new System.Drawing.Size(334, 72);
			this.Messaggio.TabIndex = 4;
			this.Messaggio.Text = "Benvenuto";
			// 
			// button2
			// 
			this.button2.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.button2.ForeColor = System.Drawing.SystemColors.Desktop;
			this.button2.Location = new System.Drawing.Point(371, 250);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(56, 72);
			this.button2.TabIndex = 5;
			this.button2.Text = "Invia";
			this.button2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.CheckInvio);
			this.button2.Click += new System.EventHandler(this.Invia);
			// 
			// label2
			// 
			this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label2.Location = new System.Drawing.Point(192, 16);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(72, 23);
			this.label2.TabIndex = 6;
			this.label2.Text = "Ascolta su";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// DestAddr
			// 
			this.DestAddr.Location = new System.Drawing.Point(56, 16);
			this.DestAddr.Name = "DestAddr";
			this.DestAddr.Size = new System.Drawing.Size(80, 21);
			this.DestAddr.TabIndex = 7;
			this.DestAddr.Text = "10.0.0.1";
			// 
			// label3
			// 
			this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label3.Location = new System.Drawing.Point(8, 16);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(48, 23);
			this.label3.TabIndex = 8;
			this.label3.Text = "Invia a ";
			this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(144, 16);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(3, 23);
			this.label4.TabIndex = 9;
			this.label4.Text = ":";
			this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// DestPort
			// 
			this.DestPort.Location = new System.Drawing.Point(152, 16);
			this.DestPort.Name = "DestPort";
			this.DestPort.Size = new System.Drawing.Size(35, 21);
			this.DestPort.TabIndex = 10;
			this.DestPort.Text = "667";
			// 
			// Stato
			// 
			this.Stato.Location = new System.Drawing.Point(96, 200);
			this.Stato.Multiline = true;
			this.Stato.Name = "Stato";
			this.Stato.Size = new System.Drawing.Size(248, 24);
			this.Stato.TabIndex = 11;
			this.Stato.Text = "";
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(8, 200);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(64, 23);
			this.label5.TabIndex = 12;
			this.label5.Text = "Info Invio";
			this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// label6
			// 
			this.label6.Location = new System.Drawing.Point(376, 16);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(8, 23);
			this.label6.TabIndex = 13;
			this.label6.Text = ":";
			this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// ListPort
			// 
			this.ListPort.Location = new System.Drawing.Point(384, 16);
			this.ListPort.Name = "ListPort";
			this.ListPort.Size = new System.Drawing.Size(40, 21);
			this.ListPort.TabIndex = 14;
			this.ListPort.Text = "667";
			// 
			// button3
			// 
			this.button3.Location = new System.Drawing.Point(219, 168);
			this.button3.Name = "button3";
			this.button3.Size = new System.Drawing.Size(104, 23);
			this.button3.TabIndex = 15;
			this.button3.Text = "Stop TX e RX";
			this.button3.Click += new System.EventHandler(this.StopTXAndRX_Click);
			// 
			// ButtonClose
			// 
			this.ButtonClose.Location = new System.Drawing.Point(144, 168);
			this.ButtonClose.Name = "ButtonClose";
			this.ButtonClose.Size = new System.Drawing.Size(64, 23);
			this.ButtonClose.TabIndex = 16;
			this.ButtonClose.Text = "Esci";
			this.ButtonClose.Click += new System.EventHandler(this.ButtonClose_Click);
			// 
			// button5
			// 
			this.button5.Location = new System.Drawing.Point(80, 168);
			this.button5.Name = "button5";
			this.button5.Size = new System.Drawing.Size(56, 23);
			this.button5.TabIndex = 17;
			this.button5.Text = "Pi� dati";
			this.button5.Click += new System.EventHandler(this.button5_Click);
			// 
			// richTextBox1
			// 
			this.richTextBox1.Cursor = System.Windows.Forms.Cursors.Arrow;
			this.richTextBox1.Location = new System.Drawing.Point(13, 20);
			this.richTextBox1.Name = "richTextBox1";
			this.richTextBox1.ReadOnly = true;
			this.richTextBox1.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
			this.richTextBox1.Size = new System.Drawing.Size(414, 212);
			this.richTextBox1.TabIndex = 19;
			this.richTextBox1.Text = "";
			this.richTextBox1.TextChanged += new System.EventHandler(this.richTextBox1_TextChanged);
			// 
			// StopPTX
			// 
			this.StopPTX.Location = new System.Drawing.Point(128, 80);
			this.StopPTX.Name = "StopPTX";
			this.StopPTX.Size = new System.Drawing.Size(104, 23);
			this.StopPTX.TabIndex = 20;
			this.StopPTX.Text = "Ferma Polling TX";
			this.StopPTX.Click += new System.EventHandler(this.StopPTX_Click);
			// 
			// StopPRX
			// 
			this.StopPRX.Location = new System.Drawing.Point(128, 112);
			this.StopPRX.Name = "StopPRX";
			this.StopPRX.Size = new System.Drawing.Size(104, 23);
			this.StopPRX.TabIndex = 21;
			this.StopPRX.Text = "Ferma Polling RX";
			this.StopPRX.Click += new System.EventHandler(this.StopPRX_Click);
			// 
			// StartPTX
			// 
			this.StartPTX.Location = new System.Drawing.Point(8, 80);
			this.StartPTX.Name = "StartPTX";
			this.StartPTX.Size = new System.Drawing.Size(104, 23);
			this.StartPTX.TabIndex = 22;
			this.StartPTX.Text = "Inzia Polling TX";
			this.StartPTX.Click += new System.EventHandler(this.StartPTX_Click);
			// 
			// StartPRX
			// 
			this.StartPRX.Location = new System.Drawing.Point(8, 112);
			this.StartPRX.Name = "StartPRX";
			this.StartPRX.Size = new System.Drawing.Size(104, 23);
			this.StartPRX.TabIndex = 23;
			this.StartPRX.Text = "Inzia Polling RX";
			this.StartPRX.Click += new System.EventHandler(this.StartPRX_Click);
			// 
			// RXStat
			// 
			this.RXStat.BackColor = System.Drawing.Color.Red;
			this.RXStat.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.RXStat.ForeColor = System.Drawing.Color.White;
			this.RXStat.Location = new System.Drawing.Point(240, 112);
			this.RXStat.Name = "RXStat";
			this.RXStat.Size = new System.Drawing.Size(104, 23);
			this.RXStat.TabIndex = 24;
			this.RXStat.Text = "Stato Polling RX";
			this.RXStat.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// TXStat
			// 
			this.TXStat.BackColor = System.Drawing.Color.Red;
			this.TXStat.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.TXStat.ForeColor = System.Drawing.Color.White;
			this.TXStat.Location = new System.Drawing.Point(240, 80);
			this.TXStat.Name = "TXStat";
			this.TXStat.Size = new System.Drawing.Size(104, 23);
			this.TXStat.TabIndex = 25;
			this.TXStat.Text = "Stato Polling TX";
			this.TXStat.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// button6
			// 
			this.button6.Location = new System.Drawing.Point(8, 168);
			this.button6.Name = "button6";
			this.button6.Size = new System.Drawing.Size(64, 23);
			this.button6.TabIndex = 26;
			this.button6.Text = "Hide";
			this.button6.Click += new System.EventHandler(this.Hide_Click);
			// 
			// notifyIcon1
			// 
			this.notifyIcon1.Icon = ((System.Drawing.Icon)(resources.GetObject("notifyIcon1.Icon")));
			this.notifyIcon1.Text = "notifyIcon1";
			this.notifyIcon1.Visible = true;
			// 
			// ConnectInfo
			// 
			this.ConnectInfo.BackColor = System.Drawing.Color.Red;
			this.ConnectInfo.ForeColor = System.Drawing.Color.Brown;
			this.ConnectInfo.Location = new System.Drawing.Point(8, 16);
			this.ConnectInfo.Name = "ConnectInfo";
			this.ConnectInfo.Size = new System.Drawing.Size(344, 23);
			this.ConnectInfo.TabIndex = 27;
			this.ConnectInfo.Text = "Connesso";
			this.ConnectInfo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// DebugBox
			// 
			this.DebugBox.BackColor = System.Drawing.Color.Transparent;
			this.DebugBox.Controls.AddRange(new System.Windows.Forms.Control[] {
																				   this.label1,
																				   this.StopListen,
																				   this.StartPRX,
																				   this.TXStat,
																				   this.StartPTX,
																				   this.RXStat,
																				   this.StopPRX,
																				   this.StopPTX,
																				   this.button6,
																				   this.button5,
																				   this.Listening,
																				   this.button3,
																				   this.button1,
																				   this.ConnectInfo,
																				   this.ButtonClose,
																				   this.Stato,
																				   this.label5});
			this.DebugBox.Enabled = false;
			this.DebugBox.Location = new System.Drawing.Point(460, 4);
			this.DebugBox.Name = "DebugBox";
			this.DebugBox.Size = new System.Drawing.Size(360, 337);
			this.DebugBox.TabIndex = 28;
			this.DebugBox.TabStop = false;
			this.DebugBox.Text = "Debug";
			this.DebugBox.Visible = false;
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(31, 286);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(306, 15);
			this.label1.TabIndex = 29;
			this.label1.Text = "Per chiudere questa finestra scegliere Strumenti->Debug";
			// 
			// StopListen
			// 
			this.StopListen.Location = new System.Drawing.Point(128, 49);
			this.StopListen.Name = "StopListen";
			this.StopListen.Size = new System.Drawing.Size(103, 23);
			this.StopListen.TabIndex = 28;
			this.StopListen.Text = "Ferma Ascolto";
			this.StopListen.Click += new System.EventHandler(this.StopListen_Click);
			// 
			// mainMenu1
			// 
			this.mainMenu1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.MenuConnessione,
																					  this.MenuVisualizzazione,
																					  this.MenuSettings,
																					  this.MenuTools,
																					  this.MenuHelpExt});
			// 
			// MenuConnessione
			// 
			this.MenuConnessione.Index = 0;
			this.MenuConnessione.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																							this.MenuConnect,
																							this.MenuDisconnect,
																							this.MenuListen,
																							this.MenuStopListen});
			this.MenuConnessione.Text = "Connessione";
			// 
			// MenuConnect
			// 
			this.MenuConnect.Index = 0;
			this.MenuConnect.Shortcut = System.Windows.Forms.Shortcut.CtrlO;
			this.MenuConnect.Text = "Apri Connessione";
			this.MenuConnect.Click += new System.EventHandler(this.MenuConnect_Click);
			// 
			// MenuDisconnect
			// 
			this.MenuDisconnect.Index = 1;
			this.MenuDisconnect.Shortcut = System.Windows.Forms.Shortcut.CtrlD;
			this.MenuDisconnect.Text = "Disconnetti";
			this.MenuDisconnect.Click += new System.EventHandler(this.MenuDisconnect_Click);
			// 
			// MenuListen
			// 
			this.MenuListen.Index = 2;
			this.MenuListen.Shortcut = System.Windows.Forms.Shortcut.CtrlL;
			this.MenuListen.Text = "Ascolta";
			this.MenuListen.Click += new System.EventHandler(this.MenuListen_Click);
			// 
			// MenuStopListen
			// 
			this.MenuStopListen.Index = 3;
			this.MenuStopListen.Shortcut = System.Windows.Forms.Shortcut.CtrlS;
			this.MenuStopListen.Text = "Interrompi ascolto";
			this.MenuStopListen.Click += new System.EventHandler(this.MenuStopListen_Click);
			// 
			// MenuVisualizzazione
			// 
			this.MenuVisualizzazione.Index = 1;
			this.MenuVisualizzazione.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																								this.MenuHide,
																								this.MenuClearText});
			this.MenuVisualizzazione.Text = "Visualizzazione";
			// 
			// MenuHide
			// 
			this.MenuHide.Index = 0;
			this.MenuHide.Shortcut = System.Windows.Forms.Shortcut.CtrlH;
			this.MenuHide.Text = "Nascondi";
			this.MenuHide.Click += new System.EventHandler(this.MenuHide_Click);
			// 
			// MenuSettings
			// 
			this.MenuSettings.Index = 2;
			this.MenuSettings.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																						 this.MenuSet,
																						 this.MenuLoadConf,
																						 this.MenuSaveConf,
																						 this.MenuAutoSave});
			this.MenuSettings.Text = "Impostazioni";
			// 
			// MenuSet
			// 
			this.MenuSet.Index = 0;
			this.MenuSet.Text = "Impostazioni";
			this.MenuSet.Click += new System.EventHandler(this.MenuSet_Click);
			// 
			// MenuLoadConf
			// 
			this.MenuLoadConf.Index = 1;
			this.MenuLoadConf.Text = "Carica configurazione";
			this.MenuLoadConf.Click += new System.EventHandler(this.MenuLoadConf_Click);
			// 
			// MenuSaveConf
			// 
			this.MenuSaveConf.Index = 2;
			this.MenuSaveConf.Text = "Salva configurazione";
			this.MenuSaveConf.Click += new System.EventHandler(this.MenuSaveConf_Click);
			// 
			// MenuAutoSave
			// 
			this.MenuAutoSave.Checked = true;
			this.MenuAutoSave.Index = 3;
			this.MenuAutoSave.Text = "Salva prima di chiudere";
			this.MenuAutoSave.Click += new System.EventHandler(this.MenuAutoSave_Click);
			// 
			// MenuTools
			// 
			this.MenuTools.Index = 3;
			this.MenuTools.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																					  this.MenuPrint,
																					  this.MenuDebug,
																					  this.MenuLogView});
			this.MenuTools.Text = "Strumenti";
			// 
			// MenuPrint
			// 
			this.MenuPrint.Enabled = false;
			this.MenuPrint.Index = 0;
			this.MenuPrint.Text = "Stampa";
			this.MenuPrint.Click += new System.EventHandler(this.MenuPrint_Click);
			// 
			// MenuDebug
			// 
			this.MenuDebug.Index = 1;
			this.MenuDebug.Text = "Debug";
			this.MenuDebug.Click += new System.EventHandler(this.MenuDebug_Click);
			// 
			// MenuLogView
			// 
			this.MenuLogView.Index = 2;
			this.MenuLogView.Text = "Log Viewer";
			this.MenuLogView.Click += new System.EventHandler(this.MenuLogView_Click);
			// 
			// MenuHelpExt
			// 
			this.MenuHelpExt.Index = 4;
			this.MenuHelpExt.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
																						this.MenuHelp,
																						this.MenuAbout});
			this.MenuHelpExt.Text = "Help";
			// 
			// MenuHelp
			// 
			this.MenuHelp.Index = 0;
			this.MenuHelp.Text = "Help";
			this.MenuHelp.Click += new System.EventHandler(this.MenuHelp_Click);
			// 
			// MenuAbout
			// 
			this.MenuAbout.Index = 1;
			this.MenuAbout.Text = "About";
			this.MenuAbout.Click += new System.EventHandler(this.MenuAbout_Click);
			// 
			// Conversazione
			// 
			this.Conversazione.BackColor = System.Drawing.Color.Transparent;
			this.Conversazione.Controls.AddRange(new System.Windows.Forms.Control[] {
																						this.richTextBox1,
																						this.Messaggio,
																						this.button2});
			this.Conversazione.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Conversazione.ForeColor = System.Drawing.SystemColors.Desktop;
			this.Conversazione.Location = new System.Drawing.Point(6, 6);
			this.Conversazione.Name = "Conversazione";
			this.Conversazione.Size = new System.Drawing.Size(442, 335);
			this.Conversazione.TabIndex = 29;
			this.Conversazione.TabStop = false;
			this.Conversazione.Text = "Conversazione";
			// 
			// statusBar1
			// 
			this.statusBar1.Location = new System.Drawing.Point(0, 406);
			this.statusBar1.Name = "statusBar1";
			this.statusBar1.Panels.AddRange(new System.Windows.Forms.StatusBarPanel[] {
																						  this.StatBarStato,
																						  this.PCremoto});
			this.statusBar1.ShowPanels = true;
			this.statusBar1.Size = new System.Drawing.Size(454, 22);
			this.statusBar1.TabIndex = 30;
			this.statusBar1.Text = "statusBar1";
			// 
			// StatBarStato
			// 
			this.StatBarStato.Icon = ((System.Drawing.Icon)(resources.GetObject("StatBarStato.Icon")));
			this.StatBarStato.Text = "Stato";
			this.StatBarStato.ToolTipText = "Stato dell\'applicazione";
			this.StatBarStato.Width = 80;
			// 
			// PCremoto
			// 
			this.PCremoto.Text = "PC remoto";
			this.PCremoto.ToolTipText = "PC Remoto a cui si � connessi";
			this.PCremoto.Width = 150;
			// 
			// Connessione
			// 
			this.Connessione.BackColor = System.Drawing.Color.Transparent;
			this.Connessione.Controls.AddRange(new System.Windows.Forms.Control[] {
																					  this.label3,
																					  this.DestAddr,
																					  this.DestPort,
																					  this.label4,
																					  this.ListencomboBox1,
																					  this.label6,
																					  this.ListPort,
																					  this.label2});
			this.Connessione.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.Connessione.ForeColor = System.Drawing.SystemColors.Desktop;
			this.Connessione.Location = new System.Drawing.Point(7, 348);
			this.Connessione.Name = "Connessione";
			this.Connessione.Size = new System.Drawing.Size(442, 49);
			this.Connessione.TabIndex = 31;
			this.Connessione.TabStop = false;
			this.Connessione.Text = "Connessione";
			// 
			// MenuClearText
			// 
			this.MenuClearText.Index = 1;
			this.MenuClearText.Text = "Cancella Testo";
			this.MenuClearText.Click += new System.EventHandler(this.MenuClearText_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(454, 428);
			this.ControlBox = false;
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.Connessione,
																		  this.statusBar1,
																		  this.Conversazione,
																		  this.DebugBox});
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Menu = this.mainMenu1;
			this.Name = "Form1";
			this.Text = "GM\'s Messenger - Non connesso";
			this.Closing += new System.ComponentModel.CancelEventHandler(this.OnClosing);
			this.DebugBox.ResumeLayout(false);
			this.Conversazione.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.StatBarStato)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.PCremoto)).EndInit();
			this.Connessione.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// Il punto di ingresso principale dell'applicazione.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Form1 f=new Form1();
			//f.WindowState=FormWindowState.Minimized;
			f.Visible=false;
			Application.Run(f);
			
		}

		
		
		private void FormLoad(object o, EventArgs e)
		{
			
			this.Hide();
		}
		
		private void Start_RX()
		{
			if (!p.IsListening)
			{
				IPAddress LOC;
			
			
				LOC=IPAddress.Parse(this.ListencomboBox1.SelectedItem.ToString());
			
				p.SetLocalEP(LOC,Convert.ToInt32(this.ListPort.Text));

				if (p.InizializzaRX())
				{
					p.StartPollingRX();
				
				}
			}
		}


		//Ascolta e controlla feedback
		private void StartListen_Click(object sender, System.EventArgs e)
		{
			
			this.Start_RX();
						
			/**/
			
		
			
			
		}


		//Invia i dati
		private void Invia(object sender, System.EventArgs e)
		{
			
			if(p.Connect(this.DestAddr.Text,this.DestPort.Text))
			{
					this.Stato.Text="Spediti "+p.PushString(this.Messaggio.Text)+" bytes";
				this.Messaggio.Text="";
			}
			

		}

		private void CheckInvio(object sender, System.Windows.Forms.KeyPressEventArgs e)
		{
			//if (e.KeyChar==
		}

		private void OnClosing(object s, System.ComponentModel.CancelEventArgs e)
		{
			this.ButtonClose_Click(s,e);
			
		}

		//Ferma ascolto e tx
		private void StopTXAndRX_Click(object sender, System.EventArgs e)
		{
			if (p.IsConnectedRX)
				this.p.FermaRX();
			if (p.IsConnectedTX)				
				this.p.FermaTX();
			
		}

		//ferma tutto e chiude
		private void ButtonClose_Click(object sender, System.EventArgs e)
		{
			this.StopTXAndRX_Click(sender,e);
			this.StopListen_Click(sender,e);
			GUIRefresh.Abort();
			if (this.MenuAutoSave.Checked)
				this.SaveConfig();
			
			//p.SaveMSG();

			this.notifyIcon1.Visible=false;
			Application.Exit();

		}

		//debug
		private void button5_Click(object sender, System.EventArgs e)
		{
			d.Visible=d.Visible^true;
			
			//this.richTextBox1.Text=Framing.DeCapsulaMSG(Framing.IncapsulaMSG("ciao")+Framing.IncapsulaMSG("me"))[0]+Framing.DeCapsulaMSG(Framing.IncapsulaMSG("ciao")+Framing.IncapsulaMSG("me"))[1];
		//	System.Windows.Forms.MessageBox.Show(System.Text.Encoding.Default.GetBytes(this.Stato.Text[1].ToString())[0].ToString());
			/*byte[] b=new byte[]{13,55,13,55,13,13,13,13,13,57};
			this.textBox1.Text=System.Text.Encoding.Default.GetString(b/*((byte[])(System.Text.Encoding.Default.GetBytes(("1\n2\n345")))));*/
			
		}

		private void StopPTX_Click(object sender, System.EventArgs e)
		{
			p.FermaPollingTX();
			this.TXStat.BackColor=Color.Red;
		}

		private void StopPRX_Click(object sender, System.EventArgs e)
		{
			p.FermaPollingRX();
			this.RXStat.BackColor=Color.Red;
		}

		private void StartPTX_Click(object sender, System.EventArgs e)
		{
			p.StartPollingTX();
			this.TXStat.BackColor=Color.Green;
		}

		private void StartPRX_Click(object sender, System.EventArgs e)
		{
			p.StartPollingRX();
			this.RXStat.BackColor=Color.Green;
		}

		private void Hide_Click(object sender, System.EventArgs e)
		{
//			d.Hide();
			this.WindowState=FormWindowState.Minimized;
			this.Hide();
		}

		private void StopListen_Click(object sender, System.EventArgs e)
		{
			this.p.FermaListening();
		}

		private void richTextBox1_TextChanged(object sender, System.EventArgs e)
		{
			/*this.richTextBox1.Select();
			this.richTextBox1.ScrollToCaret();*/
			//Thread.Sleep(1000);
			this.Messaggio.Focus();
			
			
			
		}

		//Connette
		private void MenuConnect_Click(object sender, System.EventArgs e)
		{
			p.Connect(this.DestAddr.Text,this.DestPort.Text);
			if (p.IsConnectedTX)
				p.StartPollingTX();

		}

		//Disconnette
		private void MenuDisconnect_Click(object sender, System.EventArgs e)
		{
			this.StopTXAndRX_Click(sender,e);
		}

		//Nasconde
		private void MenuHide_Click(object sender, System.EventArgs e)
		{
			this.Hide_Click(sender,e);
		}

		

		private void MenuListen_Click(object sender, System.EventArgs e)
		{
			this.StartListen_Click(sender,e);
			/*ListenChoice LC= new ListenChoice();
			
			LC.IP.DataSource=Strumenti.GetAddresses();
			LC.ShowDialog();*/
			

		}

		private void MenuStopListen_Click(object sender, System.EventArgs e)
		{
			this.StopListen_Click(sender,e);
		}

		private void MenuHelp_Click(object sender, System.EventArgs e)
		{
			
			string HelpPath=this.ApplRoot+"\\Guida\\index.htm";
			try
			{
				Help.ShowHelp(this,HelpPath);
			}
			catch
			{
				Strumenti.Error("Help non trovato in "+HelpPath);
			}
		}

		private void MenuDebug_Click(object sender, System.EventArgs e)
		{
			Size s;
			if((this.MenuDebug.Checked=this.DebugBox.Enabled=this.DebugBox.Visible^=true)==true)
				s=new Size(this.Size.Width+380,this.Size.Height);
			else
				s=new Size(this.Size.Width-380,this.Size.Height);
			
			this.Size=s;
			
		}

		

		

		

		private void MenuSet_Click(object sender, System.EventArgs e)
		{
			Impostazioni i=new Impostazioni();
			
			//font
			i.impostazioni1.Local.Font=this.p.RTM.LocalMSGFont;
			i.impostazioni1.Local.ForeColor=this.p.RTM.LocalMSGColor;
			i.impostazioni1.Remote.ForeColor=this.p.RTM.RemoteMSGColor;
			i.impostazioni1.Remote.Font=this.p.RTM.RemoteMSGFont;
			
			i.impostazioni1.BackPath.Text=this.BackImgPath;
			i.impostazioni1.pictureBox1.Image=Image.FromFile(i.impostazioni1.BackPath.Text);

			//opzioni
			i.impostazioni1.UserName.Text=this.UserName;
			i.impostazioni1.LogPath.Text=this.LogPath;
			

			i.ShowDialog();

			if (i.AcceptChanges)
			{
				//Font
				this.p.RTM.LocalMSGColor=i.impostazioni1.Local.ForeColor;
				this.p.RTM.LocalMSGFont=i.impostazioni1.Local.Font;

				this.p.RTM.RemoteMSGColor=i.impostazioni1.Remote.ForeColor;
				this.p.RTM.RemoteMSGFont=i.impostazioni1.Remote.Font;

				//opzioni
				
				this.p.LocalName=this.UserName=i.impostazioni1.UserName.Text;
				this.p.LogPath=this.LogPath=i.impostazioni1.LogPath.Text;

				this.BackImgPath=i.impostazioni1.BackPath.Text;
				this.BackgroundImage.Dispose();
				this.BackgroundImage=i.impostazioni1.pictureBox1.Image.Clone() as Image;
				i.impostazioni1.pictureBox1.Image.Dispose();

			}

			i.Dispose();

			
		}

		private void MenuLoadConf_Click(object sender, System.EventArgs e)
		{
			this.LoadConfig();
		}

		private void MenuSaveConf_Click(object sender, System.EventArgs e)
		{
			this.SaveConfig();
		}

		private void MenuPrint_Click(object sender, System.EventArgs e)
		{
			System.Drawing.Printing.PrintDocument pd=new System.Drawing.Printing.PrintDocument();
		//	pd.PrintPage+=new EventHandler(this.StampaPagina);
			this.printDialog1.AllowSelection=true;
			this.printDialog1.AllowSomePages=true;
			this.printDialog1.AllowPrintToFile=true;
			this.printDialog1.ShowNetwork=true;
			this.printDialog1.Document=pd;

			this.printDialog1.ShowDialog();
		}

		/*private void StampaPagina(object sender, PrintPageEventArgs ev)
		{
		
		
		}*/

		private void MenuAbout_Click(object sender, System.EventArgs e)
		{
			About a =new About(this.ApplRoot);
			a.ShowDialog();
			a.Dispose();
		}

		private void MenuAutoSave_Click(object sender, System.EventArgs e)
		{
			this.MenuAutoSave.Checked^=true;
		}

		private void MenuLogView_Click(object sender, System.EventArgs e)
		{
			LogView LV=new LogView(this.LogPath);
			LV.Show();
		}

		private void MenuClearText_Click(object sender, System.EventArgs e)
		{
			this.richTextBox1.Clear();
		}

		


		

		

		

		

		
	}
}

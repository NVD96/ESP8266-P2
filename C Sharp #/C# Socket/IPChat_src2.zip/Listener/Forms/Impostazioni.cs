using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

using Listener.Utils;

namespace Listener.Forms
{
	/// <summary>
	/// Descrizione di riepilogo per Impostazioni.
	/// </summary>
	public class Impostazioni : System.Windows.Forms.Form
	{
		private System.Windows.Forms.FontDialog fontDialog1;
		private System.Windows.Forms.ColorDialog colorDialog1;
		
		/// <summary>
		/// Variabile di progettazione necessaria.
		/// </summary>
		private System.ComponentModel.Container components = null;
		private System.Windows.Forms.OpenFileDialog openFileDialog1;
		private System.Windows.Forms.Button CancButton;
		private System.Windows.Forms.SaveFileDialog saveFileDialog1;
		public SettingsLib.Impostazioni impostazioni1;
		private System.Windows.Forms.Button OkButton;
		private System.Windows.Forms.Button CancelButton;

		public bool AcceptChanges;

		public Impostazioni()
		{
			//
			// Necessario per il supporto di Progettazione Windows Form
			//
			InitializeComponent();

			this.fontDialog1.ShowColor=true;
			this.fontDialog1.ShowEffects=true;
			
			
			this.colorDialog1.AnyColor=true;
			
		

		}

	

		/// <summary>
		/// Pulire le risorse in uso.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Metodo necessario per il supporto della finestra di progettazione. Non modificare
		/// il contenuto del metodo con l'editor di codice.
		/// </summary>
		private void InitializeComponent()
		{
			this.fontDialog1 = new System.Windows.Forms.FontDialog();
			this.colorDialog1 = new System.Windows.Forms.ColorDialog();
			this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
			this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
			this.impostazioni1 = new SettingsLib.Impostazioni();
			this.OkButton = new System.Windows.Forms.Button();
			this.CancelButton = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// saveFileDialog1
			// 
			this.saveFileDialog1.FileName = "doc1";
			// 
			// impostazioni1
			// 
			this.impostazioni1.Location = new System.Drawing.Point(0, 8);
			this.impostazioni1.Name = "impostazioni1";
			this.impostazioni1.Size = new System.Drawing.Size(576, 328);
			this.impostazioni1.TabIndex = 0;
			// 
			// OkButton
			// 
			this.OkButton.Location = new System.Drawing.Point(368, 352);
			this.OkButton.Name = "OkButton";
			this.OkButton.TabIndex = 1;
			this.OkButton.Text = "Ok";
			this.OkButton.Click += new System.EventHandler(this.OkButton_Click);
			// 
			// CancelButton
			// 
			this.CancelButton.Location = new System.Drawing.Point(464, 352);
			this.CancelButton.Name = "CancelButton";
			this.CancelButton.TabIndex = 2;
			this.CancelButton.Text = "Annulla";
			this.CancelButton.Click += new System.EventHandler(this.CancelButton_Click);
			// 
			// Impostazioni
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(576, 395);
			this.ControlBox = false;
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.CancelButton,
																		  this.OkButton,
																		  this.impostazioni1});
			this.Name = "Impostazioni";
			this.Text = "Impostazioni";
			this.ResumeLayout(false);

		}
		#endregion

		private void CambiaFontLocale_Click(object sender, System.EventArgs e)
		{
		
			this.fontDialog1.Font=this.impostazioni1.Local.Font;
			this.fontDialog1.Color=this.impostazioni1.Local.ForeColor;

			this.fontDialog1.ShowDialog();

			this.impostazioni1.Local.Font=this.fontDialog1.Font;
			this.impostazioni1.Local.ForeColor=this.fontDialog1.Color;
            this.impostazioni1.Local.Update();
		}
		
		private void CambiaFontRemoto_Click(object sender, System.EventArgs e)
		{
			this.fontDialog1.Font=this.impostazioni1.Remote.Font;
			this.fontDialog1.Color=this.impostazioni1.Local.ForeColor;

			this.fontDialog1.ShowDialog();

			this.impostazioni1.Remote.Font=this.fontDialog1.Font;
			this.impostazioni1.Remote.ForeColor=this.fontDialog1.Color;
			this.impostazioni1.Remote.Update();
		
		}
		private void CambiaColoreLocale_Click(object sender, System.EventArgs e)
		{
			
			this.colorDialog1.ShowDialog();
			this.impostazioni1.Local.ForeColor=this.colorDialog1.Color;
			this.impostazioni1.Local.Update();
		}

		private void CambiaColoreRemoto_Click(object sender, System.EventArgs e)
		{
			this.colorDialog1.ShowDialog();
			this.impostazioni1.Remote.ForeColor=this.colorDialog1.Color;
			this.impostazioni1.Remote.Update();
		}

		private void Browse_Click(object sender, System.EventArgs e)
		{
			this.openFileDialog1.Filter="File Grafici (*.jpg;*.bmp;*.gif)|*.jpg;*.bmp;*.gif|Tutti i file (*.*)|*.*";
			this.openFileDialog1.ShowDialog();

			if (this.openFileDialog1.FileName!=null)
			{
				try
				{
					
					this.impostazioni1.pictureBox1.Image=Image.FromFile(this.openFileDialog1.FileName);
					this.impostazioni1.BackPath.Text=this.openFileDialog1.FileName;
				}
				catch
				{
					Strumenti.Error("File non valido");
				}

			}
		}

		private void ButtonBrowseLog_Click(object sender, System.EventArgs e)
		{
			this.saveFileDialog1.Filter="File Rich Text Format (*.rtf)|*.rtf|Tutti i file (*.*)|*.*";
			this.saveFileDialog1.InitialDirectory=this.impostazioni1.LogPath.Text;
			this.saveFileDialog1.FileName=this.impostazioni1.LogPath.Text;
			this.saveFileDialog1.ShowDialog();
			if (this.saveFileDialog1.FileName!=null)
			{
				this.impostazioni1.LogPath.Text=this.saveFileDialog1.FileName;
			}
			
		}


		private void CancelButton_Click(object sender, System.EventArgs e)
		{
			this.AcceptChanges=false;
			this.Close();
		}

		
		private void OkButton_Click(object sender, System.EventArgs e)
		{
			this.AcceptChanges=true;
			this.Close();
		}

		

		

		
		

		
		
		
		
	}
}

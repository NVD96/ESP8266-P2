﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using NETCOM;

namespace ServerTest
{
    public partial class MyChatForm : Form
    {
        AgentRelay m_chatProvider = new AgentRelay();
        ServerRelay m_serverRelay = new ServerRelay(true);

        private enum eTcpCommands                            // Contents.. (Parameters)
        {
            InvalidCommand = 0,
            ChatMessage = 1,

            QueryNameRequest = 2,
            QueryNameResponse = 3,
        };

        public MyChatForm()
        {
            InitializeComponent();
        }

        private void MyChatForm_Load(object sender, EventArgs e)
        {
            m_chatProvider.OnNewPacketReceived += chatProvider_OnNewPacketReceived;

            m_serverRelay.OnNewAgentConnected += m_serverRelay_OnNewAgentConnected;
            m_serverRelay.OnServerFailedToAcceptConnection += m_serverRelay_OnServerFailedToAcceptConnection;
            m_serverRelay.StartServer(null, 1234);

            m_serverRelay.AcceptIncommingConnections = true;
        }

        private void MyChatForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            m_chatProvider.Dispose();
            m_serverRelay.Dispose();        // m_serverRelay.StopServer(true);
        }

        void m_serverRelay_OnServerFailedToAcceptConnection(Exception ex)
        {
            this.Invoke(new MethodInvoker(() => { lbMessages.Items.Insert(0, "EXCEPTION in ServerRelay: " + ex.Message); }));
        }

        void m_serverRelay_OnNewAgentConnected(AgentRelay agentRelay)
        {
            agentRelay.OnNewPacketReceived += chatProvider_OnNewPacketReceived;
            m_chatProvider = agentRelay;

            SendChatMessage("I am now connected to you!");

            this.Invoke(new MethodInvoker(() =>
            {
                btnSend.Enabled = true;
                btnConnect.Enabled = false;
                lbMessages.Items.Insert(0, "New agent received...");
            }));
        }

        private void btnConnect_Click(object sender, EventArgs e)
        {
            try
            {
                m_chatProvider.Connect(tbIPAddress.Text, 1234);
                btnConnect.Enabled = false;
                btnSend.Enabled = true;
            }
            catch
            {
                MessageBox.Show("IP Address is invalid or the other side is not accessable!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public bool SendChatMessage(string txt)
        {
            return m_chatProvider.SendMessage((int)eTcpCommands.ChatMessage, txt);
        }

        private void chatProvider_OnNewPacketReceived(AgentRelay.Packet packet, AgentRelay agentRelay)
        {
            switch(packet.Command)
            {
                case (byte)eTcpCommands.ChatMessage:
                    this.Invoke(new MethodInvoker(() => { lbMessages.Items.Insert(0,AgentRelay.MakeStringFromPacketContents(packet)); }));
                    break;

                case (byte)eTcpCommands.QueryNameRequest:
                    agentRelay.SendMessage((int)eTcpCommands.QueryNameResponse, "TCP/IP Test");
                    break;

                case (byte)eTcpCommands.QueryNameResponse:
                    this.Invoke(new MethodInvoker(() => { lbMessages.Items.Insert(0, "NAME: " + AgentRelay.MakeStringFromPacketContents(packet)); }));
                    break;

                default:
                    agentRelay.SendResponse(AgentRelay.eResponseTypes.InvalidCommand);
                    break;
            }
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            SendChatMessage(tbMessage.Text.Trim());
        }

    }
}

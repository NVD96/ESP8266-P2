package main

import "github.com/mycontroller-org/2mqtt/cmd/sub"

func main() {
	sub.Execute()
}

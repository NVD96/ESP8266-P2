Welcome to the 2mqtt server. This repository is part of the MyController.org family!
Source code: https://github.com/mycontroller-org/2mqtt


To start the service, run the command,
./ctl.sh start


To stop the service, run the command,
./ctl.sh stop

#ifndef __DELAY_H__
#define __DELAY_H__

void delay(unsigned int);
void delay2(unsigned int);

#endif

#ifndef __UART0_H__
#define __UART0_H__

#include "main.h"


void UART0_Init(void);
void GPIO_Init(void);

#endif

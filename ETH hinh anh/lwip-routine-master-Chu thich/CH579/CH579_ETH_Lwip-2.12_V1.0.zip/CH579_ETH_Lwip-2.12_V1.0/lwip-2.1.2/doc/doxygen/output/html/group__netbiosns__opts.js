var group__netbiosns__opts =
[
    [ "LWIP_NETBIOS_RESPOND_NAME_QUERY", "group__netbiosns__opts.html#gaa9dec8fc3dee5e72fbe9b854437bce84", null ],
    [ "NETBIOS_LWIP_NAME", "group__netbiosns__opts.html#ga468c2ae67a79ce082ee585a438f7373b", null ]
];
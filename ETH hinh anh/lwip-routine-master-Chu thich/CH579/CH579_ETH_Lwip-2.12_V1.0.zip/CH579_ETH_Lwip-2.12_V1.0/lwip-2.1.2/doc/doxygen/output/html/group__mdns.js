var group__mdns =
[
    [ "Options", "group__mdns__opts.html", "group__mdns__opts" ],
    [ "mdns_resp_netif_settings_changed", "group__mdns.html#gab2edba12d5cad1949f7ca040ae12beec", null ],
    [ "mdns_resp_add_netif", "group__mdns.html#gaa619ac8f46a4b4021195720f0355cbeb", null ],
    [ "mdns_resp_add_service", "group__mdns.html#ga824e992e94be216c8e059f48f49a59ce", null ],
    [ "mdns_resp_add_service_txtitem", "group__mdns.html#ga01c85202f4b85edc8b571f2f419db576", null ],
    [ "mdns_resp_announce", "group__mdns.html#ga0f462fb91a9d0323bb4636bd725f0e85", null ],
    [ "mdns_resp_del_service", "group__mdns.html#ga3df2ae751cdfdffb0a567390940eb8ad", null ],
    [ "mdns_resp_init", "group__mdns.html#ga5fa15978a398dae1a8d7620ae169bdd3", null ],
    [ "mdns_resp_remove_netif", "group__mdns.html#gaa8144e3c77a92c4043e6214ff6b6010c", null ],
    [ "mdns_resp_rename_netif", "group__mdns.html#ga7b1473e595eb0c185bab293f3ec2e50e", null ],
    [ "mdns_resp_rename_service", "group__mdns.html#gaf273897059f1bbddc74cfcb820777dd9", null ],
    [ "mdns_resp_restart", "group__mdns.html#ga93eccdc0d9afff0f24160d31c70e2c9a", null ]
];
var dir_8da39adb2a11af660bdd7075b7323870 =
[
    [ "socket.h", "socket_8h.html", null ]
];
var group__netifapi__netif =
[
    [ "netifapi_netif_remove", "group__netifapi__netif.html#ga0e3f522b900a0ba04421c4587e790373", null ],
    [ "netifapi_netif_set_default", "group__netifapi__netif.html#ga862d6cfa5d36b2c36d7b1671e8d95ccf", null ],
    [ "netifapi_netif_set_down", "group__netifapi__netif.html#ga22c02edde32743ccfd41924da0601a16", null ],
    [ "netifapi_netif_set_link_down", "group__netifapi__netif.html#ga2a9694804743f5466c4ecc400b7f07e4", null ],
    [ "netifapi_netif_set_link_up", "group__netifapi__netif.html#gac054a60a32447019913d34da63924853", null ],
    [ "netifapi_netif_set_up", "group__netifapi__netif.html#ga6ce735fe79efe1739e53b7f0e975ac76", null ],
    [ "netifapi_netif_add", "group__netifapi__netif.html#gacc063c5a3071e34eec7376651e35a519", null ],
    [ "netifapi_netif_index_to_name", "group__netifapi__netif.html#gab7914d77d0a89fd6c31048feb0bdafb6", null ],
    [ "netifapi_netif_name_to_index", "group__netifapi__netif.html#gad4a821182d01eafa4ca258f958fcb089", null ],
    [ "netifapi_netif_set_addr", "group__netifapi__netif.html#ga31755ea6dbb213236bfce19bcbe8c973", null ]
];
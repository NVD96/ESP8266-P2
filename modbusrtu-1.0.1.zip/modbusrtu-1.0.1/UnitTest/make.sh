
make clean
make all

#ifndef SERIAL_H
#define SERIAL_H
void serial_init(void);
#endif

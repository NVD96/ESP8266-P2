#ifndef __VERSION_H__
#define __VERSION_H__

#define FIRMWARE_VERSION_MAJOR 0
#define FIRMWARE_VERSION_MINOR 2

#endif

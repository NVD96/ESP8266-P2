Shared library implementing the espstlink protocol for use in tools like stm8flash.

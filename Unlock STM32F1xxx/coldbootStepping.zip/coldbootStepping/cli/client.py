#!/usr/bin/python3
#
# Copyright (C) 2017 Stefan Tatschner
#
# This Source Code Form is subject to the terms of the MIT License.
# If a copy of the MIT License was not distributed with this file,
# you can obtain one at https://opensource.org/licenses/MIT
#

import argparse
import functools
import logging
import os
import shlex
import signal
import subprocess
import sys
import time
from datetime import datetime as dt
from subprocess import Popen, PIPE, STDOUT, TimeoutExpired
from tempfile import TemporaryDirectory

import numpy as np

CRC_TABLE = np.array((
    0x00000000, 0x77073096, 0xEE0E612C, 0x990951BA, 0x076DC419, 0x706AF48F,
    0xE963A535, 0x9E6495A3, 0x0EDB8832, 0x79DCB8A4, 0xE0D5E91E, 0x97D2D988,
    0x09B64C2B, 0x7EB17CBD, 0xE7B82D07, 0x90BF1D91, 0x1DB71064, 0x6AB020F2,
    0xF3B97148, 0x84BE41DE, 0x1ADAD47D, 0x6DDDE4EB, 0xF4D4B551, 0x83D385C7,
    0x136C9856, 0x646BA8C0, 0xFD62F97A, 0x8A65C9EC, 0x14015C4F, 0x63066CD9,
    0xFA0F3D63, 0x8D080DF5, 0x3B6E20C8, 0x4C69105E, 0xD56041E4, 0xA2677172,
    0x3C03E4D1, 0x4B04D447, 0xD20D85FD, 0xA50AB56B, 0x35B5A8FA, 0x42B2986C,
    0xDBBBC9D6, 0xACBCF940, 0x32D86CE3, 0x45DF5C75, 0xDCD60DCF, 0xABD13D59,
    0x26D930AC, 0x51DE003A, 0xC8D75180, 0xBFD06116, 0x21B4F4B5, 0x56B3C423,
    0xCFBA9599, 0xB8BDA50F, 0x2802B89E, 0x5F058808, 0xC60CD9B2, 0xB10BE924,
    0x2F6F7C87, 0x58684C11, 0xC1611DAB, 0xB6662D3D, 0x76DC4190, 0x01DB7106,
    0x98D220BC, 0xEFD5102A, 0x71B18589, 0x06B6B51F, 0x9FBFE4A5, 0xE8B8D433,
    0x7807C9A2, 0x0F00F934, 0x9609A88E, 0xE10E9818, 0x7F6A0DBB, 0x086D3D2D,
    0x91646C97, 0xE6635C01, 0x6B6B51F4, 0x1C6C6162, 0x856530D8, 0xF262004E,
    0x6C0695ED, 0x1B01A57B, 0x8208F4C1, 0xF50FC457, 0x65B0D9C6, 0x12B7E950,
    0x8BBEB8EA, 0xFCB9887C, 0x62DD1DDF, 0x15DA2D49, 0x8CD37CF3, 0xFBD44C65,
    0x4DB26158, 0x3AB551CE, 0xA3BC0074, 0xD4BB30E2, 0x4ADFA541, 0x3DD895D7,
    0xA4D1C46D, 0xD3D6F4FB, 0x4369E96A, 0x346ED9FC, 0xAD678846, 0xDA60B8D0,
    0x44042D73, 0x33031DE5, 0xAA0A4C5F, 0xDD0D7CC9, 0x5005713C, 0x270241AA,
    0xBE0B1010, 0xC90C2086, 0x5768B525, 0x206F85B3, 0xB966D409, 0xCE61E49F,
    0x5EDEF90E, 0x29D9C998, 0xB0D09822, 0xC7D7A8B4, 0x59B33D17, 0x2EB40D81,
    0xB7BD5C3B, 0xC0BA6CAD, 0xEDB88320, 0x9ABFB3B6, 0x03B6E20C, 0x74B1D29A,
    0xEAD54739, 0x9DD277AF, 0x04DB2615, 0x73DC1683, 0xE3630B12, 0x94643B84,
    0x0D6D6A3E, 0x7A6A5AA8, 0xE40ECF0B, 0x9309FF9D, 0x0A00AE27, 0x7D079EB1,
    0xF00F9344, 0x8708A3D2, 0x1E01F268, 0x6906C2FE, 0xF762575D, 0x806567CB,
    0x196C3671, 0x6E6B06E7, 0xFED41B76, 0x89D32BE0, 0x10DA7A5A, 0x67DD4ACC,
    0xF9B9DF6F, 0x8EBEEFF9, 0x17B7BE43, 0x60B08ED5, 0xD6D6A3E8, 0xA1D1937E,
    0x38D8C2C4, 0x4FDFF252, 0xD1BB67F1, 0xA6BC5767, 0x3FB506DD, 0x48B2364B,
    0xD80D2BDA, 0xAF0A1B4C, 0x36034AF6, 0x41047A60, 0xDF60EFC3, 0xA867DF55,
    0x316E8EEF, 0x4669BE79, 0xCB61B38C, 0xBC66831A, 0x256FD2A0, 0x5268E236,
    0xCC0C7795, 0xBB0B4703, 0x220216B9, 0x5505262F, 0xC5BA3BBE, 0xB2BD0B28,
    0x2BB45A92, 0x5CB36A04, 0xC2D7FFA7, 0xB5D0CF31, 0x2CD99E8B, 0x5BDEAE1D,
    0x9B64C2B0, 0xEC63F226, 0x756AA39C, 0x026D930A, 0x9C0906A9, 0xEB0E363F,
    0x72076785, 0x05005713, 0x95BF4A82, 0xE2B87A14, 0x7BB12BAE, 0x0CB61B38,
    0x92D28E9B, 0xE5D5BE0D, 0x7CDCEFB7, 0x0BDBDF21, 0x86D3D2D4, 0xF1D4E242,
    0x68DDB3F8, 0x1FDA836E, 0x81BE16CD, 0xF6B9265B, 0x6FB077E1, 0x18B74777,
    0x88085AE6, 0xFF0F6A70, 0x66063BCA, 0x11010B5C, 0x8F659EFF, 0xF862AE69,
    0x616BFFD3, 0x166CCF45, 0xA00AE278, 0xD70DD2EE, 0x4E048354, 0x3903B3C2,
    0xA7672661, 0xD06016F7, 0x4969474D, 0x3E6E77DB, 0xAED16A4A, 0xD9D65ADC,
    0x40DF0B66, 0x37D83BF0, 0xA9BCAE53, 0xDEBB9EC5, 0x47B2CF7F, 0x30B5FFE9,
    0xBDBDF21C, 0xCABAC28A, 0x53B39330, 0x24B4A3A6, 0xBAD03605, 0xCDD70693,
    0x54DE5729, 0x23D967BF, 0xB3667A2E, 0xC4614AB8, 0x5D681B02, 0x2A6F2B94,
    0xB40BBE37, 0xC30C8EA1, 0x5A05DF1B, 0x2D02EF8D),
    dtype=np.uint32
)

#
# Decorators
#
def trace(func):
    """
    A decorator to trace function calls. Once applied to a method every
    call to the decorated function, including its arguments and keyword
    arguments is logged to the root logger in debug level.
    """
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        logging.debug('Calling "{}" with args "{}" and kwargs "{}"'.format(
            func.__name__,
            args,
            kwargs,
        ))
        return func(*args, **kwargs)
    return wrapper


#
# Calculation methods
#
def reverse_crc(crc, crc_old):
    table_val = np.uint32((crc_old >> 8) ^ crc)
    table_ind, = np.where(CRC_TABLE == table_val)

    if len(table_ind) == 1:
        return np.uint8(table_ind[0] ^ crc_old)

    # An error has occured.
    # For example: duplicated indexes found, no value found, ...
    return None


def extract_crc(filename):
    """
    Extract the CRC sum from the ramdump file at the well known offset.

    returns:
        Extracted CRC sum as uint16.
    """
    with open(filename, 'rb') as f:
        # Address is obtained from gdb. Stackpointer offset is excluded.
        f.seek(0x01fdc)
        crc_extracted = f.read(4)
        # http://stackoverflow.com/a/28996024/2587286
        crc_extracted = int.from_bytes(crc_extracted, byteorder='little')
        crc_extracted = np.uint32(crc_extracted)
        logging.info(
            'Read CRC from RAM dump: "0x{:04X}"'.format(crc_extracted)
        )
        return crc_extracted


#
# Communication Primitives
# Methods interacting with buspirate
#
# The serial UART protocol with the magic and custom
# microcotroller board is defined in ascii mode. The
# protocol is very primitive, stateless and no responses
# are expected. The following commands are available
# (please note the trailing newline!):
#
#   Reset Low:              R\n
#   Reset High:             r\n
#   Reset Pulse:            P\n
#   Set Reset Pulsewidth:   TXXXXXXXX\n (formatstring for X: {:08X})
#   Relais on:              S\n
#   Relais off:             s\n
@trace
def reset_low(pd=0.01):
    with open(TTY, 'w') as f:
        f.write('r\n')
    time.sleep(pd)


@trace
def reset_high(pd=0.01):
    with open(TTY, 'w') as f:
        f.write('R\n')
    time.sleep(pd)


@trace
def reset_pulse(pd=0.01):
    with open(TTY, 'w') as f:
        f.write('P\n')
    time.sleep(pd)


@trace
def relais_on(pd=0.01):
    with open(TTY, 'w') as f:
        f.write('S\n')
    time.sleep(pd)


@trace
def relais_off(pd=0.01):
    with open(TTY, 'w') as f:
        f.write('s\n')
    time.sleep(pd)


@trace
def set_pulse_width(width, pd=0.01):
    logging.info('Setting pulse width: "0x{:08X}"'.format(width))
    cmd = 'T{:08X}\n'.format(width)
    with open(TTY, 'w') as f:
        for ch in cmd:
            f.write(ch)
            time.sleep(0.01)
    time.sleep(pd)


@trace
def dump_ram(ocd_args):
    """
    Start openocd and dump the RAM of the STM32 chip. When openocd
    times out, it is killed and an exception is raised.

    returns:
        filename        The filename containing the RAM dump.

    raises:
        TimeoutExpired  When openocd timeout out.
    """
    logging.debug('Starting openocd...')
    openocd_proc = subprocess.Popen(
        ['openocd'] + shlex.split(ocd_args),
        stdout=PIPE,
        stderr=STDOUT,
    )

    filename = 'memdump-{}.bin'.format(dt.now().strftime('%F-%H%M%s'))
    if TMPDIR:
        filename = os.path.join(TMPDIR.name, filename)

    time.sleep(5)
    reset_high()

    nc_input = ('sleep 2000\ndump_image {} 0x20000000 8192\n'
                'shutdown\n').format(filename)
    nc_input = nc_input.encode('ascii')
    nc_proc = Popen(
        ['nc', 'localhost', '4444'],
        stdout=PIPE,
        stdin=PIPE,
        stderr=PIPE,
    )

    logging.info('Dumping RAM to "{}"'.format(filename))
    logging.debug('Piping "{}" to openocd via netcat'.format(nc_input))
    nc_proc.communicate(input=nc_input)
    logging.debug(openocd_proc.stdout.read().decode().strip())
    logging.debug(
        'Awaiting openocd process "{}" to terminate'.format(openocd_proc.pid)
    )

    try:
        openocd_proc.wait(timeout=5)
    except TimeoutExpired:
        logging.warning(
            'Timeout! Killing openocd process "{}"'.format(openocd_proc.pid)
        )
        openocd_proc.kill()
        raise

    return filename


#
# Helpers
#
def init_uart():
    subprocess.call(['stty', '--file=/dev/ttyUSB0', '115200', 'raw', '-echo'])


def switch_off_testbed():
    """Frequently used helper to switch off the testbed painlessly."""
    time.sleep(0.1)
    reset_low()
    relais_off()


def parse_args():
    # Magic foo: http://stackoverflow.com/a/32891625/2587286
    def fc(prog):
        return argparse.HelpFormatter(
            prog,
            max_help_position=40,
            width=100,
        )

    # More magic foo: http://stackoverflow.com/a/25513044/2587286
    def auto_int(x):
        return int(x, 0)

    parser = argparse.ArgumentParser(
        formatter_class=fc,
        description='Super fancy CRC cracker',
    )
    parser.add_argument(
        '-w',
        '--pulsewidth',
        metavar='WIDTH',
        type=auto_int,
        default=0x0200,
        help='Specifiy initial pulsewidth [default: "0x200]'
    )
    parser.add_argument(
        '-c',
        '--crc',
        type=auto_int,
        default=0xFFFFFFFF,
        help='Initial CRC value [default: "0xFFFFFFFF"]'
    )
    parser.add_argument(
        '--searchfirst',
        action='store_true',
        help='Set to search for the CRC value given by --crc [default: false]'
    )
    parser.add_argument(
        '-t',
        '--tty',
        metavar='tty',
        type=str,
        help='Specify tty device node [default: "/dev/ttyUSB0"]',
    )
    parser.add_argument(
        '-a',
        '--ocd-args',
        metavar='ARGS',
        type=str,
        default=(
            '-f '
            '/usr/share/openocd/scripts/interface/stlink-v2.cfg '
             '-f '
             '/usr/share/openocd/scripts/target/stm32f0x.cfg '
        ),
        help='Overwrite openocd args (space separated string)',
    )
    parser.add_argument(
        '-n',
        '--no-tempdir',
        action='store_true',
        help='Do not use a tempdir for memdumps',
    )
    parser.add_argument(
        '-o',
        '--outfile',
        metavar='PATH',
        type=str,
        default='extracted-{}.bin'.format(dt.now().strftime('%F-%H%M%s')),
        help='Specify output file [default: "extracted-$TIMESTAMP.bin"]',
    )
    parser.add_argument(
        '-l',
        '--loglevel',
        metavar='LEVEL',
        type=str,
        default='INFO',
        help='CRITICAL, ERROR, WARNING, INFO [default], DEBUG'
    )

    return parser.parse_args()


def init_logging(loglevel):
    # From python docs. No magic stackoverflow involved. :)
    # https://docs.python.org/3/howto/logging.html#logging-to-a-file
    numeric_level = getattr(logging, loglevel.upper(), None)
    if not isinstance(numeric_level, int):
        print('Invalid log level: "{}"'.format(loglevel))
        exit(1)

    logging.basicConfig(
        format='%(asctime)s %(levelname)s: %(message)s',
        level=numeric_level,
    )


def main():
    args = parse_args()

    # Overwrite global buspirate device node config with CLI argument.
    global TTY
    TTY = args.tty if args.tty else '/dev/ttyUSB0'

    if not os.path.exists(TTY):
        print('TTY "{}" does not exist.'.format(TTY))
        exit(1)

    global TMPDIR
    TMPDIR = None if args.no_tempdir else TemporaryDirectory(prefix="crccrack-")

    pulsewidth = args.pulsewidth
    crc_old = np.uint32(args.crc)
    crcs_found = [crc_old]
    crc_loaded = False;

    init_logging(args.loglevel)
    logging.info('{} called with: {}'.format(sys.argv[0], args))
    logging.info('Writing data to: {}'.format(args.outfile))

    init_uart()
    # Ensure a well defined state at the beginning of magic.
    switch_off_testbed()

    # Use unbuffered writes.
    with open(args.outfile, 'ab', 0) as f:
        while True:
            if args.searchfirst is True or crc_loaded is True:
                logging.info((
                    'Current params: '
                    'crc_old="0x{:04X}", '
                    'pulsewidth="0x{:08X}"'.format(crc_old, pulsewidth)
                ))

            set_pulse_width(pulsewidth)
            reset_low()
            relais_on(pd=0.3)
            reset_pulse()

            try:
                # Dump RAM first and extract crc from the well known offset.
                crc = extract_crc(dump_ram(args.ocd_args))

                if args.searchfirst is True and crc_loaded is False:
                    crc_old = crc
                    logging.info('Using 0x{:08X} as initial CRC'.format(crc_old))
                    crc_loaded = True;
                    switch_off_testbed()
                    crcs_found.append(crc)
                    pulsewidth += 0x06;
                    logging.info('Increasing pulsewidth')
                    continue
            except TimeoutExpired:
                logging.error('Dumping RAM timed out. Retrying...')
                switch_off_testbed()
                continue
            except FileNotFoundError:
                logging.critical('Ramdump file does not exist. Retrying...')
                logging.critical('Does openocd work properly?')
                switch_off_testbed()
                continue

            if crc in crcs_found:
                logging.info('Previous CRC appeared again')
                logging.info('Increasing pulsewidth')
                pulsewidth += 0x06
                switch_off_testbed()
                continue

            data = reverse_crc(crc, crc_old)

            if data is None:
                logging.info('Decreasing pulsewidth')
                pulsewidth -= 0x03
                switch_off_testbed()
                continue

            logging.info('Writing byte "0x{:02X}" to file'.format(data))
            # Fuck you debian "stable"!
            try:
                f.write(data.tobytes())
            except AttributeError:
                f.write(data.tostring())

            # Cleanup and preparation for next iteration.
            # Let's just keep the last 3 CRCs in a list...
            crc_old = crc
            crcs_found.append(crc)

            if len(crcs_found) > 3:
                crcs_found.pop(0)

            logging.info('Increasing pulsewidth')
            pulsewidth += 0x06
            switch_off_testbed()


def cleanup():
    logging.critical('Switching off testbed.')
    switch_off_testbed()
    logging.info('Cleaning up tempory directory.')
    if TMPDIR:
        TMPDIR.cleanup()


def sigtermhandler(signum, frame):
    logging.critical('SIGTERM received.')
    cleanup()
    exit(128 + signum)


if __name__ == '__main__':
    try:
        signal.signal(signal.SIGTERM, sigtermhandler)
        main()
    except KeyboardInterrupt:
        logging.critical('SIGINT received.')
        cleanup()
        exit(128 + signal.SIGINT)

/*
 * Copyright (C) 2017 Obermaier Johannes
 *
 * This Source Code Form is subject to the terms of the MIT License.
 * If a copy of the MIT License was not distributed with this file,
 * you can obtain one at https://opensource.org/licenses/MIT
 */

#include <stdint.h>
#include <string.h>
#include "st/stm32f0xx.h"

#define UART_WAIT_TRANSMIT do { ; } while (!(USART2->ISR & USART_ISR_TXE));
#define UART_BUFFER_LEN (12u)

/* Pin usage: */
/* PC8: Reset */
/* PC9: Power */

uint32_t pulseWidth = 1u;


static void uartExecCmd( uint8_t const * const cmd );
static void waitPulse( uint32_t const wtime ) __attribute__ ((naked));


void sendDbg( const char * const str )
{
	const char * strptr = str;

	while (*strptr)
	{
		USART2->TDR = *strptr;
		++strptr;
		UART_WAIT_TRANSMIT;
	}
}

static void waitPulse( uint32_t const wtime )
{
	/* Each loop iteration takes 4 clock cycles, thus 0.5µs at 8MHz */
	__asm__ __volatile__(	".syntax unified	\n"
				"	mov r1, %0	\n"
				"lop1: 		\n"
				"	subs r1, #1	\n"
				"	bne lop1	\n"
				"	bx  lr		\n"
				".syntax divided	\n"
				: : "r" (wtime): "cc", "r1");
}


static void uartExecCmd( uint8_t const * const cmd )
{
	uint8_t i = 1u;
	uint8_t c = 0u;

	switch (cmd[0])
	{
		case 'S':
			GPIOC->ODR |= (GPIO_ODR_9);
			sendDbg("Power on\r\n");
			break;

		case 's':
			GPIOC->ODR &= ~(GPIO_ODR_9);
			sendDbg("Power off\r\n");
			break;

		case 'R':
			GPIOC->ODR |= (GPIO_ODR_8);
			sendDbg("Reset on\r\n");
			break;

		case 'r':
			GPIOC->ODR &= ~(GPIO_ODR_8);
			sendDbg("Reset off\r\n");
			break;

		case 'P':
		case 'p':
			GPIOC->ODR |= (GPIO_ODR_8);
			waitPulse(pulseWidth);
			GPIOC->ODR &= ~(GPIO_ODR_8);
			sendDbg("Reset pulse\r\n");
			break;

		case 't':
		case 'T':
			pulseWidth = 0u;

			for (i = 1; i < (UART_BUFFER_LEN - 1u); ++i)
			{
				c = cmd[i];
				if ((c <= '9') && (c >= '0'))
				{
					c -= '0';
				}
				else if ((c >= 'a') && (c <= 'f'))
				{
					c -= 'a';
					c += 0x0A;
				}
				else if ((c >= 'A') && (c <= 'F'))
				{
					c -= 'A';
					c += 0x0A;
				}
				else
				{
					break;
				}
				pulseWidth <<= 4u;
				pulseWidth |= c;
			}

			/* prevent T=0 (infinite loop) */
			if (pulseWidth == 0u)
			{
				pulseWidth = 1u;
			}

			sendDbg("Time Set\r\n");
			break;

		case '\r':
		case '\n':
		case '\0':
			/* ignore */
			break;

		default:
			sendDbg("Unknown Command\r\n");
			break;

	}
}

int main( void )
{
	/* Enable all GPIO clocks */
	RCC->AHBENR |= RCC_AHBENR_GPIOAEN | RCC_AHBENR_GPIOBEN | RCC_AHBENR_GPIOCEN | RCC_AHBENR_GPIODEN | RCC_AHBENR_GPIOEEN | RCC_AHBENR_GPIOFEN;

	GPIOC->MODER |= GPIO_MODER_MODER8_0 | GPIO_MODER_MODER9_0;
	GPIOC->OSPEEDR |= (GPIO_OSPEEDR_OSPEEDR8_0 | GPIO_OSPEEDR_OSPEEDR8_1) | (GPIO_OSPEEDR_OSPEEDR9_0 | GPIO_OSPEEDR_OSPEEDR9_1);

	/* USART2 Configuration */
	RCC->APB1ENR |= RCC_APB1ENR_USART2EN;
	GPIOA->MODER |= GPIO_MODER_MODER2_1 | GPIO_MODER_MODER3_1;
	GPIOA->OSPEEDR |= (GPIO_OSPEEDR_OSPEEDR2_0 | GPIO_OSPEEDR_OSPEEDR2_1) | (GPIO_OSPEEDR_OSPEEDR3_0 | GPIO_OSPEEDR_OSPEEDR3_1);
	GPIOA->PUPDR |= GPIO_PUPDR_PUPDR2_1 | GPIO_PUPDR_PUPDR3_1;
	GPIOA->AFR[0] = (0x01u << (2u * 4u)) | (0x01u << (3u * 4u));
	USART2->CR2 = 0u;
	USART2->BRR = 0x1A1u / 6u; /* 115200 Baud at 8 MHz clock */
	USART2->CR1 = USART_CR1_UE | USART_CR1_RE | USART_CR1_TE;
	sendDbg("\r\nSystem booted\r\n");

	uint8_t volatile uartData = 0u;
	uint8_t uartStr[UART_BUFFER_LEN] = {0u};
	uint8_t uartStrInd = 0u;

	/* Flush UART buffers */
	uartData = USART2->RDR;
	uartData = USART2->RDR;
	uartData = USART2->RDR;

	while (1u)
	{
		while (!(USART2->ISR & USART_ISR_RXNE))
		{
			;
		}
		uartData = USART2->RDR;

		switch (uartData)
		{
			/* ignore \t */
			case '\t':
				break;

			/* Accept \r and \n as command delimiter */
			case '\r':
			case '\n':
				/* Execute Command */
				sendDbg("Exec: ");
				uartExecCmd(uartStr);
				uartStrInd = 0u;
				memset(uartStr, 0x00u, sizeof(uartStr));
				break;

			default:
				if (uartStrInd < (UART_BUFFER_LEN - 1u))
				{
					uartStr[uartStrInd] = uartData;
					++uartStrInd;
				}
				break;
		}
	}

	return 0u;
}

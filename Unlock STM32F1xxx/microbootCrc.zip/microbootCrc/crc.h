/*
 * Copyright (C) 2017 Obermaier Johannes
 *
 * This Source Code Form is subject to the terms of the MIT License.
 * If a copy of the MIT License was not distributed with this file,
 * you can obtain one at https://opensource.org/licenses/MIT
 */

 
#ifndef INC_CRC_H
#define INC_CRC_H

void crc32Byte( uint32_t * const crc, uint8_t const data );
uint32_t crc32Compute( uint8_t const * const input, uint32_t const len );

#endif

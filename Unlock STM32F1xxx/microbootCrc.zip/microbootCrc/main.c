/*
 * Copyright (C) 2017 Obermaier Johannes
 *
 * This Source Code Form is subject to the terms of the MIT License.
 * If a copy of the MIT License was not distributed with this file,
 * you can obtain one at https://opensource.org/licenses/MIT
 */


#include <stdint.h>
#include "st/stm32f0xx.h"
#include "crc.h"

/* references to linker script to get the address+size of the firmware (source data for CRC computation) */
extern uint32_t *_flashFirmwareStart;
extern uint32_t *_flashFirmwareEnd;


/* The following three variables serve as an example for data in different sections. In cold boot attacks, variables in .data and .bss can be read by the debugger directly. Constants in Flash, as well as the firmware itself, are not readible directly. Nevertheless, the firmware including any constants can be extracted using our cold-boot-stepping attack. */

/* exampleFlashConstant will be placed in the .rodata section in the Flash memory, next to the system's firmware. This data will _not_ be loaded into SRAM. */
const uint8_t exampleFlashConstant[] = "This is some secret data, which is stored in the system's flash memory together with the firmware. If you can read this, your attack works correctly!";

/* exampleDATAVariable takes space in the .data section */
uint8_t volatile exampleDATAVariable[] = "This variable ends up in .data and can be read by the debugger directly.";

/* exampleBSSVar takes 512 bytes in the .bss section. */
uint8_t volatile exampleBSSVar[512];


/* Systick config (no influence on proof-of-concept code, used just for LED blinking after CRC computation) */
#define FCPU (8000000u) /* 8 MHz internal clock */
#define BLINK_INTERVAL_MS (500u) /* Blink every 500ms */
#define SYSTICK_MAX (0xFFFFFFu)
#define SYSTICK_WAIT (SYSTICK_MAX - ((FCPU * BLINK_INTERVAL_MS) / 1000u))
#define SYSTICK_CSR_ADDR ((uint32_t *) 0xE000E010u)
#define SYSTICK_CVR_ADDR ((uint32_t *) 0xE000E018u)
#define SYSTICK_CSR_ON (0x00000005u)
/* Systick config end */


int main( void )
{
	uint32_t crc = 0u;
	uint32_t i = 0u;

	/* Enable all GPIO clocks */
	RCC->AHBENR |= RCC_AHBENR_GPIOAEN | RCC_AHBENR_GPIOBEN | RCC_AHBENR_GPIOCEN | RCC_AHBENR_GPIODEN | RCC_AHBENR_GPIOEEN | RCC_AHBENR_GPIOFEN;

	/* Configure LED output pins (PC9, PC8) */
	GPIOC->MODER |= GPIO_MODER_MODER8_0 | GPIO_MODER_MODER9_0;
	GPIOC->OSPEEDR |= (GPIO_OSPEEDR_OSPEEDR8_0 | GPIO_OSPEEDR_OSPEEDR8_1) | (GPIO_OSPEEDR_OSPEEDR9_0 | GPIO_OSPEEDR_OSPEEDR9_1);

	/* PC9 LED ON */
	GPIOC->ODR |= GPIO_ODR_9;


	/* In this example, the CRC is computed over the currently executed firmware. */
	crc = crc32Compute((uint8_t *) &_flashFirmwareStart, ((uintptr_t) &_flashFirmwareEnd - (uintptr_t) &_flashFirmwareStart));



	/* ##### END OF CRC Code / proof-of-concept. An example task follows, which blinks the LEDs and writes some data to the SRAM ##### */

	/* PC9 LED OFF */
	GPIOC->ODR ^= GPIO_ODR_9;

	/* PC8 LED ON */
	GPIOC->ODR ^= GPIO_ODR_8;

 	/* suppress gcc warning due to unused variables... */
	crc |= 0u;

	/* fill exampleBSSVar with incrementing data values */
	for (i = 0u; i < 512u; ++i)
	{
		exampleBSSVar[i] = i & 0xFFu;
	}

	/* Initialize the Systick timer and blink the LEDs */
	uint32_t volatile *sysTickCSR = SYSTICK_CSR_ADDR;
	uint32_t volatile *sysTickCVR = SYSTICK_CVR_ADDR;
	*sysTickCSR = SYSTICK_CSR_ON;
	*sysTickCVR = SYSTICK_MAX;

	while (1u)
	{
		/* Wait for approx. 500ms */
		while (*sysTickCVR > (SYSTICK_WAIT))
		{
			; /* Wait... */
		}

		/* Reset Timer */
		*sysTickCVR = SYSTICK_MAX;

		/* Blink LEDs */
		GPIOC->ODR ^= (GPIO_ODR_8) | (GPIO_ODR_9);
	}

	return 0u;
}

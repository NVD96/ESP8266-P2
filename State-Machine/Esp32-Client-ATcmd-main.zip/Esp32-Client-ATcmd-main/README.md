# Esp32-Client-ATcmd
Example: MCU control Esp32 through AT Command, Client - Sever (Local)

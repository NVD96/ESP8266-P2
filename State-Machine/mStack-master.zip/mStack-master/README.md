# mStack
Introduction: https://docs.google.com/presentation/d/1deQKRg0LhhAfUAAlzsoK3S0EYKm-wdVp/edit?usp=sharing&ouid=115677683991422284563&rtpof=true&sd=true

Event-Driven: https://github.com/hongsan/random/discussions/7

State-Machine: https://docs.google.com/document/d/12TmRmmMCdQwuzwci6eULvQRrKmXvgtzN2RMRyjY_XIM/edit?usp=sharing

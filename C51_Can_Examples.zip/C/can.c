/**
 * @file $RCSfile: can.c,v $
 *
 * Copyright (c) 2004 Atmel.
 *
 * Please read file license.txt for copyright notice.
 *
 * @brief This file is an example to use can networking with id and mask functionality.
 *
 * This file can be parsed by Doxygen for automatic documentation
 * generation.
 * Put here the functional description of this file within the software
 * architecture of your program.
 *
 * @version $Revision: 1.0 $ $Name:  $
 */

/* @section  I N C L U D E S */
#include "t89c51cc01.h"

/*_____ D E F I N I T I O N S ______________________________________________*/

/* baud rate and bit timing parameters at Fosc=12Mhz */
/* refert to Xcalculator software on Atmel website for other bit timing */

#define BRP_100k    0x05
#define SJW_100k    0x00
#define PRS_100k    0x01
#define PHS2_100k   0x03
#define PHS1_100k   0x02

#define MSK_CANGCON_ENA  	0x02
#define MSK_CANGCON_GRES 	0x01
#define DLC_MAX            8
#define CH_DISABLE         0x00
#define CH_RxENA           0x80
#define CH_TxENA           0x40
#define MSK_CANGIE_ENRX    0x20
#define MSK_CANGIE_ENTX    0x10

unsigned char num_channel, num_data;

/**
 * FUNCTION_PURPOSE: This file set up Can at 100Kbauds with channel 0 id 0x123 in reception
 * and channel 1 id 0x001 in emission.
 * FUNCTION_INPUTS: void
 * FUNCTION_OUTPUTS: void
 */
void main(void)
{
CANGCON |= MSK_CANGCON_GRES;/* reset CAN */ 
/* reset all mailboxes */
for (num_channel = 0; num_channel < 15; num_channel++)
{
   CANPAGE  = num_channel << 4;
   CANCONCH = CH_DISABLE;
   CANSTCH  = 0;
   CANIDT1  = 0;
   CANIDT2  = 0;
   CANIDT3  = 0;
   CANIDT4  = 0;
   CANIDM1  = 0;
   CANIDM2  = 0;
   CANIDM3  = 0;
   CANIDM4  = 0;
   for (num_data = 0; num_data < 8; num_data++) CANMSG = 0;
}
/* setup bit timing */
CANBT1   =  BRP_100k  << 1;                  /* BRP=0x00; */
CANBT2  &= ~0x60;                            /* reset SJW   */
CANBT2  |=  SJW_100k  << 5;                  /* SJW=0x00; */
CANBT2  &= ~0x0E;                            /* reset PRS   */       
CANBT2  |=  PRS_100k  << 1;                  /* PRS=0x02; */
CANBT3  &= ~0x70;                            /* reset PHS2  */       
CANBT3  |=  PHS2_100k << 4;                  /* PHS2=0x03;*/
CANBT3  &= ~0x0E;                            /* reset PHS1  */
CANBT3  |=  PHS1_100k << 1;                  /* PHS1=0x03 */
CANGCON |=  MSK_CANGCON_ENA;                 /* start CAN */

/* Channel 0 init */
CANPAGE = (0 << 4);                          /* CHNB=0x00; select channel 0 */
CANSTCH  = 0x00;                             /* reset channel staus */               
CANCONCH = CH_DISABLE;                       /* reset control and dlc register */            

/* Channel 0: identifier = 11bits. CANIDT=0x123 */
CANIDT1 = 0x24;
CANIDT2 &= ~0x80;
CANIDT2 |=  0x60;

/* Channel 0: mask = 11bits. 0x7F0 */
CANIDM1 = 0xFE;
CANIDM2 &= ~0xE0;
CANIDM4 = 0;

/* Channel 0 configuration */
CANIDT4 &=~0x04;                             /* clear bit rtr in CANIDT4. */
CANCONCH |= DLC_MAX;                         /* Reception 8 bytes.*/
CANCONCH |= CH_RxENA;                        /* Reception enabled without buffer.*/

/* Channel 1 init */
CANPAGE = (1 << 4);                          /* CHNB=0x01; select channel 1 */
CANSTCH  = 0x00;                             /* reset channel staus */               
CANCONCH = CH_DISABLE;                       /* reset control and dlc register */            

/* Channel 1: identifier = 11bits. CANIDT=0x001 */
CANIDT1 = 0x80;
CANIDT2 &= ~0xC0;
CANIDT2 |= 0x20;

/* interrupt configuration */
CANIE2|=0x01;                                /* IECH0=1 */
CANGIE |= MSK_CANGIE_ENTX;                   /* Can_Tx IT enable */
CANGIE |= MSK_CANGIE_ENRX;                   /* Can_Rx IT enable */
ECAN = 1;                                    /* CAN IT enable */
EA = 1;                                      /* all IT enable */   


while(1);                                    /* endless */
}

/**
 * FUNCTION_PURPOSE: can interrupt. echo receive data on channel 0 reception.
 * Reception id between 0x120 and 0x12F.
 * FUNCTION_INPUTS: P4.1(RxDC) can input
 * FUNCTION_OUTPUTS: P4.0(TxDC) can output 
 */
can_it(void) interrupt 7
{
char save_canpage;
char i;                                      /* can_data index */
char can_data[8];

/* CAUTION can interrupt function modify CANPAGE. Save CANPAGE at beginning
and restore it at ending */
save_canpage = CANPAGE;                      /* save current context */

/* echo receive data on channel 0 reception */
CANPAGE = (0 << 4);                          /* CHNB=0x00; select channel 0 */
if(CANSTCH==MSK_CANSTCH_RxOk)        
{
   for (i=0; i<8; i++) can_data[i] = CANMSG; /* save receive data */
   CANPAGE = (1 << 4);                       /* CHNB=0x00; select channel 1 */
   /* Channel 1 configuration */
   CANCONCH = CH_DISABLE;                    /* reset channel 1 configuration */            
   for (i=0; i<8; i++) CANMSG = can_data[i]; /* load saved data */
   
   CANCONCH |= DLC_MAX;                      /* transmit 8 bytes */            
   CANCONCH |= CH_TxENA;                     /* emission enabled */
   CANEN2 |= (1 << 1);                       /* channel 1 enable */
   CANSTCH=0x00;                             /* reset channel 1 status */
}

CANPAGE = (0 << 4);                          /* CHNB=0x00; select channel 0 */
CANCONCH = CH_DISABLE;                       /* reset channel 0 configuration */            
CANCONCH |= DLC_MAX;                         /* receive 8 bytes */
CANCONCH |= CH_RxENA;                        /* reception enable */
CANEN2 |= (1 << 0);                          /* channel 0 enable */
CANSTCH=0x00;                                /* reset channel 0 status */

CANPAGE= save_canpage;                       /* restore saved context */ 

CANGIT = 0x00;                               /* reset all flags */ 
}


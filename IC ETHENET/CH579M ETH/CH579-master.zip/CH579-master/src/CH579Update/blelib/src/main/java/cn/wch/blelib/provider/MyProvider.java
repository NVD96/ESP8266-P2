package cn.wch.blelib.provider;

import androidx.core.content.FileProvider;

/**
 * @author WCH
 */
public class MyProvider extends FileProvider {
}

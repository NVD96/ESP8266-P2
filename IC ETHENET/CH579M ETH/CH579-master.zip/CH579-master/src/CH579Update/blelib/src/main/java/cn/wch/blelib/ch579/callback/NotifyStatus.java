package cn.wch.blelib.ch579.callback;

public interface NotifyStatus {
    void onData(byte[] data);
}

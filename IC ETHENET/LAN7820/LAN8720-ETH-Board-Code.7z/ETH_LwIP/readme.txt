
Development environment:KEIL MDK 4.0
Downloader;ULINK
Development Board IP: 192.168.0.100
PC client IP :192.168.0.xx
# ESP32ETH
Simple ESP32 with native ethernet using LAN8720 phy, Arduino compatible

Minimalistic design that can be extended. Manufactured and tested in real life, reliable, no packetloss, etc.

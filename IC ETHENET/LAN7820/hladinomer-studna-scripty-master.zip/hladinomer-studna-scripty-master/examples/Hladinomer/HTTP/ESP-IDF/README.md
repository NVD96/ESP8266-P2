# HTTP Request Example

Uses a POSIX socket to make a very simple HTTP request.

See the README.md file in the upper level 'examples' directory for more information about examples.

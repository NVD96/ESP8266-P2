#ifndef PSXCONTROLLER_H
#define PSXCONTROLLER_H

int psxReadInput();
void psxcontrollerInit();

#endif
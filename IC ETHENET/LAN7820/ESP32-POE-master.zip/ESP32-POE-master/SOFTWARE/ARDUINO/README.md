Make sure that you have properly installed the support for ESP32 chips in your Arduino IDE environment. Check the Arduino for ESP32 GitHub page for installation instructions: https://github.com/espressif/arduino-esp32

We commit updates directly to the ESP32's GitHub. When installing the ESP32 for Arduino IDE refer to these instructions:

https://docs.espressif.com/projects/arduino-esp32/en/latest/installing.html

After a successful installation make sure to select the Olimex board in Tools -> Board and its corresponding COM port from Tools -> Port.

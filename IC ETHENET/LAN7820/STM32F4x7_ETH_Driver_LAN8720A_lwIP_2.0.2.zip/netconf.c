/**
  ******************************************************************************
  * @file    netconf.c
  * @author  MCD Application Team
  * @version V1.1.0
  * @date    31-July-2013
  * @brief   Network connection configuration
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT 2013 STMicroelectronics</center></h2>
  *
  * Licensed under MCD-ST Liberty SW License Agreement V2, (the "License");
  * You may not use this file except in compliance with the License.
  * You may obtain a copy of the License at:
  *
  *        http://www.st.com/software_license_agreement_liberty_v2
  *
  * Unless required by applicable law or agreed to in writing, software
  * distributed under the License is distributed on an "AS IS" BASIS,
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx.h"
#include "lwip/mem.h"
#include "lwip/memp.h"
#include "lwip/dhcp.h"
#include "ethernetif.h"

#include "stm32f4x7_eth_bsp.h"

#include "netconf.h"
#include "lwip/tcpip.h"
#include <stdio.h>

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/

#include "UsartDebug.h"
#include "DS3231.h"

/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
struct	netif		xnetif;						// network interface structure
struct	dhcp		xdhcp;						// dhcp data

extern	__IO uint32_t  EthStatus;

#ifdef USE_DHCP
__IO uint8_t DHCP_state;
#endif

/* Private functions ---------------------------------------------------------*/
/**
  * @brief  Initializes the lwIP stack
  * @param  None
  * @retval None
  */
void LwIP_Init(void)
{
	struct ip4_addr ipaddr, netmask, gw;

	tcpip_init( NULL, NULL );					// Create tcp_ip stack thread

	// IP address setting
#ifdef USE_DHCP
	ipaddr.addr = 0;
	netmask.addr = 0;
	gw.addr = 0;
#else
	IP4_ADDR(&ipaddr, IP_ADDR0, IP_ADDR1, IP_ADDR2, IP_ADDR3);
	IP4_ADDR(&netmask, NETMASK_ADDR0, NETMASK_ADDR1 , NETMASK_ADDR2, NETMASK_ADDR3);
	IP4_ADDR(&gw, GW_ADDR0, GW_ADDR1, GW_ADDR2, GW_ADDR3);
#endif

	netif_add(&xnetif, &ipaddr, &netmask, &gw, NULL, &ethernetif_init, &tcpip_input);			// Adds your network interface to the netif_list
	netif_set_hostname(&xnetif	,DEFAULT_HOSTNAME	);											// Set hostname for DNS
	netif_set_default(&xnetif);																	//  Registers the default network interface.
	dhcp_set_struct(&xnetif	,&xdhcp);

	if (EthStatus == (ETH_INIT_FLAG | ETH_LINK_FLAG))
	{
		netif_set_link_up(&xnetif);																// Set Ethernet link flag
		netif_set_up(&xnetif);																	// When the netif is fully configured this function must be called.

#ifdef USE_DHCP
		DHCP_state = DHCP_START;
#else
		xSemaphoreTake(UsartDebugMutex, portMAX_DELAY);
			RtcPutTimeStamp();
			sprintf((char *)UsartDebugBuffer, "[ETHERNET]->Init: DHCP off, static IP address:: %d.%d.%d.%d\r\n",IP_ADDR0, IP_ADDR1, IP_ADDR2, IP_ADDR3);
			UsartDebugSendString((const uint8_t*)UsartDebugBuffer);
		xSemaphoreGive(UsartDebugMutex);
#endif
	}
	else
	{
		netif_set_down(&xnetif);													//  When the netif link is down this function must be called.
#ifdef USE_DHCP
		DHCP_state = DHCP_LINK_DOWN;
#endif
		xSemaphoreTake(UsartDebugMutex, portMAX_DELAY);
			RtcPutTimeStamp();
			UsartDebugSendString((uint8_t*)"[ETHERNET]->Init: link down\r\n");
		xSemaphoreGive(UsartDebugMutex);
	}
	netif_set_link_callback(&xnetif, ETH_link_callback);							// Set the link callback function, this function is called on change of link status
}

#ifdef USE_DHCP
/**
  * @brief  LwIP_DHCP_Process_Handle
  * @param  None
  * @retval None
  */
void LwIP_DHCP_task(void * pvParameters)
{
	struct ip4_addr ipaddr, netmask, gw;

	while(1)
	{
		switch (DHCP_state)
		{
			case DHCP_START:
			{
				dhcp_start(&xnetif);

				ipaddr.addr = 0;
				DHCP_state = DHCP_WAIT_ADDRESS;

				xSemaphoreTake(UsartDebugMutex, portMAX_DELAY);
					RtcPutTimeStamp();
					UsartDebugSendString((uint8_t*)"[ETHERNET]->Looking for DHCP server...\r\n");
				xSemaphoreGive(UsartDebugMutex);
				break;
			}
			case DHCP_WAIT_ADDRESS:
			{
				ipaddr.addr = xnetif.ip_addr.addr;						// Read the new IP address

				if (ipaddr.addr)
				{
					DHCP_state = DHCP_ADDRESS_ASSIGNED;

					xSemaphoreTake(UsartDebugMutex, portMAX_DELAY);
						RtcPutTimeStamp();
						sprintf((char *)UsartDebugBuffer, "[ETHERNET]->IP address assigned by a DHCP server: %d.%d.%d.%d\r\n",ip4_addr1(&ipaddr),	ip4_addr2(&ipaddr), ip4_addr3(&ipaddr), ip4_addr4(&ipaddr));
						UsartDebugSendString((const uint8_t*)UsartDebugBuffer);
					xSemaphoreGive(UsartDebugMutex);
				}
				else
				{
					if (xdhcp.tries > MAX_DHCP_TRIES)				// DHCP timeout
					{
						DHCP_state = DHCP_TIMEOUT;

						dhcp_release(&xnetif);
						dhcp_stop(&xnetif);						// Stop DHCP


						IP4_ADDR(&ipaddr, IP_ADDR0 ,IP_ADDR1 , IP_ADDR2 , IP_ADDR3 );										// Static address used
						IP4_ADDR(&netmask, NETMASK_ADDR0, NETMASK_ADDR1, NETMASK_ADDR2, NETMASK_ADDR3);
						IP4_ADDR(&gw, GW_ADDR0, GW_ADDR1, GW_ADDR2, GW_ADDR3);
						netif_set_addr(&xnetif, &ipaddr , &netmask, &gw);

						xSemaphoreTake(UsartDebugMutex, portMAX_DELAY);
							RtcPutTimeStamp();
							sprintf((char *)UsartDebugBuffer, "[ETHERNET]->DHCP timeout, static IP address: %d.%d.%d.%d\rn",ip4_addr1(&ipaddr),	ip4_addr2(&ipaddr), ip4_addr3(&ipaddr), ip4_addr4(&ipaddr));
							UsartDebugSendString((const uint8_t*)UsartDebugBuffer);
						xSemaphoreGive(UsartDebugMutex);
					}
				}
				break;
			}
			default: break;
		}
		vTaskDelay(250);
	}
}
#endif  /* USE_DHCP */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/

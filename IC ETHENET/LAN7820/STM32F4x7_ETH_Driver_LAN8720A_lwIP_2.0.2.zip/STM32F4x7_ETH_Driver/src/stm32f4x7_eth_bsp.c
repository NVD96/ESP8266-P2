/**
  ******************************************************************************
  * @file    stm32f4x7_eth_bsp.c
  * @author  MCD Application Team
  * @version V1.1.0
  * @date    31-July-2013
  * @brief   STM32F4x7 Ethernet hardware configuration.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT 2013 STMicroelectronics</center></h2>
  *
  * Licensed under MCD-ST Liberty SW License Agreement V2, (the "License");
  * You may not use this file except in compliance with the License.
  * You may obtain a copy of the License at:
  *
  *        http://www.st.com/software_license_agreement_liberty_v2
  *
  * Unless required by applicable law or agreed to in writing, software
  * distributed under the License is distributed on an "AS IS" BASIS,
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "lwip/opt.h"
#include "stm32f4x7_eth.h"
#include "stm32f4x7_eth_bsp.h"


#include "lwip/netif.h"
#include "netconf.h"
#include "lwip/dhcp.h"

/* Scheduler includes */
#include "FreeRTOS.h"
#include "task.h"

#include "UsartDebug.h"
#include "DS3231.h"

/* The time to block waiting for input. */
#define ETH_LINK_TASK_STACK_SIZE				( configMINIMAL_STACK_SIZE * 2 )
#define ETH_LINK_TASK_PRIORITY					( tskIDLE_PRIORITY + 1 )
#define emacBLOCK_TIME_WAITING_ETH_LINK_IT		( ( portTickType ) 100 )


ETH_InitTypeDef ETH_InitStructure;
__IO uint32_t  EthStatus = 0;
extern struct netif xnetif;

#ifdef USE_DHCP
extern __IO uint8_t DHCP_state;
#endif

static void ETH_GPIO_Config(void);
static void ETH_NVIC_Config(void);
static void ETH_MACDMA_Config(void);

/* Private functions ---------------------------------------------------------*/

/**
  * @brief  ETH_BSP_Config
  * @param  None
  * @retval None
  */
void ETH_BSP_Config(void)
{
	xSemaphoreTake(UsartDebugMutex, portMAX_DELAY);
		RtcPutTimeStamp();
		UsartDebugSendString((uint8_t*)"[ETHERNET]->Start\r\n");
	xSemaphoreGive(UsartDebugMutex);

	ETH_GPIO_Config();					// Configure the GPIO ports for ethernet pins
	ETH_NVIC_Config();					// Config NVIC for Ethernet
	ETH_MACDMA_Config();				// Configure the Ethernet MAC/DMA


	if(ETH_ReadPHYRegister(LAN8720A_PHY_ADDRESS, PHY_BSR) & PHY_Linked_Status)		// Get Ethernet link status
	{
		EthStatus |= ETH_LINK_FLAG;

		xSemaphoreTake(UsartDebugMutex, portMAX_DELAY);
			RtcPutTimeStamp();
			UsartDebugSendString((const uint8_t*)"[ETHERNET]->Link up\r\n");
		xSemaphoreGive(UsartDebugMutex);
	}

	// create the task that handles the ETH_link
	xTaskCreate(Eth_Link_IT_task		,(char const*)"ETH_link"		,ETH_LINK_TASK_STACK_SIZE	,(void *)LAN8720A_PHY_ADDRESS	,ETH_LINK_TASK_PRIORITY	,NULL	);
}

/**
  * @brief  Configures the Ethernet Interface
  * @param  None
  * @retval None
  */
static void ETH_MACDMA_Config(void)
{
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_ETH_MAC | RCC_AHB1Periph_ETH_MAC_Tx | RCC_AHB1Periph_ETH_MAC_Rx, ENABLE);	// Enable ETHERNET clock

	ETH_DeInit();				// Reset ETHERNET on AHB Bus
	ETH_SoftwareReset();		// Software reset
	while (ETH_GetSoftwareResetStatus() == SET);	// Wait for software reset

	// ETHERNET Configuration
	ETH_StructInit(&ETH_InitStructure);

	/*------------------------   MAC   -----------------------------------*/
	ETH_InitStructure.ETH_AutoNegotiation				= ETH_AutoNegotiation_Enable;
	ETH_InitStructure.ETH_LoopbackMode					= ETH_LoopbackMode_Disable;
	ETH_InitStructure.ETH_RetryTransmission				= ETH_RetryTransmission_Disable;
	ETH_InitStructure.ETH_AutomaticPadCRCStrip			= ETH_AutomaticPadCRCStrip_Disable;
	ETH_InitStructure.ETH_ReceiveAll					= ETH_ReceiveAll_Disable;
	ETH_InitStructure.ETH_BroadcastFramesReception		= ETH_BroadcastFramesReception_Enable;
	ETH_InitStructure.ETH_PromiscuousMode				= ETH_PromiscuousMode_Disable;
	ETH_InitStructure.ETH_MulticastFramesFilter			= ETH_MulticastFramesFilter_Perfect;
	ETH_InitStructure.ETH_UnicastFramesFilter			= ETH_UnicastFramesFilter_Perfect;
#ifdef CHECKSUM_BY_HARDWARE
	ETH_InitStructure.ETH_ChecksumOffload				= ETH_ChecksumOffload_Enable;
#endif

	/*------------------------   DMA   -----------------------------------*/

	/* When we use the Checksum offload feature, we need to enable the Store and Forward mode:
	the store and forward guarantee that a whole frame is stored in the FIFO, so the MAC can insert/verify the checksum,
	if the checksum is OK the DMA can handle the frame otherwise the frame is dropped */
	ETH_InitStructure.ETH_DropTCPIPChecksumErrorFrame		= ETH_DropTCPIPChecksumErrorFrame_Enable;
	ETH_InitStructure.ETH_ReceiveStoreForward				= ETH_ReceiveStoreForward_Enable;
	ETH_InitStructure.ETH_TransmitStoreForward				= ETH_TransmitStoreForward_Enable;

	ETH_InitStructure.ETH_ForwardErrorFrames				= ETH_ForwardErrorFrames_Disable;
	ETH_InitStructure.ETH_ForwardUndersizedGoodFrames		= ETH_ForwardUndersizedGoodFrames_Disable;
	ETH_InitStructure.ETH_SecondFrameOperate				= ETH_SecondFrameOperate_Enable;
	ETH_InitStructure.ETH_AddressAlignedBeats				= ETH_AddressAlignedBeats_Enable;
	ETH_InitStructure.ETH_FixedBurst						= ETH_FixedBurst_Enable;
	ETH_InitStructure.ETH_RxDMABurstLength					= ETH_RxDMABurstLength_32Beat;
	ETH_InitStructure.ETH_TxDMABurstLength					= ETH_TxDMABurstLength_32Beat;
	ETH_InitStructure.ETH_DMAArbitration					= ETH_DMAArbitration_RoundRobin_RxTx_2_1;


	EthStatus = ETH_Init(&ETH_InitStructure, LAN8720A_PHY_ADDRESS);		// Configure Ethernet

	ETH_DMAITConfig(ETH_DMA_IT_NIS | ETH_DMA_IT_R, ENABLE);				// Enable the Ethernet Rx Interrupt
}

/**
  * @brief  Configures the different GPIO ports.
  * @param  None
  * @retval None
  */
void ETH_GPIO_Config(void)
{
	GPIO_InitTypeDef	GPIO_InitStructure;


	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA | RCC_AHB1Periph_GPIOB | RCC_AHB1Periph_GPIOC, ENABLE);		// Enable GPIOs clocks
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_SYSCFG, ENABLE);					// Enable SYSCFG clock
	SYSCFG_ETH_MediaInterfaceConfig(SYSCFG_ETH_MediaInterface_RMII);		// MII/RMII Media interface selection

	// Ethernet pins configuration
	/*
	ETH_MDIO			PA2
	ETH_MDC				PC1
	ETH_RMII_REF_CLK	PA1
	ETH_RMII_CRS_DV		PA7
	ETH_RMII_RXD0		PC4
	ETH_RMII_RXD1		PC5
	ETH_RMII_TX_EN		PB11
	ETH_RMII_TXD0		PB12
	ETH_RMII_TXD1		PB13
	ETH_PHY_RST			PC0
	*/

	GPIO_InitStructure.GPIO_Speed		= GPIO_Speed_100MHz;
	GPIO_InitStructure.GPIO_Mode		= GPIO_Mode_AF;
	GPIO_InitStructure.GPIO_OType		= GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd		= GPIO_PuPd_NOPULL ;

	// Configure PA1(ETH_RMII_REF_CLK),	PA2(ETH_MDIO),	PA7(ETH_RMII_CRS_DV)
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1 | GPIO_Pin_2 | GPIO_Pin_7;
	GPIO_Init(GPIOA	,&GPIO_InitStructure	);
	GPIO_PinAFConfig(GPIOA	,GPIO_PinSource1	,GPIO_AF_ETH	);			// ETH_RMII_REF_CLK
	GPIO_PinAFConfig(GPIOA	,GPIO_PinSource2	,GPIO_AF_ETH	);			// ETH_MDIO
	GPIO_PinAFConfig(GPIOA	,GPIO_PinSource7	,GPIO_AF_ETH	);			// ETH_RMII_CRS_DV

	// Configure PB11(ETH_RMII_TX_EN),	PB12(ETH_RMII_TXD0),	PB13(ETH_RMII_TXD1)
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11 | GPIO_Pin_12 | GPIO_Pin_13;
	GPIO_Init(GPIOB	,&GPIO_InitStructure	);
	GPIO_PinAFConfig(GPIOB	,GPIO_PinSource11	,GPIO_AF_ETH	);			// ETH_RMII_TX_EN
	GPIO_PinAFConfig(GPIOB	,GPIO_PinSource12	,GPIO_AF_ETH	);			// ETH_RMII_TXD0
	GPIO_PinAFConfig(GPIOB	,GPIO_PinSource13	,GPIO_AF_ETH	);  		// ETH_RMII_TXD1


	// Configure PC1(ETH_MDC),	PC4(ETH_RMII_RXD0),	PC5(ETH_RMII_RXD1)
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1 | GPIO_Pin_4 | GPIO_Pin_5;
	GPIO_Init(GPIOC, &GPIO_InitStructure);
	GPIO_PinAFConfig(GPIOC	,GPIO_PinSource1	,GPIO_AF_ETH	);			// ETH_MDC
	GPIO_PinAFConfig(GPIOC	,GPIO_PinSource4	,GPIO_AF_ETH	);			// ETH_RMII_RXD0
	GPIO_PinAFConfig(GPIOC	,GPIO_PinSource5	,GPIO_AF_ETH	);  		// ETH_RMII_RXD1

	// Configure PC0(ETH_PHY_RST)
	GPIO_InitStructure.GPIO_Pin		= GPIO_Pin_0;
	GPIO_InitStructure.GPIO_Mode	= GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_OType	= GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd	= GPIO_PuPd_UP;
	GPIO_InitStructure.GPIO_Speed	= GPIO_Speed_50MHz;
	GPIO_Init(GPIOC	,&GPIO_InitStructure	);

	GPIO_ResetBits(GPIOC, GPIO_Pin_0);
	vTaskDelay(1);
	GPIO_SetBits(GPIOC, GPIO_Pin_0);
	vTaskDelay(1);
}

/**
  * @brief  Configures and enable the Ethernet global interrupt.
  * @param  None
  * @retval None
  */
void ETH_NVIC_Config(void)
{
	NVIC_InitTypeDef   NVIC_InitStructure;

	// Enable the Ethernet global Interrupt
	NVIC_InitStructure.NVIC_IRQChannel						= ETH_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority	= 12 ;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority			= 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd					= ENABLE;
	NVIC_Init(&NVIC_InitStructure);
}


/**
* @brief  This function handles Ethernet link status.
* @param  None
* @retval None
*/
void Eth_Link_IT_task( void * pvParameters )
{
	uint32_t pcPHYAddress;

	pcPHYAddress = ( uint32_t  ) pvParameters;
	while(1)
	{
		if((ETH_ReadPHYRegister((uint16_t) pcPHYAddress, PHY_BSR) & PHY_Linked_Status))
		{
			netif_set_link_up(&xnetif);
		}
		else
		{
			netif_set_link_down(&xnetif);
		}
		vTaskDelay(emacBLOCK_TIME_WAITING_ETH_LINK_IT);
	}
}

/**
  * @brief  Link callback function, this function is called on change of link status.
  * @param  The network interface
  * @retval None
  */
void ETH_link_callback(struct netif *netif)
{
	__IO uint32_t 		timeout = 0;
	uint32_t			tmpreg, RegValue;
	struct ip4_addr		ipaddr,	netmask,	gw;
#ifndef USE_DHCP
	uint8_t				iptab[4] = {0},iptxt[20];
#endif

	if(netif_is_link_up(netif))
	{
		if(ETH_InitStructure.ETH_AutoNegotiation != ETH_AutoNegotiation_Disable)		// Restart the autonegotiation
		{
			timeout = 0;																		// Reset Timeout counter
			ETH_WritePHYRegister(LAN8720A_PHY_ADDRESS, PHY_BCR, PHY_AutoNegotiation);			// Enable Auto-Negotiation
			do																					// Wait until the auto-negotiation will be completed
			{
				timeout++;
			} while (!(ETH_ReadPHYRegister(LAN8720A_PHY_ADDRESS, PHY_BSR) & PHY_AutoNego_Complete) && (timeout < (uint32_t)PHY_READ_TO));


			timeout = 0;																		// Reset Timeout counter
			RegValue = ETH_ReadPHYRegister(LAN8720A_PHY_ADDRESS, PHY_SR);						// Read the result of the auto-negotiation

			if(RegValue & PHY_DUPLEX_STATUS)													// Configure the MAC with the Duplex Mode fixed by the auto-negotiation process
			{
				ETH_InitStructure.ETH_Mode = ETH_Mode_FullDuplex;  								// Set Ethernet duplex mode to Full-duplex following the auto-negotiation
			}
			else
			{
				ETH_InitStructure.ETH_Mode = ETH_Mode_HalfDuplex;								// Set Ethernet duplex mode to Half-duplex following the auto-negotiation
			}

			if(RegValue & PHY_SPEED_STATUS)														// Configure the MAC with the speed fixed by the auto-negotiation process
			{
				ETH_InitStructure.ETH_Speed = ETH_Speed_10M;									// Set Ethernet speed to 10M following the auto-negotiation
			}
			else
			{
				ETH_InitStructure.ETH_Speed = ETH_Speed_100M;									// Set Ethernet speed to 100M following the auto-negotiation
			}

			// ETHERNET MACCR Re-Configuration
			tmpreg = ETH->MACCR;																// Get the ETHERNET MACCR value
			tmpreg |= (uint32_t)(ETH_InitStructure.ETH_Speed | ETH_InitStructure.ETH_Mode);		// Set the FES bit according to ETH_Speed value, set the DM bit according to ETH_Mode value

			ETH->MACCR = (uint32_t)tmpreg;														// Write to ETHERNET MACCR

			_eth_delay_(ETH_REG_WRITE_DELAY);
			tmpreg = ETH->MACCR;
			ETH->MACCR = tmpreg;
		}

		ETH_Start();		// Restart MAC interface
#ifdef USE_DHCP
		ipaddr.addr = 0;
		netmask.addr = 0;
		gw.addr = 0;

		DHCP_state = DHCP_START;
#else
		IP4_ADDR(&ipaddr, IP_ADDR0, IP_ADDR1, IP_ADDR2, IP_ADDR3);
		IP4_ADDR(&netmask, NETMASK_ADDR0, NETMASK_ADDR1 , NETMASK_ADDR2, NETMASK_ADDR3);
		IP4_ADDR(&gw, GW_ADDR0, GW_ADDR1, GW_ADDR2, GW_ADDR3);
#endif

		netif_set_addr(netif, &ipaddr , &netmask, &gw);
		netif_set_up(netif);    										// When the netif is fully configured this function must be called

		xSemaphoreTake(UsartDebugMutex, portMAX_DELAY);
			RtcPutTimeStamp();
			UsartDebugSendString((const uint8_t*)"[ETHERNET]->Link up\r\n");
		xSemaphoreGive(UsartDebugMutex);
#ifndef USE_DHCP
		xSemaphoreTake(UsartDebugMutex, portMAX_DELAY);
			RtcPutTimeStamp();
			sprintf((char *)UsartDebugBuffer, "[ETHERNET]->DHCP off, static IP address:: %d.%d.%d.%d\r\n",IP_ADDR0, IP_ADDR1, IP_ADDR2, IP_ADDR3);
			UsartDebugSendString((const uint8_t*)UsartDebugBuffer);
		xSemaphoreGive(UsartDebugMutex);
#endif
	}
  	else
	{
		ETH_Stop();
#ifdef USE_DHCP
		DHCP_state = DHCP_LINK_DOWN;
		dhcp_release(netif);
		dhcp_stop(netif);
#endif
		netif_set_down(netif);		//  When the netif link is down this function must be called

		xSemaphoreTake(UsartDebugMutex, portMAX_DELAY);
			RtcPutTimeStamp();
			UsartDebugSendString((uint8_t*)"[ETHERNET]->Link down\r\n");
		xSemaphoreGive(UsartDebugMutex);
	}
}

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/

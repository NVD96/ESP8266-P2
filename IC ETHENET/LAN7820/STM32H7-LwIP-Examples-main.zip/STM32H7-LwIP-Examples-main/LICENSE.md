| Component                       |                     Copyright                             |                   License                    |
|:---------                       |:----------------------------------------------------------|:---------------------------------------------|
| CMSIS                           | ARM Limited                                               | Apache License 2.0                           |
| CMSIS Device                    | ARM Limited - STMicroelectronics                          | Apache License 2.0                           |
| STM32H7 HAL                     | STMicroelectronics                                        | BSD-3-Clause                                 |
| BSP Components                  | STMicroelectronics                                        | BSD-3-Clause                                 |
| FreeRTOS kernel                 | Amazon.com, Inc. or its affiliates                        | MIT                                          |
| LwIP                            | Swedish Institute of Computer Science                     | BSD-3-Clause                                 |
| STM32 Projects                  | STMicroelectronics                                        | SLA0044 (BSD-3-Clause for basic Examples)    |
#ifndef __CLIENTSOCKET_H
#define __CLIENTSOCKET_H

void ClientSocketTCP(void);

#endif
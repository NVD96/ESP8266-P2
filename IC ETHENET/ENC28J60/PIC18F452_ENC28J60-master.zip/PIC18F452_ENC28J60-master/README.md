# PIC18F452_ENC28J60

PIC18F452 + ENC28J60 ETHERNET

this code implements: socket client and server web server http

microchip microcontroller: PIC18F452

compiler used: MICROCHIP C18

IDE used: MICROCHIP MPLABX

how use this, click on this links:

video 20 https://www.youtube.com/watch?v=bw4drnXNRU8

video 21 https://www.youtube.com/watch?v=Z8jerYzHvA4

video 22 https://www.youtube.com/watch?v=8cpVyn0nBXw

video 23 https://www.youtube.com/watch?v=vXFWnsYBVfc

video 24 https://www.youtube.com/watch?v=0AhBBfH1vWk

video 25 https://www.youtube.com/watch?v=B5hGlWDhck0

video 26 https://www.youtube.com/watch?v=vbAiNJ-K5yU

video 27 https://www.youtube.com/watch?v=DlJOUUGjOU8

video 28 https://www.youtube.com/watch?v=yTJHk9RV1hY

video 29 https://www.youtube.com/watch?v=G5LpOyUg-nw


-------------------------------------------------------------
bitcoin donation: bc1qppnaphwqwshk6kqzaal28p5854cntslu0y5dw7

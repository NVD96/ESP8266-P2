class Data:
    ssid=["<SSID1>","<SSID2>"]
    pwd=["<PWD1>", "<PWD2>"]
    times_try=10
    debug=True
